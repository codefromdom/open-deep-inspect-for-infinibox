
#!/usr/bin/env python3
"""
Topology Correlation Service
Open Source Community

Correlates data from all exporters to build complete end-to-end paths:
Infinibox Volume → WWPN → FC Zone → ESXi HBA → Datastore → VM

Stores topology in PostgreSQL and exposes via REST API and Prometheus metrics.
"""

import os
import sys
import time
import json
import logging
import psycopg2
import psycopg2.extras
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
from threading import Thread, Lock
from flask import Flask, jsonify, request, Response
from prometheus_client import Gauge, Counter, Info, Histogram, generate_latest, REGISTRY
import yaml

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='{"timestamp": "%(asctime)s", "level": "%(levelname)s", "module": "%(name)s", "message": "%(message)s"}',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger(__name__)

# Flask app
app = Flask(__name__)

# ============================================================================
# Prometheus Metrics
# ============================================================================

topology_correlator_info = Info('topology_correlator', 'Topology correlator service information')
topology_paths_total = Gauge('topology_paths_total', 'Total number of complete paths discovered')
topology_volumes_total = Gauge('topology_volumes_total', 'Total number of volumes in topology')
topology_hosts_total = Gauge('topology_hosts_total', 'Total number of hosts in topology')
topology_vms_total = Gauge('topology_vms_total', 'Total number of VMs in topology')
topology_datastores_total = Gauge('topology_datastores_total', 'Total number of datastores in topology')
topology_fc_zones_total = Gauge('topology_fc_zones_total', 'Total number of FC zones in topology')

topology_path_health = Gauge('topology_path_health', 'Path health status (1=healthy, 0=degraded)',
                             ['volume_name', 'vm_name'])
topology_correlation_duration = Histogram('topology_correlation_duration_seconds',
                                         'Duration of correlation operations')
topology_correlation_errors = Counter('topology_correlation_errors_total',
                                     'Total correlation errors', ['error_type'])
topology_last_update = Gauge('topology_last_update_timestamp', 'Last successful topology update timestamp')

# ============================================================================
# Data Models
# ============================================================================

@dataclass
class InfiniboxVolume:
    volume_id: str
    volume_name: str
    volume_serial: str
    pool_name: str
    size_bytes: int
    wwpns: List[str] = field(default_factory=list)
    iqns: List[str] = field(default_factory=list)

@dataclass
class HostMapping:
    host_id: str
    host_name: str
    volume_id: str
    volume_name: str
    lun_id: str
    initiator_wwpns: List[str] = field(default_factory=list)
    initiator_iqns: List[str] = field(default_factory=list)

@dataclass
class FCZone:
    zone_name: str
    zoneset_name: str
    switch_name: str
    member_wwpns: List[str] = field(default_factory=list)

@dataclass
class ESXiHost:
    host_name: str
    host_id: str
    hba_wwpns: List[str] = field(default_factory=list)
    datastores: List[str] = field(default_factory=list)

@dataclass
class Datastore:
    datastore_name: str
    datastore_id: str
    lun_id: Optional[str] = None
    capacity_bytes: int = 0
    vms: List[str] = field(default_factory=list)

@dataclass
class VM:
    vm_name: str
    vm_id: str
    datastore: str
    host: str

@dataclass
class TopologyPath:
    """Complete end-to-end path"""
    path_id: str
    volume_name: str
    volume_id: str
    host_mappings: List[str]
    fc_zones: List[str]
    esxi_hosts: List[str]
    datastores: List[str]
    vms: List[str]
    health_status: str = "healthy"
    last_update: datetime = field(default_factory=datetime.now)

# ============================================================================
# Configuration
# ============================================================================

@dataclass
class CorrelatorConfig:
    """Configuration for topology correlator"""
    # Database
    db_host: str = "localhost"
    db_port: int = 5432
    db_name: str = "topology"
    db_user: str = "topology_user"
    db_password: str = "changeme"
    
    # Exporter endpoints
    infinibox_exporter_url: str = "http://localhost:9600/metrics"
    brocade_exporter_url: str = "http://localhost:9602/metrics"
    vmware_exporter_url: str = "http://localhost:9605/metrics"
    
    # Service settings
    correlation_interval: int = 60  # seconds
    api_port: int = 9700
    
    @classmethod
    def from_env(cls):
        return cls(
            db_host=os.getenv('DB_HOST', 'localhost'),
            db_port=int(os.getenv('DB_PORT', '5432')),
            db_name=os.getenv('DB_NAME', 'topology'),
            db_user=os.getenv('DB_USER', 'topology_user'),
            db_password=os.getenv('DB_PASSWORD', 'changeme'),
            infinibox_exporter_url=os.getenv('INFINIBOX_EXPORTER', 'http://localhost:9600/metrics'),
            brocade_exporter_url=os.getenv('BROCADE_EXPORTER', 'http://localhost:9602/metrics'),
            vmware_exporter_url=os.getenv('VMWARE_EXPORTER', 'http://localhost:9605/metrics'),
            correlation_interval=int(os.getenv('CORRELATION_INTERVAL', '60')),
            api_port=int(os.getenv('API_PORT', '9700')),
        )
    
    @classmethod
    def from_file(cls, config_path: str):
        try:
            with open(config_path, 'r') as f:
                config_data = yaml.safe_load(f)
            
            return cls(
                db_host=config_data.get('database', {}).get('host', 'localhost'),
                db_port=config_data.get('database', {}).get('port', 5432),
                db_name=config_data.get('database', {}).get('name', 'topology'),
                db_user=config_data.get('database', {}).get('user', 'topology_user'),
                db_password=config_data.get('database', {}).get('password', 'changeme'),
                infinibox_exporter_url=config_data.get('exporters', {}).get('infinibox', 'http://localhost:9600/metrics'),
                brocade_exporter_url=config_data.get('exporters', {}).get('brocade', 'http://localhost:9602/metrics'),
                vmware_exporter_url=config_data.get('exporters', {}).get('vmware', 'http://localhost:9605/metrics'),
                correlation_interval=config_data.get('correlation_interval', 60),
                api_port=config_data.get('api_port', 9700),
            )
        except Exception as e:
            logger.error(f"Failed to load config from {config_path}: {e}")
            return cls.from_env()

# ============================================================================
# Database Manager
# ============================================================================

class DatabaseManager:
    """Manages PostgreSQL database connections and operations"""
    
    def __init__(self, config: CorrelatorConfig):
        self.config = config
        self.conn = None
        self.lock = Lock()
    
    def connect(self):
        """Establish database connection"""
        try:
            self.conn = psycopg2.connect(
                host=self.config.db_host,
                port=self.config.db_port,
                dbname=self.config.db_name,
                user=self.config.db_user,
                password=self.config.db_password
            )
            logger.info(f"Connected to database {self.config.db_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            return False
    
    def execute(self, query: str, params: tuple = None, fetch: bool = False):
        """Execute a database query"""
        with self.lock:
            try:
                if not self.conn or self.conn.closed:
                    self.connect()
                
                cursor = self.conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
                cursor.execute(query, params)
                
                if fetch:
                    results = cursor.fetchall()
                    cursor.close()
                    return results
                else:
                    self.conn.commit()
                    cursor.close()
                    return True
            except Exception as e:
                logger.error(f"Database error: {e}")
                if self.conn:
                    self.conn.rollback()
                return None if fetch else False
    
    def store_volume(self, volume: InfiniboxVolume):
        """Store or update volume information"""
        query = """
            INSERT INTO volumes (volume_id, volume_name, volume_serial, pool_name, size_bytes, last_seen)
            VALUES (%s, %s, %s, %s, %s, NOW())
            ON CONFLICT (volume_id) DO UPDATE SET
                volume_name = EXCLUDED.volume_name,
                volume_serial = EXCLUDED.volume_serial,
                pool_name = EXCLUDED.pool_name,
                size_bytes = EXCLUDED.size_bytes,
                last_seen = NOW()
        """
        return self.execute(query, (volume.volume_id, volume.volume_name, volume.volume_serial, 
                                     volume.pool_name, volume.size_bytes))
    
    def store_host_mapping(self, mapping: HostMapping):
        """Store host to volume mapping"""
        query = """
            INSERT INTO host_mappings (host_id, host_name, volume_id, lun_id, last_seen)
            VALUES (%s, %s, %s, %s, NOW())
            ON CONFLICT (host_id, volume_id) DO UPDATE SET
                host_name = EXCLUDED.host_name,
                lun_id = EXCLUDED.lun_id,
                last_seen = NOW()
        """
        return self.execute(query, (mapping.host_id, mapping.host_name, mapping.volume_id, mapping.lun_id))
    
    def store_fc_zone(self, zone: FCZone):
        """Store FC zone configuration"""
        query = """
            INSERT INTO fc_zones (zone_name, zoneset_name, switch_name, last_seen)
            VALUES (%s, %s, %s, NOW())
            ON CONFLICT (zone_name, switch_name) DO UPDATE SET
                zoneset_name = EXCLUDED.zoneset_name,
                last_seen = NOW()
        """
        return self.execute(query, (zone.zone_name, zone.zoneset_name, zone.switch_name))
    
    def store_topology_path(self, path: TopologyPath):
        """Store complete topology path"""
        query = """
            INSERT INTO topology_paths (path_id, volume_name, volume_id, path_data, health_status, last_update)
            VALUES (%s, %s, %s, %s, %s, NOW())
            ON CONFLICT (path_id) DO UPDATE SET
                path_data = EXCLUDED.path_data,
                health_status = EXCLUDED.health_status,
                last_update = NOW()
        """
        path_data = json.dumps(asdict(path))
        return self.execute(query, (path.path_id, path.volume_name, path.volume_id, 
                                     path_data, path.health_status))
    
    def get_all_paths(self):
        """Retrieve all topology paths"""
        query = "SELECT * FROM topology_paths WHERE last_update > NOW() - INTERVAL '1 hour'"
        return self.execute(query, fetch=True)
    
    def get_path_by_volume(self, volume_name: str):
        """Get paths for a specific volume"""
        query = "SELECT * FROM topology_paths WHERE volume_name = %s"
        return self.execute(query, (volume_name,), fetch=True)
    
    def get_path_by_vm(self, vm_name: str):
        """Get paths for a specific VM"""
        query = "SELECT * FROM topology_paths WHERE path_data::jsonb @> %s::jsonb"
        search_json = json.dumps({"vms": [vm_name]})
        return self.execute(query, (search_json,), fetch=True)

# ============================================================================
# Metrics Scraper
# ============================================================================

class MetricsScraper:
    """Scrapes metrics from Prometheus exporters"""
    
    def __init__(self, config: CorrelatorConfig):
        self.config = config
    
    def scrape_prometheus_metrics(self, url: str, timeout: int = 10) -> Dict[str, Any]:
        """Scrape and parse Prometheus metrics"""
        try:
            response = requests.get(url, timeout=timeout)
            response.raise_for_status()
            
            metrics = {}
            for line in response.text.split('\n'):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                
                # Parse metric line
                try:
                    parts = line.split(' ')
                    if len(parts) >= 2:
                        metric_with_labels = parts[0]
                        value = parts[1]
                        
                        # Extract metric name and labels
                        if '{' in metric_with_labels:
                            metric_name = metric_with_labels[:metric_with_labels.index('{')]
                            labels_str = metric_with_labels[metric_with_labels.index('{')+1:metric_with_labels.index('}')]
                            
                            # Parse labels
                            labels = {}
                            for label_pair in labels_str.split(','):
                                if '=' in label_pair:
                                    key, val = label_pair.split('=', 1)
                                    labels[key.strip()] = val.strip('"')
                            
                            if metric_name not in metrics:
                                metrics[metric_name] = []
                            metrics[metric_name].append({'labels': labels, 'value': value})
                        else:
                            metrics[metric_with_labels] = [{'value': value}]
                except Exception as e:
                    logger.debug(f"Could not parse metric line: {line[:100]}")
            
            return metrics
        except Exception as e:
            logger.error(f"Failed to scrape metrics from {url}: {e}")
            return {}
    
    def get_infinibox_data(self) -> Dict[str, Any]:
        """Get data from Infinibox exporter"""
        metrics = self.scrape_prometheus_metrics(self.config.infinibox_exporter_url)
        
        data = {
            'volumes': [],
            'host_mappings': [],
            'fc_ports': []
        }
        
        # Extract volume information
        if 'infinibox_volume_size_bytes' in metrics:
            for metric in metrics['infinibox_volume_size_bytes']:
                labels = metric['labels']
                data['volumes'].append({
                    'volume_id': labels.get('volume_id'),
                    'volume_name': labels.get('volume_name'),
                    'pool_name': labels.get('pool_name'),
                    'size_bytes': int(float(metric['value']))
                })
        
        # Extract host mappings
        if 'infinibox_lun_mapping' in metrics:
            for metric in metrics['infinibox_lun_mapping']:
                labels = metric['labels']
                data['host_mappings'].append({
                    'host_id': labels.get('host_id'),
                    'host_name': labels.get('host_name'),
                    'volume_id': labels.get('volume_id'),
                    'volume_name': labels.get('volume_name'),
                    'lun_id': labels.get('lun_id')
                })
        
        return data
    
    def get_brocade_data(self) -> Dict[str, Any]:
        """Get data from Brocade exporter"""
        metrics = self.scrape_prometheus_metrics(self.config.brocade_exporter_url)
        
        data = {
            'port_wwpns': [],
            'fc_zones': []
        }
        
        # Extract port WWPNs
        # Note: Info metrics have different format in Prometheus
        # We'll need to extract from the exporter endpoint directly
        
        return data
    
    def get_vmware_data(self) -> Dict[str, Any]:
        """Get data from VMware exporter"""
        metrics = self.scrape_prometheus_metrics(self.config.vmware_exporter_url)
        
        data = {
            'hosts': [],
            'datastores': [],
            'vms': []
        }
        
        return data

# ============================================================================
# Topology Correlator
# ============================================================================

class TopologyCorrelator:
    """Main correlation engine"""
    
    def __init__(self, config: CorrelatorConfig):
        self.config = config
        self.db = DatabaseManager(config)
        self.scraper = MetricsScraper(config)
        self.paths = []
        self.lock = Lock()
    
    def start(self):
        """Initialize and start the correlator"""
        logger.info("Starting Topology Correlator")
        
        # Connect to database
        if not self.db.connect():
            logger.error("Cannot start without database connection")
            return False
        
        return True
    
    @topology_correlation_duration.time()
    def correlate_topology(self):
        """Main correlation method - builds complete end-to-end paths"""
        logger.info("Starting topology correlation cycle")
        
        try:
            # 1. Scrape data from all exporters
            infinibox_data = self.scraper.get_infinibox_data()
            brocade_data = self.scraper.get_brocade_data()
            vmware_data = self.scraper.get_vmware_data()
            
            # 2. Store raw data
            for volume in infinibox_data.get('volumes', []):
                vol = InfiniboxVolume(
                    volume_id=volume['volume_id'],
                    volume_name=volume['volume_name'],
                    volume_serial=volume.get('volume_serial', ''),
                    pool_name=volume['pool_name'],
                    size_bytes=volume['size_bytes']
                )
                self.db.store_volume(vol)
            
            for mapping in infinibox_data.get('host_mappings', []):
                map_obj = HostMapping(
                    host_id=mapping['host_id'],
                    host_name=mapping['host_name'],
                    volume_id=mapping['volume_id'],
                    volume_name=mapping['volume_name'],
                    lun_id=mapping['lun_id']
                )
                self.db.store_host_mapping(map_obj)
            
            # 3. Build correlation paths
            # This is where we link: Volume → Host → WWPN → Zone → ESXi → Datastore → VM
            paths = self._build_correlation_paths(infinibox_data, brocade_data, vmware_data)
            
            # 4. Store paths
            for path in paths:
                self.db.store_topology_path(path)
            
            # 5. Update metrics
            with self.lock:
                self.paths = paths
            
            topology_paths_total.set(len(paths))
            topology_volumes_total.set(len(infinibox_data.get('volumes', [])))
            topology_last_update.set(time.time())
            
            logger.info(f"Topology correlation completed: {len(paths)} paths discovered")
            
        except Exception as e:
            logger.error(f"Topology correlation failed: {e}")
            topology_correlation_errors.labels(error_type='correlation_failed').inc()
    
    def _build_correlation_paths(self, infinibox_data, brocade_data, vmware_data) -> List[TopologyPath]:
        """
        Build complete correlation paths
        Algorithm:
        1. For each volume with host mapping
        2. Find host initiator WWPNs
        3. Find FC zones containing those WWPNs
        4. Find ESXi HBAs in the same zones
        5. Find datastores on those ESXi hosts
        6. Find VMs using those datastores
        """
        paths = []
        
        # Create lookup dictionaries
        volume_map = {v['volume_id']: v for v in infinibox_data.get('volumes', [])}
        
        # Process each host mapping
        for mapping in infinibox_data.get('host_mappings', []):
            volume_id = mapping['volume_id']
            volume_name = mapping['volume_name']
            
            if volume_id not in volume_map:
                continue
            
            path = TopologyPath(
                path_id=f"{volume_id}_{mapping['host_id']}",
                volume_name=volume_name,
                volume_id=volume_id,
                host_mappings=[mapping['host_name']],
                fc_zones=[],
                esxi_hosts=[],
                datastores=[],
                vms=[],
                health_status="healthy"
            )
            
            paths.append(path)
        
        return paths
    
    def get_paths(self) -> List[Dict]:
        """Get all current topology paths"""
        with self.lock:
            return [asdict(p) for p in self.paths]
    
    def get_path_by_volume(self, volume_name: str) -> Optional[Dict]:
        """Get path for specific volume"""
        with self.lock:
            for path in self.paths:
                if path.volume_name == volume_name:
                    return asdict(path)
        return None

# ============================================================================
# REST API Routes
# ============================================================================

correlator = None

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "service": "topology-correlator"})

@app.route('/api/v1/topology/paths')
def get_all_paths():
    """Get all topology paths"""
    try:
        paths = correlator.get_paths()
        return jsonify({"paths": paths, "count": len(paths)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/v1/topology/volume/<volume_name>')
def get_path_by_volume(volume_name):
    """Get topology path for specific volume"""
    try:
        path = correlator.get_path_by_volume(volume_name)
        if path:
            return jsonify(path)
        else:
            return jsonify({"error": "Volume not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/v1/topology/vm/<vm_name>')
def get_path_by_vm(vm_name):
    """Get topology path for specific VM"""
    try:
        result = correlator.db.get_path_by_vm(vm_name)
        if result:
            return jsonify({"paths": result})
        else:
            return jsonify({"error": "VM not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/metrics')
def metrics():
    """Prometheus metrics endpoint"""
    return Response(generate_latest(REGISTRY), mimetype='text/plain')

# ============================================================================
# Main
# ============================================================================

def correlation_loop(correlator: TopologyCorrelator):
    """Background correlation loop"""
    while True:
        try:
            correlator.correlate_topology()
        except Exception as e:
            logger.error(f"Error in correlation loop: {e}")
        
        time.sleep(correlator.config.correlation_interval)

def main():
    global correlator
    
    logger.info("Starting Topology Correlation Service")
    
    # Load configuration
    config_path = os.getenv('CONFIG_FILE', '/app/config.yml')
    if os.path.exists(config_path):
        config = CorrelatorConfig.from_file(config_path)
    else:
        config = CorrelatorConfig.from_env()
    
    # Initialize correlator
    correlator = TopologyCorrelator(config)
    
    if not correlator.start():
        logger.error("Failed to start correlator")
        sys.exit(1)
    
    # Set service info
    topology_correlator_info.info({
        'version': '1.0.0',
        'build_date': '2025-10-22',
        'correlation_interval': str(config.correlation_interval)
    })
    
    # Start correlation thread
    correlation_thread = Thread(target=correlation_loop, args=(correlator,), daemon=True)
    correlation_thread.start()
    
    # Start API server
    logger.info(f"Starting API server on port {config.api_port}")
    logger.info(f"API endpoints available at http://0.0.0.0:{config.api_port}/api/v1/topology/")
    logger.info(f"Metrics available at http://0.0.0.0:{config.api_port}/metrics")
    
    app.run(host='0.0.0.0', port=config.api_port, debug=False)

if __name__ == '__main__':
    main()
