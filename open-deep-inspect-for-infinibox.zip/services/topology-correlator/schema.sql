-- ============================================================================
-- Topology Database Schema
-- Infinidat Professional Services for Hollywoodbets
-- ============================================================================
-- 
-- This schema stores the complete end-to-end topology:
-- Infinibox Volume → WWPN → FC Zone → ESXi HBA → Datastore → VM
--

-- Create database (run as postgres user)
-- CREATE DATABASE topology;
-- CREATE USER topology_user WITH PASSWORD 'changeme';
-- GRANT ALL PRIVILEGES ON DATABASE topology TO topology_user;

\c topology

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- Infinibox Tables
-- ============================================================================

-- Volumes table
CREATE TABLE IF NOT EXISTS volumes (
    volume_id VARCHAR(64) PRIMARY KEY,
    volume_name VARCHAR(255) NOT NULL,
    volume_serial VARCHAR(128),
    pool_name VARCHAR(255),
    size_bytes BIGINT,
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_volumes_name ON volumes(volume_name);
CREATE INDEX idx_volumes_serial ON volumes(volume_serial);
CREATE INDEX idx_volumes_last_seen ON volumes(last_seen);

-- Volume WWPNs (for FC volumes)
CREATE TABLE IF NOT EXISTS volume_wwpns (
    id SERIAL PRIMARY KEY,
    volume_id VARCHAR(64) REFERENCES volumes(volume_id) ON DELETE CASCADE,
    wwpn VARCHAR(23) NOT NULL,  -- Format: XX:XX:XX:XX:XX:XX:XX:XX
    port_type VARCHAR(16) DEFAULT 'fc',
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(volume_id, wwpn)
);

CREATE INDEX idx_volume_wwpns_wwpn ON volume_wwpns(wwpn);
CREATE INDEX idx_volume_wwpns_volume ON volume_wwpns(volume_id);

-- Volume IQNs (for iSCSI volumes)
CREATE TABLE IF NOT EXISTS volume_iqns (
    id SERIAL PRIMARY KEY,
    volume_id VARCHAR(64) REFERENCES volumes(volume_id) ON DELETE CASCADE,
    iqn VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(volume_id, iqn)
);

CREATE INDEX idx_volume_iqns_iqn ON volume_iqns(iqn);

-- Hosts (registered in Infinibox)
CREATE TABLE IF NOT EXISTS hosts (
    host_id VARCHAR(64) PRIMARY KEY,
    host_name VARCHAR(255) NOT NULL,
    host_type VARCHAR(64),
    operating_system VARCHAR(128),
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_hosts_name ON hosts(host_name);

-- Host Initiators (WWPNs and IQNs)
CREATE TABLE IF NOT EXISTS host_initiators (
    id SERIAL PRIMARY KEY,
    host_id VARCHAR(64) REFERENCES hosts(host_id) ON DELETE CASCADE,
    initiator_type VARCHAR(16) NOT NULL,  -- 'fc' or 'iscsi'
    initiator_address VARCHAR(255) NOT NULL,  -- WWPN or IQN
    state VARCHAR(32),
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(host_id, initiator_address)
);

CREATE INDEX idx_host_initiators_address ON host_initiators(initiator_address);
CREATE INDEX idx_host_initiators_type ON host_initiators(initiator_type);

-- Host to Volume Mappings (LUNs)
CREATE TABLE IF NOT EXISTS host_mappings (
    id SERIAL PRIMARY KEY,
    host_id VARCHAR(64) REFERENCES hosts(host_id) ON DELETE CASCADE,
    host_name VARCHAR(255),
    volume_id VARCHAR(64) REFERENCES volumes(volume_id) ON DELETE CASCADE,
    lun_id VARCHAR(16),
    mapping_state VARCHAR(32) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(host_id, volume_id)
);

CREATE INDEX idx_host_mappings_host ON host_mappings(host_id);
CREATE INDEX idx_host_mappings_volume ON host_mappings(volume_id);
CREATE INDEX idx_host_mappings_lun ON host_mappings(lun_id);

-- ============================================================================
-- Fibre Channel SAN Tables
-- ============================================================================

-- FC Switches
CREATE TABLE IF NOT EXISTS fc_switches (
    switch_id VARCHAR(64) PRIMARY KEY,
    switch_name VARCHAR(255) NOT NULL,
    switch_ip VARCHAR(45),
    vendor VARCHAR(64) DEFAULT 'Brocade',
    model VARCHAR(128),
    firmware_version VARCHAR(64),
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_fc_switches_name ON fc_switches(switch_name);

-- FC Switch Ports
CREATE TABLE IF NOT EXISTS fc_ports (
    id SERIAL PRIMARY KEY,
    switch_id VARCHAR(64) REFERENCES fc_switches(switch_id) ON DELETE CASCADE,
    port_index VARCHAR(16) NOT NULL,
    port_wwpn VARCHAR(23),  -- Format: XX:XX:XX:XX:XX:XX:XX:XX
    port_name VARCHAR(255),
    port_state VARCHAR(32),
    port_speed_gbps INTEGER,
    connected_wwpn VARCHAR(23),
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(switch_id, port_index)
);

CREATE INDEX idx_fc_ports_wwpn ON fc_ports(port_wwpn);
CREATE INDEX idx_fc_ports_connected ON fc_ports(connected_wwpn);
CREATE INDEX idx_fc_ports_switch ON fc_ports(switch_id);

-- FC Zone Sets
CREATE TABLE IF NOT EXISTS fc_zonesets (
    id SERIAL PRIMARY KEY,
    zoneset_name VARCHAR(255) NOT NULL,
    switch_id VARCHAR(64) REFERENCES fc_switches(switch_id) ON DELETE CASCADE,
    is_active BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(zoneset_name, switch_id)
);

CREATE INDEX idx_fc_zonesets_name ON fc_zonesets(zoneset_name);
CREATE INDEX idx_fc_zonesets_active ON fc_zonesets(is_active);

-- FC Zones
CREATE TABLE IF NOT EXISTS fc_zones (
    id SERIAL PRIMARY KEY,
    zone_name VARCHAR(255) NOT NULL,
    zoneset_name VARCHAR(255) NOT NULL,
    switch_name VARCHAR(255) NOT NULL,
    zone_type VARCHAR(32) DEFAULT 'standard',
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(zone_name, switch_name)
);

CREATE INDEX idx_fc_zones_name ON fc_zones(zone_name);
CREATE INDEX idx_fc_zones_zoneset ON fc_zones(zoneset_name);

-- FC Zone Members (WWPNs in each zone)
CREATE TABLE IF NOT EXISTS fc_zone_members (
    id SERIAL PRIMARY KEY,
    zone_name VARCHAR(255) NOT NULL,
    switch_name VARCHAR(255) NOT NULL,
    member_wwpn VARCHAR(23) NOT NULL,
    member_type VARCHAR(32) DEFAULT 'wwpn',
    alias_name VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(zone_name, switch_name, member_wwpn)
);

CREATE INDEX idx_fc_zone_members_wwpn ON fc_zone_members(member_wwpn);
CREATE INDEX idx_fc_zone_members_zone ON fc_zone_members(zone_name);

-- ============================================================================
-- VMware Tables
-- ============================================================================

-- ESXi Hosts
CREATE TABLE IF NOT EXISTS esxi_hosts (
    host_id VARCHAR(64) PRIMARY KEY,
    host_name VARCHAR(255) NOT NULL,
    host_ip VARCHAR(45),
    vcenter VARCHAR(255),
    cluster_name VARCHAR(255),
    version VARCHAR(64),
    build VARCHAR(64),
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_esxi_hosts_name ON esxi_hosts(host_name);
CREATE INDEX idx_esxi_hosts_cluster ON esxi_hosts(cluster_name);

-- ESXi HBAs (Host Bus Adapters)
CREATE TABLE IF NOT EXISTS esxi_hbas (
    id SERIAL PRIMARY KEY,
    host_id VARCHAR(64) REFERENCES esxi_hosts(host_id) ON DELETE CASCADE,
    hba_device VARCHAR(64) NOT NULL,
    hba_wwpn VARCHAR(23),  -- Format: XX:XX:XX:XX:XX:XX:XX:XX
    hba_type VARCHAR(32),
    driver VARCHAR(128),
    status VARCHAR(32),
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(host_id, hba_device)
);

CREATE INDEX idx_esxi_hbas_wwpn ON esxi_hbas(hba_wwpn);
CREATE INDEX idx_esxi_hbas_host ON esxi_hbas(host_id);

-- Datastores
CREATE TABLE IF NOT EXISTS datastores (
    datastore_id VARCHAR(64) PRIMARY KEY,
    datastore_name VARCHAR(255) NOT NULL,
    datastore_type VARCHAR(32),  -- 'VMFS', 'NFS', 'vVol'
    capacity_bytes BIGINT,
    free_bytes BIGINT,
    lun_id VARCHAR(16),
    naa_id VARCHAR(128),  -- NAA identifier for LUN
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_datastores_name ON datastores(datastore_name);
CREATE INDEX idx_datastores_naa ON datastores(naa_id);

-- Datastore to ESXi Host Mapping
CREATE TABLE IF NOT EXISTS datastore_mounts (
    id SERIAL PRIMARY KEY,
    datastore_id VARCHAR(64) REFERENCES datastores(datastore_id) ON DELETE CASCADE,
    host_id VARCHAR(64) REFERENCES esxi_hosts(host_id) ON DELETE CASCADE,
    mount_path VARCHAR(512),
    accessible BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(datastore_id, host_id)
);

CREATE INDEX idx_datastore_mounts_ds ON datastore_mounts(datastore_id);
CREATE INDEX idx_datastore_mounts_host ON datastore_mounts(host_id);

-- Virtual Machines
CREATE TABLE IF NOT EXISTS vms (
    vm_id VARCHAR(64) PRIMARY KEY,
    vm_name VARCHAR(255) NOT NULL,
    vm_uuid VARCHAR(64),
    host_id VARCHAR(64) REFERENCES esxi_hosts(host_id),
    datastore_id VARCHAR(64) REFERENCES datastores(datastore_id),
    power_state VARCHAR(32),
    guest_os VARCHAR(128),
    cpu_count INTEGER,
    memory_mb BIGINT,
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX idx_vms_name ON vms(vm_name);
CREATE INDEX idx_vms_host ON vms(host_id);
CREATE INDEX idx_vms_datastore ON vms(datastore_id);

-- ============================================================================
-- Network Topology Tables (for iSCSI/NFS)
-- ============================================================================

-- Network Switches
CREATE TABLE IF NOT EXISTS network_switches (
    switch_id VARCHAR(64) PRIMARY KEY,
    switch_name VARCHAR(255) NOT NULL,
    switch_ip VARCHAR(45),
    vendor VARCHAR(64),
    model VARCHAR(128),
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW()
);

-- LLDP Neighbors (for network topology)
CREATE TABLE IF NOT EXISTS lldp_neighbors (
    id SERIAL PRIMARY KEY,
    local_device VARCHAR(255) NOT NULL,
    local_port VARCHAR(128) NOT NULL,
    remote_device VARCHAR(255) NOT NULL,
    remote_port VARCHAR(128) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(local_device, local_port, remote_device, remote_port)
);

CREATE INDEX idx_lldp_local ON lldp_neighbors(local_device, local_port);
CREATE INDEX idx_lldp_remote ON lldp_neighbors(remote_device, remote_port);

-- ============================================================================
-- Correlation and Path Tables
-- ============================================================================

-- Complete topology paths (pre-computed for fast queries)
CREATE TABLE IF NOT EXISTS topology_paths (
    path_id VARCHAR(128) PRIMARY KEY,
    volume_name VARCHAR(255) NOT NULL,
    volume_id VARCHAR(64) REFERENCES volumes(volume_id) ON DELETE CASCADE,
    path_data JSONB NOT NULL,  -- Complete path stored as JSON
    health_status VARCHAR(32) DEFAULT 'healthy',
    last_update TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_topology_paths_volume ON topology_paths(volume_id);
CREATE INDEX idx_topology_paths_name ON topology_paths(volume_name);
CREATE INDEX idx_topology_paths_health ON topology_paths(health_status);
CREATE INDEX idx_topology_paths_data ON topology_paths USING gin(path_data);

-- Path relationships (for graph queries)
CREATE TABLE IF NOT EXISTS path_relationships (
    id SERIAL PRIMARY KEY,
    source_type VARCHAR(32) NOT NULL,  -- 'volume', 'host', 'zone', 'hba', 'datastore', 'vm'
    source_id VARCHAR(128) NOT NULL,
    target_type VARCHAR(32) NOT NULL,
    target_id VARCHAR(128) NOT NULL,
    relationship_type VARCHAR(64) NOT NULL,  -- 'mapped_to', 'in_zone', 'connected_to', 'mounted_on', 'runs_on'
    created_at TIMESTAMP DEFAULT NOW(),
    last_seen TIMESTAMP DEFAULT NOW(),
    UNIQUE(source_type, source_id, target_type, target_id, relationship_type)
);

CREATE INDEX idx_path_rel_source ON path_relationships(source_type, source_id);
CREATE INDEX idx_path_rel_target ON path_relationships(target_type, target_id);
CREATE INDEX idx_path_rel_type ON path_relationships(relationship_type);

-- ============================================================================
-- Views for Common Queries
-- ============================================================================

-- Complete path view (Volume → VM)
CREATE OR REPLACE VIEW v_complete_paths AS
SELECT 
    v.volume_id,
    v.volume_name,
    v.pool_name,
    v.size_bytes,
    hm.host_id,
    hm.host_name,
    hm.lun_id,
    ds.datastore_id,
    ds.datastore_name,
    vm.vm_id,
    vm.vm_name,
    vm.power_state,
    vm.guest_os
FROM volumes v
LEFT JOIN host_mappings hm ON v.volume_id = hm.volume_id
LEFT JOIN esxi_hosts eh ON LOWER(eh.host_name) = LOWER(hm.host_name)
LEFT JOIN vms vm ON eh.host_id = vm.host_id
LEFT JOIN datastores ds ON vm.datastore_id = ds.datastore_id
WHERE v.last_seen > NOW() - INTERVAL '24 hours';

-- FC topology view (Infinibox → Zone → ESXi)
CREATE OR REPLACE VIEW v_fc_topology AS
SELECT 
    v.volume_name,
    vw.wwpn as volume_wwpn,
    hi.initiator_address as host_initiator_wwpn,
    h.host_name as infinibox_host,
    fz.zone_name,
    fz.switch_name,
    eh.host_name as esxi_host,
    ehba.hba_wwpn as esxi_hba_wwpn
FROM volumes v
JOIN volume_wwpns vw ON v.volume_id = vw.volume_id
JOIN host_mappings hm ON v.volume_id = hm.volume_id
JOIN hosts h ON hm.host_id = h.host_id
JOIN host_initiators hi ON h.host_id = hi.host_id AND hi.initiator_type = 'fc'
LEFT JOIN fc_zone_members fzm ON hi.initiator_address = fzm.member_wwpn
LEFT JOIN fc_zones fz ON fzm.zone_name = fz.zone_name
LEFT JOIN fc_zone_members fzm2 ON fz.zone_name = fzm2.zone_name AND fzm2.member_wwpn != hi.initiator_address
LEFT JOIN esxi_hbas ehba ON fzm2.member_wwpn = ehba.hba_wwpn
LEFT JOIN esxi_hosts eh ON ehba.host_id = eh.host_id;

-- ============================================================================
-- Helper Functions
-- ============================================================================

-- Function to clean up old data
CREATE OR REPLACE FUNCTION cleanup_old_data(retention_days INTEGER DEFAULT 7)
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER := 0;
BEGIN
    -- Delete old path data
    DELETE FROM topology_paths WHERE last_update < NOW() - (retention_days || ' days')::INTERVAL;
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    -- Clean up orphaned relationships
    DELETE FROM path_relationships WHERE last_seen < NOW() - (retention_days || ' days')::INTERVAL;
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Function to find path for VM
CREATE OR REPLACE FUNCTION get_path_for_vm(vm_name_param VARCHAR)
RETURNS TABLE (
    volume_name VARCHAR,
    datastore_name VARCHAR,
    host_name VARCHAR,
    path_json JSONB
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        v.volume_name,
        ds.datastore_name,
        eh.host_name,
        tp.path_data as path_json
    FROM vms vm
    JOIN datastores ds ON vm.datastore_id = ds.datastore_id
    JOIN esxi_hosts eh ON vm.host_id = eh.host_id
    LEFT JOIN topology_paths tp ON tp.path_data::jsonb @> jsonb_build_object('vms', jsonb_build_array(vm.vm_name))
    LEFT JOIN volumes v ON tp.volume_id = v.volume_id
    WHERE vm.vm_name = vm_name_param;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- Initial Data and Grants
-- ============================================================================

-- Grant permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO topology_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO topology_user;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO topology_user;

-- Create indexes for performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_volumes_metadata ON volumes USING gin(metadata);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_hosts_metadata ON hosts USING gin(metadata);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_datastores_metadata ON datastores USING gin(metadata);

-- ============================================================================
-- Monitoring and Maintenance
-- ============================================================================

-- Table to track correlation runs
CREATE TABLE IF NOT EXISTS correlation_runs (
    id SERIAL PRIMARY KEY,
    run_timestamp TIMESTAMP DEFAULT NOW(),
    duration_seconds FLOAT,
    paths_discovered INTEGER,
    errors INTEGER,
    status VARCHAR(32)
);

CREATE INDEX idx_correlation_runs_timestamp ON correlation_runs(run_timestamp);

-- Insert initial run
INSERT INTO correlation_runs (run_timestamp, duration_seconds, paths_discovered, errors, status)
VALUES (NOW(), 0, 0, 0, 'initialized');

-- ============================================================================
-- Schema Version
-- ============================================================================

CREATE TABLE IF NOT EXISTS schema_version (
    version VARCHAR(16) PRIMARY KEY,
    applied_at TIMESTAMP DEFAULT NOW(),
    description TEXT
);

INSERT INTO schema_version (version, description) 
VALUES ('1.0.0', 'Initial schema for end-to-end topology visualization')
ON CONFLICT (version) DO NOTHING;

-- ============================================================================
-- Complete
-- ============================================================================

-- Summary
DO $$
DECLARE
    table_count INTEGER;
    index_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO table_count FROM information_schema.tables WHERE table_schema = 'public' AND table_type = 'BASE TABLE';
    SELECT COUNT(*) INTO index_count FROM pg_indexes WHERE schemaname = 'public';
    
    RAISE NOTICE 'Topology database schema initialized successfully!';
    RAISE NOTICE 'Tables created: %', table_count;
    RAISE NOTICE 'Indexes created: %', index_count;
    RAISE NOTICE '';
    RAISE NOTICE 'Schema version: 1.0.0';
    RAISE NOTICE 'Ready for topology correlation service.';
END $$;
