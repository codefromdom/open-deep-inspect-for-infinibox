#!/bin/bash
#
# Capacity Analysis and Forecasting
# Open Source Community
#

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
OUTPUT_DIR="${SCRIPT_DIR}/../../output"
mkdir -p "$OUTPUT_DIR"

REPORT_FILE="$OUTPUT_DIR/capacity_analysis_$(date +%Y%m%d_%H%M%S).txt"

echo "==========================================="
echo "Capacity Analysis"
echo "Open Source Community"
echo "==========================================="
echo

{
    echo "Capacity Analysis Report"
    echo "========================"
    echo "Time: $(date)"
    echo
    
    echo "1. Infinibox Storage Capacity"
    echo "----------------------------------------------"
    curl -s "http://localhost:8428/api/v1/query?query=infinibox_pool_total_capacity_bytes" | jq -r '.data.result[] | "Pool \(.metric.pool_name): \((.value[1] | tonumber / 1099511627776 | floor))TB total"'
    echo
    curl -s "http://localhost:8428/api/v1/query?query=infinibox_pool_free_capacity_bytes" | jq -r '.data.result[] | "Pool \(.metric.pool_name): \((.value[1] | tonumber / 1099511627776 | floor))TB free"'
    echo
    
    echo "2. VMware Datastore Capacity"
    echo "----------------------------------------------"
    curl -s "http://localhost:8428/api/v1/query?query=vmware_datastore_capacity_gb" | jq -r '.data.result[] | "Datastore \(.metric.datastore_name): \(.value[1])GB total"'
    echo
    curl -s "http://localhost:8428/api/v1/query?query=vmware_datastore_used_percent" | jq -r '.data.result[] | "Datastore \(.metric.datastore_name): \(.value[1])% used"'
    echo
    
    echo "3. Growth Trend Analysis (7-day)"
    echo "----------------------------------------------"
    echo "Analyzing storage growth over past 7 days..."
    
    # Calculate growth rate
    CURRENT=$(curl -s "http://localhost:8428/api/v1/query?query=infinibox_pool_used_capacity_bytes" | jq -r '.data.result[0].value[1] // 0')
    WEEK_AGO=$(curl -s "http://localhost:8428/api/v1/query?query=infinibox_pool_used_capacity_bytes&time=$(($(date +%s) - 604800))" | jq -r '.data.result[0].value[1] // 0')
    
    if [ "$CURRENT" != "0" ] && [ "$WEEK_AGO" != "0" ]; then
        GROWTH=$(echo "scale=2; ($CURRENT - $WEEK_AGO) / $WEEK_AGO * 100" | bc)
        echo "Storage growth: ${GROWTH}% over 7 days"
        
        # Forecast days until 80% capacity
        FREE=$(curl -s "http://localhost:8428/api/v1/query?query=infinibox_pool_free_capacity_bytes" | jq -r '.data.result[0].value[1] // 0')
        DAILY_GROWTH=$(echo "scale=2; ($CURRENT - $WEEK_AGO) / 7" | bc)
        
        if [ "$(echo "$DAILY_GROWTH > 0" | bc)" -eq 1 ]; then
            DAYS_TO_80=$(echo "scale=0; ($FREE * 0.2) / $DAILY_GROWTH" | bc)
            echo "Estimated days until 80% capacity: $DAYS_TO_80 days"
        fi
    fi
    
    echo
    echo "4. Recommendations"
    echo "----------------------------------------------"
    echo "- Monitor capacity weekly"
    echo "- Plan expansion when free space < 20%"
    echo "- Review data reduction ratios"
    echo "- Consider snapshot retention policies"
    
} | tee "$REPORT_FILE"

echo
echo "Report saved to: $REPORT_FILE"
