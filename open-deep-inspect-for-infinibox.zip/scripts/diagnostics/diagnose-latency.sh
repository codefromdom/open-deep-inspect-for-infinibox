#!/bin/bash
#
# End-to-End Latency Diagnostics
# Open Source Community
#
# Diagnoses latency issues across the entire stack:
# VM → ESXi → FC Network → Infinibox
#

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
OUTPUT_DIR="${SCRIPT_DIR}/../../output"
mkdir -p "$OUTPUT_DIR"

REPORT_FILE="$OUTPUT_DIR/latency_diagnostic_$(date +%Y%m%d_%H%M%S).txt"

echo "==========================================="
echo "End-to-End Latency Diagnostic"
echo "Open Source Community"
echo "==========================================="
echo

# Check if VM name provided
if [ -z "$1" ]; then
    echo "Usage: $0 <vm-name>"
    echo
    echo "This script diagnoses latency issues for a specific VM"
    exit 1
fi

VM_NAME="$1"

{
    echo "Latency Diagnostic Report"
    echo "========================="
    echo "VM: $VM_NAME"
    echo "Time: $(date)"
    echo
    
    echo "1. Querying VictoriaMetrics for VM metrics..."
    echo "----------------------------------------------"
    
    # Query VM CPU ready time
    echo "VM CPU Ready Time:"
    curl -s "http://localhost:8428/api/v1/query?query=vmware_vm_cpu_usage_mhz{vm_name=\"$VM_NAME\"}" | jq -r '.data.result[0].value[1] // "N/A"'
    echo
    
    # Query VM disk latency
    echo "VM Disk Usage:"
    curl -s "http://localhost:8428/api/v1/query?query=vmware_vm_disk_usage_kb{vm_name=\"$VM_NAME\"}" | jq -r '.data.result[0].value[1] // "N/A"'
    echo
    
    echo "2. Checking ESXi Host Metrics..."
    echo "----------------------------------------------"
    
    # Get host name for the VM
    HOST_NAME=$(curl -s "http://localhost:8428/api/v1/query?query=vmware_vm_status{vm_name=\"$VM_NAME\"}" | jq -r '.data.result[0].metric.host_name // "unknown"')
    echo "Host: $HOST_NAME"
    
    # Query host CPU
    echo "Host CPU Usage:"
    curl -s "http://localhost:8428/api/v1/query?query=vmware_host_cpu_usage_mhz{host_name=\"$HOST_NAME\"}" | jq -r '.data.result[0].value[1] // "N/A"'
    echo
    
    echo "3. Checking Storage Latency..."
    echo "----------------------------------------------"
    
    # Query Infinibox volume latency
    echo "Infinibox Volume Latency (ms):"
    curl -s "http://localhost:8428/api/v1/query?query=infinibox_volume_latency_read_ms" | jq -r '.data.result[] | "\(.metric.volume_name): \(.value[1])ms"'
    echo
    
    echo "4. Checking FC Network..."
    echo "----------------------------------------------"
    
    # Query Brocade port errors
    echo "Brocade Port Errors (last 5 min):"
    curl -s "http://localhost:8428/api/v1/query?query=rate(brocade_port_errors_total[5m])" | jq -r '.data.result[] | "\(.metric.switch_name):\(.metric.port_index) - \(.value[1]) errors/s"'
    echo
    
    echo "5. Summary and Recommendations"
    echo "----------------------------------------------"
    echo "Review the metrics above to identify latency bottlenecks:"
    echo "  - High CPU ready time → CPU contention on host"
    echo "  - High storage latency → Check Infinibox and FC network"
    echo "  - FC port errors → Cable or transceiver issues"
    echo
    echo "For detailed analysis, access Grafana dashboard:"
    echo "  http://localhost:3000/d/correlation"
    
} | tee "$REPORT_FILE"

echo
echo "Report saved to: $REPORT_FILE"
