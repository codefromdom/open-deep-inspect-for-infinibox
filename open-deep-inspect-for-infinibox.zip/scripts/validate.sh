#!/bin/bash
#
# Comprehensive Validation Script
# Open Source Community
#
# Validates entire monitoring stack configuration and connectivity
#

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ERRORS=0
WARNINGS=0

print_success() { echo -e "${GREEN}✅ $1${NC}"; }
print_error() { echo -e "${RED}❌ $1${NC}"; ERRORS=$((ERRORS+1)); }
print_warning() { echo -e "${YELLOW}⚠️  $1${NC}"; WARNINGS=$((WARNINGS+1)); }
print_info() { echo -e "${GREEN}ℹ️  $1${NC}"; }

echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}Monitoring Stack Validation${NC}"
echo -e "${GREEN}Open Source Community${NC}"
echo -e "${GREEN}============================================${NC}"
echo

cd "$PROJECT_DIR"

# ============================================================================
# 1. Configuration File Validation
# ============================================================================

echo "1. Validating Configuration Files"
echo "=================================="
echo

# Check .env file
if [ -f ".env" ]; then
    print_success ".env file exists"
    
    # Check required variables
    required_vars=("GRAFANA_ADMIN_PASSWORD" "INFINIBOX_HOST" "INFINIBOX_USER" "INFINIBOX_PASSWORD" "VCENTER_HOST" "VCENTER_USER" "VCENTER_PASSWORD")
    for var in "${required_vars[@]}"; do
        if grep -q "^${var}=" .env && ! grep -q "^${var}=changeme" .env; then
            print_success "  $var is configured"
        else
            print_error "  $var is not configured or uses default value"
        fi
    done
else
    print_error ".env file not found"
fi

echo

# Check config files
config_files=("config/infinidat.yml" "config/vmware.yml" "config/brocade.yml" "config/juniper.yml")
for config in "${config_files[@]}"; do
    if [ -f "$config" ]; then
        print_success "$config exists"
    else
        print_error "$config not found"
    fi
done

echo

# ============================================================================
# 2. Docker Environment Validation
# ============================================================================

echo "2. Validating Docker Environment"
echo "================================="
echo

# Check Docker
if command -v docker &> /dev/null; then
    print_success "Docker is installed"
    docker --version
else
    print_error "Docker is not installed"
fi

echo

# Check Docker Compose
if command -v docker-compose &> /dev/null || docker compose version &> /dev/null; then
    print_success "Docker Compose is available"
    docker-compose --version 2>/dev/null || docker compose version
else
    print_error "Docker Compose is not installed"
fi

echo

# ============================================================================
# 3. Container Status Validation
# ============================================================================

echo "3. Validating Container Status"
echo "==============================="
echo

containers=("victoriametrics" "prometheus" "grafana" "infinidat-exporter" "vmware-exporter" "brocade-exporter" "juniper-exporter")

for container in "${containers[@]}"; do
    if docker-compose ps | grep "org-$container" | grep -q "Up"; then
        print_success "$container is running"
    else
        print_error "$container is not running"
    fi
done

echo

# ============================================================================
# 4. Network Connectivity Validation
# ============================================================================

echo "4. Validating Network Connectivity"
echo "==================================="
echo

# Check if containers can reach each other
print_info "Testing internal network connectivity..."

if docker exec org-prometheus curl -s http://victoriametrics:8428/health &> /dev/null; then
    print_success "Prometheus → VictoriaMetrics: OK"
else
    print_error "Prometheus → VictoriaMetrics: FAILED"
fi

if docker exec org-grafana curl -s http://prometheus:9090/-/healthy &> /dev/null; then
    print_success "Grafana → Prometheus: OK"
else
    print_error "Grafana → Prometheus: FAILED"
fi

echo

# ============================================================================
# 5. Exporter Health Validation
# ============================================================================

echo "5. Validating Exporter Health"
echo "==============================="
echo

# Check each exporter health endpoint
exporters=(
    "9600:Infinidat"
    "9601:VMware"
    "9602:Brocade"
    "9603:Juniper"
)

for exporter in "${exporters[@]}"; do
    port="${exporter%%:*}"
    name="${exporter##*:}"
    
    if curl -s -f "http://localhost:$port/health" &> /dev/null; then
        print_success "$name exporter health check: OK"
    else
        print_error "$name exporter health check: FAILED"
    fi
done

echo

# ============================================================================
# 6. Metrics Collection Validation
# ============================================================================

echo "6. Validating Metrics Collection"
echo "================================="
echo

# Check if metrics are being collected
print_info "Checking if metrics are available..."

if curl -s "http://localhost:9090/api/v1/query?query=up" | grep -q '"status":"success"'; then
    print_success "Prometheus is collecting metrics"
else
    print_error "Prometheus is not collecting metrics"
fi

# Check specific metrics
metrics_to_check=(
    "infinibox_system_status:Infinibox"
    "vmware_host_status:VMware"
    "brocade_switch_status:Brocade"
    "juniper_switch_status:Juniper"
)

for metric in "${metrics_to_check[@]}"; do
    metric_name="${metric%%:*}"
    component="${metric##*:}"
    
    result=$(curl -s "http://localhost:9090/api/v1/query?query=$metric_name" | jq -r '.data.result | length')
    
    if [ "$result" -gt 0 ] 2>/dev/null; then
        print_success "$component metrics are being collected ($result series)"
    else
        print_warning "$component metrics not found (may not be configured yet)"
    fi
done

echo

# ============================================================================
# 7. Grafana Dashboard Validation
# ============================================================================

echo "7. Validating Grafana"
echo "====================="
echo

# Check Grafana API
if curl -s "http://localhost:3000/api/health" | grep -q "ok"; then
    print_success "Grafana API is responding"
else
    print_error "Grafana API is not responding"
fi

# Check if dashboards exist
dashboard_count=$(ls -1 grafana/dashboards/*.json 2>/dev/null | wc -l)
if [ "$dashboard_count" -gt 0 ]; then
    print_success "$dashboard_count dashboard(s) available"
else
    print_warning "No dashboards found in grafana/dashboards/"
fi

echo

# ============================================================================
# 8. Alert Rules Validation
# ============================================================================

echo "8. Validating Alert Rules"
echo "========================="
echo

# Check if alert rules are loaded
if curl -s "http://localhost:9090/api/v1/rules" | jq -r '.data.groups | length' | grep -q '[1-9]'; then
    print_success "Alert rules are loaded"
    
    # Count rules
    rule_count=$(curl -s "http://localhost:9090/api/v1/rules" | jq -r '[.data.groups[].rules[]] | length')
    print_info "  Total rules: $rule_count"
else
    print_warning "No alert rules loaded"
fi

echo

# ============================================================================
# 9. Storage Validation
# ============================================================================

echo "9. Validating Storage"
echo "====================="
echo

# Check VictoriaMetrics data directory
vm_data_size=$(docker exec org-victoriametrics du -sh /victoria-metrics-data 2>/dev/null | awk '{print $1}')
if [ -n "$vm_data_size" ]; then
    print_success "VictoriaMetrics data directory: $vm_data_size"
else
    print_warning "Cannot check VictoriaMetrics data size"
fi

echo

# ============================================================================
# Summary
# ============================================================================

echo "=========================================="
echo "Validation Summary"
echo "=========================================="
echo

if [ $ERRORS -eq 0 ]; then
    print_success "All validations passed!"
    echo
    echo "Your monitoring stack is ready for production use."
    echo
    echo "Next steps:"
    echo "  1. Access Grafana: http://localhost:3000"
    echo "  2. Access Prometheus: http://localhost:9090"
    echo "  3. Review dashboards and configure alerts"
    echo "  4. Set up backup schedule: ./scripts/backup.sh"
    EXIT_CODE=0
else
    print_error "Validation completed with $ERRORS error(s) and $WARNINGS warning(s)"
    echo
    echo "Please review the errors above and fix configuration issues."
    echo
    echo "Common issues:"
    echo "  - Missing or incorrect credentials in .env"
    echo "  - Services not started: docker-compose up -d"
    echo "  - Network connectivity to monitored devices"
    echo "  - Insufficient permissions for monitoring accounts"
    echo
    echo "For help, see: docs/TROUBLESHOOTING.md"
    EXIT_CODE=1
fi

exit $EXIT_CODE
