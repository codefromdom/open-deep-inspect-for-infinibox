
#!/bin/bash
################################################################################
# Prerequisites Installation Script
# Open Source Community
# 
# Installs Docker, Docker Compose, and system dependencies
################################################################################

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo "================================================================================"
echo "  Prerequisites Installation for open-deep-inspect-for-infinibox"
echo "  Open Source Community"
echo "================================================================================"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    log_error "Please run as root: sudo $0"
    exit 1
fi

################################################################################
# Detect OS
################################################################################

if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
    OS_VERSION=$VERSION_ID
else
    log_error "Cannot detect OS"
    exit 1
fi

log_info "Detected OS: $OS $OS_VERSION"

################################################################################
# Install Docker
################################################################################

log_info "Installing Docker..."

if command -v docker &> /dev/null; then
    log_info "Docker already installed: $(docker --version)"
else
    case "$OS" in
        ubuntu|debian)
            apt-get update
            apt-get install -y apt-transport-https ca-certificates curl software-properties-common
            curl -fsSL https://download.docker.com/linux/$OS/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
            echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/$OS $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
            apt-get update
            apt-get install -y docker-ce docker-ce-cli containerd.io
            ;;
        centos|rhel|fedora)
            yum install -y yum-utils
            yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
            yum install -y docker-ce docker-ce-cli containerd.io
            ;;
        *)
            log_error "Unsupported OS: $OS"
            exit 1
            ;;
    esac
    
    systemctl start docker
    systemctl enable docker
    log_success "Docker installed and started"
fi

################################################################################
# Install Docker Compose
################################################################################

log_info "Installing Docker Compose..."

if command -v docker-compose &> /dev/null; then
    log_info "Docker Compose already installed: $(docker-compose --version)"
else
    DOCKER_COMPOSE_VERSION="2.23.0"
    curl -L "https://github.com/docker/compose/releases/download/v${DOCKER_COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    ln -sf /usr/local/bin/docker-compose /usr/bin/docker-compose
    log_success "Docker Compose installed"
fi

################################################################################
# Install System Dependencies
################################################################################

log_info "Installing system dependencies..."

case "$OS" in
    ubuntu|debian)
        apt-get install -y curl wget git net-tools dnsutils
        ;;
    centos|rhel|fedora)
        yum install -y curl wget git net-tools bind-utils
        ;;
esac

log_success "System dependencies installed"

################################################################################
# Configure System Settings
################################################################################

log_info "Configuring system settings..."

# Increase file limits
cat > /etc/security/limits.d/monitoring.conf << EOF
* soft nofile 65536
* hard nofile 65536
* soft nproc 65536
* hard nproc 65536
EOF

# Configure sysctl for monitoring
cat > /etc/sysctl.d/99-monitoring.conf << EOF
# Network settings for monitoring
net.core.somaxconn = 1024
net.ipv4.tcp_max_syn_backlog = 2048
net.core.netdev_max_backlog = 2048

# File descriptor limits
fs.file-max = 2097152
EOF

sysctl -p /etc/sysctl.d/99-monitoring.conf > /dev/null 2>&1 || true

log_success "System settings configured"

################################################################################
# Create Directories
################################################################################

log_info "Creating data directories..."

mkdir -p /var/lib/open-deep-inspect/{prometheus,victoriametrics,grafana}
chmod 777 /var/lib/open-deep-inspect/*

log_success "Data directories created"

################################################################################
# Summary
################################################################################

echo ""
echo "================================================================================"
echo "  PREREQUISITES INSTALLATION COMPLETE!"
echo "================================================================================"
echo ""
echo "✅ Docker installed: $(docker --version)"
echo "✅ Docker Compose installed: $(docker-compose --version)"
echo "✅ System dependencies installed"
echo "✅ System settings configured"
echo "✅ Data directories created"
echo ""
echo "📝 Next Steps:"
echo "  1. Configure device credentials in config/*.yml files"
echo "  2. Create/edit .env file with passwords"
echo "  3. Run deployment: ./scripts/deploy.sh"
echo ""
echo "================================================================================"

exit 0
