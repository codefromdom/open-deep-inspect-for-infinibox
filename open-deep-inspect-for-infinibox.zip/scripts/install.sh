#!/bin/bash
#
# open-deep-inspect-for-infinibox Installation Script
# Open Source Framework
#
# This script automates the deployment of the monitoring stack

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}open-deep-inspect-for-infinibox Installation${NC}"
echo -e "${GREEN}Open Source Community${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Check if running from correct directory
cd "$PROJECT_DIR"

# Function to print success messages
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

# Function to print error messages
print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# Function to print warning messages
print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Check if Docker is installed
echo "Checking prerequisites..."
if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed. Please install Docker first."
    exit 1
fi
print_success "Docker is installed"

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    print_error "Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi
print_success "Docker Compose is installed"

# Check if .env file exists
if [ ! -f .env ]; then
    print_warning ".env file not found. Copying from .env.example"
    cp .env.example .env
    print_warning "Please edit .env file with your credentials before continuing."
    echo "Run: nano .env"
    exit 1
fi
print_success ".env file exists"

# Check if required config files exist
echo ""
echo "Checking configuration files..."
REQUIRED_CONFIGS=("config/infinidat.yml" "config/vmware.yml" "config/brocade.yml" "config/juniper.yml")
for config in "${REQUIRED_CONFIGS[@]}"; do
    if [ ! -f "$config" ]; then
        print_error "Required configuration file missing: $config"
        exit 1
    fi
done
print_success "All configuration files present"

# Pull Docker images
echo ""
echo "Pulling Docker images..."
docker-compose pull prometheus victoriametrics grafana || {
    print_error "Failed to pull Docker images"
    exit 1
}
print_success "Docker images pulled successfully"

# Build custom exporters
echo ""
echo "Building custom exporters..."
docker-compose build || {
    print_error "Failed to build custom exporters"
    exit 1
}
print_success "Custom exporters built successfully"

# Create necessary directories if they don't exist
echo ""
echo "Creating directories..."
mkdir -p prometheus/rules
mkdir -p grafana/dashboards
mkdir -p grafana/provisioning/datasources
mkdir -p grafana/provisioning/dashboards
print_success "Directories created"

# Stop any existing containers
echo ""
echo "Stopping any existing containers..."
docker-compose down 2>/dev/null || true
print_success "Existing containers stopped"

# Start the monitoring stack
echo ""
echo "Starting monitoring stack..."
docker-compose up -d || {
    print_error "Failed to start monitoring stack"
    echo "Check logs with: docker-compose logs"
    exit 1
}
print_success "Monitoring stack started"

# Wait for services to be healthy
echo ""
echo "Waiting for services to become healthy (this may take 30-60 seconds)..."
sleep 10

# Function to check if a service is healthy
check_service() {
    local service=$1
    local max_attempts=30
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if docker-compose ps | grep "$service" | grep -q "Up"; then
            return 0
        fi
        sleep 2
        attempt=$((attempt + 1))
    done
    return 1
}

# Check critical services
CRITICAL_SERVICES=("prometheus" "victoriametrics" "grafana")
for service in "${CRITICAL_SERVICES[@]}"; do
    if check_service "$service"; then
        print_success "$service is running"
    else
        print_error "$service failed to start"
        echo "Check logs with: docker-compose logs $service"
        exit 1
    fi
done

# Check exporter services
EXPORTER_SERVICES=("infinidat-exporter" "vmware-exporter" "brocade-exporter" "juniper-exporter")
echo ""
echo "Checking exporters..."
for service in "${EXPORTER_SERVICES[@]}"; do
    if check_service "$service"; then
        print_success "$service is running"
    else
        print_warning "$service may have issues - check logs: docker-compose logs $service"
    fi
done

# Get server IP
SERVER_IP=$(hostname -I | awk '{print $1}')

# Display access information
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Installation Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo "Access Information:"
echo "-------------------"
echo -e "Grafana:          ${GREEN}http://$SERVER_IP:3000${NC}"
echo "  Username:       admin"
echo "  Password:       (from your .env file)"
echo ""
echo -e "Prometheus:       ${GREEN}http://$SERVER_IP:9090${NC}"
echo -e "VictoriaMetrics:  ${GREEN}http://$SERVER_IP:8428${NC}"
echo ""
echo "Exporters:"
echo -e "  Infinibox:      ${GREEN}http://$SERVER_IP:9600/metrics${NC}"
echo -e "  VMware:         ${GREEN}http://$SERVER_IP:9601/metrics${NC}"
echo -e "  Brocade:        ${GREEN}http://$SERVER_IP:9602/metrics${NC}"
echo -e "  Juniper:        ${GREEN}http://$SERVER_IP:9603/metrics${NC}"
echo ""
echo "Next Steps:"
echo "-----------"
echo "1. Access Grafana and verify dashboards are loaded"
echo "2. Navigate to 'Organization Infrastructure Overview' dashboard"
echo "3. Verify metrics are being collected from all devices"
echo "4. Run health check: ./scripts/health-check.sh"
echo "5. Set up backups: ./scripts/backup.sh"
echo ""
echo "Useful Commands:"
echo "----------------"
echo "  View logs:           docker-compose logs -f"
echo "  View specific logs:  docker-compose logs -f [service-name]"
echo "  Restart service:     docker-compose restart [service-name]"
echo "  Stop all:            docker-compose down"
echo "  Start all:           docker-compose up -d"
echo ""
print_success "open-deep-inspect-for-infinibox is now operational!"
echo ""
