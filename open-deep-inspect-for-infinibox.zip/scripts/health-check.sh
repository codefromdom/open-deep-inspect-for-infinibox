
#!/bin/bash
################################################################################
# Health Check Script for open-deep-inspect-for-infinibox
# Open Source Community
################################################################################

set -e

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

echo "================================================================================"
echo "  open-deep-inspect-for-infinibox - Health Check"
echo "  Open Source Community"
echo "================================================================================"
echo ""

HEALTH_SCORE=0
MAX_SCORE=0

check_service() {
    local name=$1
    local url=$2
    MAX_SCORE=$((MAX_SCORE + 1))
    
    if curl -s -f "$url" > /dev/null 2>&1; then
        log_success "$name is healthy"
        HEALTH_SCORE=$((HEALTH_SCORE + 1))
        return 0
    else
        log_error "$name is not responding"
        return 1
    fi
}

check_container() {
    local name=$1
    MAX_SCORE=$((MAX_SCORE + 1))
    
    if docker ps --format "{{.Names}}" | grep -q "$name"; then
        log_success "Container running: $name"
        HEALTH_SCORE=$((HEALTH_SCORE + 1))
        return 0
    else
        log_error "Container not running: $name"
        return 1
    fi
}

################################################################################
# Container Health Checks
################################################################################

log_info "Checking Docker containers..."
echo ""

check_container "prometheus"
check_container "victoriametrics"
check_container "grafana"
check_container "infinidat-exporter"
check_container "vmware-exporter"
check_container "brocade-exporter"
check_container "juniper-exporter"

echo ""

################################################################################
# Service Health Checks
################################################################################

log_info "Checking service endpoints..."
echo ""

check_service "Prometheus" "http://localhost:9090/-/healthy"
check_service "VictoriaMetrics" "http://localhost:8428/health"
check_service "Grafana" "http://localhost:3000/api/health"
check_service "Infinidat Exporter" "http://localhost:9600/metrics"
check_service "VMware Exporter" "http://localhost:9601/metrics"
check_service "Brocade Exporter" "http://localhost:9602/metrics"
check_service "Juniper Exporter" "http://localhost:9603/metrics"

echo ""

################################################################################
# Prometheus Targets
################################################################################

log_info "Checking Prometheus targets..."
echo ""

TARGETS_UP=$(curl -s http://localhost:9090/api/v1/targets 2>/dev/null | grep -o '"health":"up"' | wc -l || echo 0)
TARGETS_DOWN=$(curl -s http://localhost:9090/api/v1/targets 2>/dev/null | grep -o '"health":"down"' | wc -l || echo 0)

log_info "Targets UP: $TARGETS_UP"
if [ "$TARGETS_DOWN" -gt 0 ]; then
    log_warning "Targets DOWN: $TARGETS_DOWN"
else
    log_success "All targets UP"
fi

echo ""

################################################################################
# Metrics Collection
################################################################################

log_info "Checking metrics collection..."
echo ""

# Check if metrics are being collected
check_metric() {
    local metric=$1
    local label=$2
    MAX_SCORE=$((MAX_SCORE + 1))
    
    if curl -s "http://localhost:9090/api/v1/query?query=$metric" 2>/dev/null | grep -q "success"; then
        log_success "Collecting: $label"
        HEALTH_SCORE=$((HEALTH_SCORE + 1))
        return 0
    else
        log_error "Not collecting: $label"
        return 1
    fi
}

check_metric "infinibox_controller_status" "Infinibox controllers"
check_metric "vmware_host_connection_state" "VMware hosts"
check_metric "brocade_port_status" "Brocade FC ports"
check_metric "juniper_interface_status" "Juniper interfaces"

echo ""

################################################################################
# Disk Usage
################################################################################

log_info "Checking disk usage..."
echo ""

check_disk() {
    local path=$1
    local label=$2
    local usage=$(df -h "$path" 2>/dev/null | tail -1 | awk '{print $5}' | sed 's/%//')
    
    if [ -z "$usage" ]; then
        log_warning "$label: Unable to check"
        return
    fi
    
    if [ "$usage" -lt 70 ]; then
        log_success "$label: ${usage}% used"
    elif [ "$usage" -lt 85 ]; then
        log_warning "$label: ${usage}% used (monitor)"
    else
        log_error "$label: ${usage}% used (critical)"
    fi
}

check_disk "/" "Root filesystem"
check_disk "/var/lib/docker" "Docker data"

echo ""

################################################################################
# Summary
################################################################################

HEALTH_PERCENTAGE=$((HEALTH_SCORE * 100 / MAX_SCORE))

echo "================================================================================"
echo "  HEALTH CHECK SUMMARY"
echo "================================================================================"
echo ""
echo "Health Score: $HEALTH_SCORE / $MAX_SCORE ($HEALTH_PERCENTAGE%)"
echo ""

if [ "$HEALTH_PERCENTAGE" -ge 90 ]; then
    echo -e "${GREEN}✓ System Status: EXCELLENT${NC}"
    echo "All critical components are healthy and operational."
elif [ "$HEALTH_PERCENTAGE" -ge 70 ]; then
    echo -e "${YELLOW}⚠ System Status: GOOD${NC}"
    echo "Most components are healthy. Review warnings above."
elif [ "$HEALTH_PERCENTAGE" -ge 50 ]; then
    echo -e "${YELLOW}⚠ System Status: DEGRADED${NC}"
    echo "Some components need attention. Check logs."
else
    echo -e "${RED}✗ System Status: CRITICAL${NC}"
    echo "Multiple components are failing. Immediate action required."
fi

echo ""
echo "Troubleshooting:"
echo "  - View logs: docker-compose logs -f <service>"
echo "  - Restart service: docker-compose restart <service>"
echo "  - Check config: cat config/<device>.yml"
echo "  - Full restart: docker-compose down && docker-compose up -d"
echo ""
echo "================================================================================"

exit 0
