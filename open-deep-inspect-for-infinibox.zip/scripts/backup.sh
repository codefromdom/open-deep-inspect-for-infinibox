#!/bin/bash
#
# open-deep-inspect-for-infinibox Backup Script
# Open Source Framework
#
# This script backs up Grafana dashboards, configurations, and data

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}open-deep-inspect-for-infinibox Backup${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

cd "$PROJECT_DIR"

# Create backup directory with timestamp
BACKUP_DIR="backups/backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$BACKUP_DIR"

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ️  $1${NC}"
}

echo "Creating backup in: $BACKUP_DIR"
echo ""

# Backup configuration files
echo "Backing up configuration files..."
cp -r config "$BACKUP_DIR/"
cp .env "$BACKUP_DIR/.env" 2>/dev/null || print_info ".env not found, skipping"
cp docker-compose.yml "$BACKUP_DIR/"
print_success "Configuration files backed up"

# Backup Prometheus configuration
echo "Backing up Prometheus configuration..."
cp -r prometheus "$BACKUP_DIR/"
print_success "Prometheus configuration backed up"

# Backup Grafana dashboards
echo "Backing up Grafana dashboards..."
cp -r grafana/dashboards "$BACKUP_DIR/grafana_dashboards"
cp -r grafana/provisioning "$BACKUP_DIR/grafana_provisioning"
print_success "Grafana configuration backed up"

# Backup Grafana database (if container is running)
if docker-compose ps | grep -q "org-grafana.*Up"; then
    echo "Backing up Grafana database..."
    docker-compose exec -T grafana grafana-cli admin export "$BACKUP_DIR/grafana_export.json" 2>/dev/null || {
        print_info "Could not export Grafana database (may not be supported)"
    }
    
    # Backup Grafana volume
    print_info "Creating Grafana volume backup..."
    docker run --rm -v open-deep-inspect-for-infinibox_grafana-data:/data -v "$(pwd)/$BACKUP_DIR":/backup alpine tar czf /backup/grafana-data.tar.gz /data 2>/dev/null && \
        print_success "Grafana volume backed up" || \
        print_info "Could not backup Grafana volume"
else
    print_info "Grafana container not running, skipping database backup"
fi

# Backup VictoriaMetrics data (optional - can be large)
read -p "Do you want to backup VictoriaMetrics data? (This can be large) [y/N]: " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Backing up VictoriaMetrics data..."
    print_info "This may take several minutes..."
    docker run --rm -v open-deep-inspect-for-infinibox_victoriametrics-data:/data -v "$(pwd)/$BACKUP_DIR":/backup alpine tar czf /backup/victoriametrics-data.tar.gz /data 2>/dev/null && \
        print_success "VictoriaMetrics data backed up" || \
        print_error "Failed to backup VictoriaMetrics data"
fi

# Create backup metadata
cat > "$BACKUP_DIR/backup_info.txt" << EOF
open-deep-inspect-for-infinibox Backup
================================
Backup Date: $(date)
Backup Location: $BACKUP_DIR
Hostname: $(hostname)
Docker Version: $(docker --version)
Docker Compose Version: $(docker-compose --version 2>/dev/null || docker compose version)

Backed Up Components:
- Configuration files (.env, docker-compose.yml, config/)
- Prometheus configuration and rules
- Grafana dashboards and provisioning
- Grafana database (if available)
- Grafana volume data

Restore Instructions:
1. Stop the monitoring stack: docker-compose down
2. Restore configuration files to project directory
3. Restore Grafana volume: docker run --rm -v open-deep-inspect-for-infinibox_grafana-data:/data -v $(pwd)/backups/[backup_dir]:/backup alpine tar xzf /backup/grafana-data.tar.gz -C /
4. Start the stack: docker-compose up -d
EOF

print_success "Backup metadata created"

# Calculate backup size
BACKUP_SIZE=$(du -sh "$BACKUP_DIR" | awk '{print $1}')

# Compress the backup
echo ""
echo "Compressing backup..."
BACKUP_ARCHIVE="backups/backup_$(date +%Y%m%d_%H%M%S).tar.gz"
tar -czf "$BACKUP_ARCHIVE" -C backups "$(basename "$BACKUP_DIR")" 2>/dev/null && {
    print_success "Backup compressed to $BACKUP_ARCHIVE"
    ARCHIVE_SIZE=$(du -sh "$BACKUP_ARCHIVE" | awk '{print $1}')
    
    # Remove uncompressed backup directory
    rm -rf "$BACKUP_DIR"
    print_success "Uncompressed backup removed"
} || {
    print_error "Failed to compress backup"
    ARCHIVE_SIZE="N/A"
}

# Clean up old backups (keep last 7 days)
echo ""
echo "Cleaning up old backups (keeping last 7 days)..."
find backups/ -name "backup_*.tar.gz" -type f -mtime +7 -delete 2>/dev/null && \
    print_success "Old backups cleaned up" || \
    print_info "No old backups to clean up"

# Summary
echo ""
echo -e "${GREEN}========================================${NC}"
echo "Backup Complete!"
echo -e "${GREEN}========================================${NC}"
echo "Backup Archive:  $BACKUP_ARCHIVE"
echo "Archive Size:    $ARCHIVE_SIZE"
echo ""
echo "To restore this backup:"
echo "  1. Extract: tar -xzf $BACKUP_ARCHIVE"
echo "  2. Follow instructions in backup_info.txt"
echo ""
print_success "Backup completed successfully!"
