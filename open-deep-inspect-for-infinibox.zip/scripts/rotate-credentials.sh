#!/bin/bash
#
# Credential Rotation Script
# Open Source Community
#
# Safely rotates monitoring credentials and updates all components
#

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}Credential Rotation Script${NC}"
echo -e "${GREEN}Open Source Community${NC}"
echo -e "${GREEN}============================================${NC}"
echo

# Function to print messages
print_info() { echo -e "${GREEN}ℹ️  $1${NC}"; }
print_warning() { echo -e "${YELLOW}⚠️  $1${NC}"; }
print_error() { echo -e "${RED}❌ $1${NC}"; }

# Check if .env.backup exists
if [ ! -f "$PROJECT_DIR/.env.backup" ]; then
    print_info "Creating backup of current credentials..."
    cp "$PROJECT_DIR/.env" "$PROJECT_DIR/.env.backup.$(date +%Y%m%d_%H%M%S)"
    print_info "Backup created"
fi

echo
echo "Credential Rotation Checklist"
echo "==============================="
echo
echo "This script will guide you through credential rotation."
echo "Ensure you have:"
echo "  1. New credentials generated in respective systems"
echo "  2. Read-only access verified for new credentials"
echo "  3. Backup window scheduled (services will restart)"
echo
read -p "Do you want to continue? (yes/no): " CONTINUE

if [ "$CONTINUE" != "yes" ]; then
    echo "Aborted."
    exit 0
fi

echo
echo "Select component to rotate credentials:"
echo "  1. Infinibox"
echo "  2. vCenter"
echo "  3. Brocade switches (SNMP)"
echo "  4. Juniper switches (SNMP)"
echo "  5. Grafana admin"
echo "  6. All of the above"
echo
read -p "Enter choice (1-6): " CHOICE

rotate_infinibox() {
    print_info "Rotating Infinibox credentials..."
    echo
    echo "Steps to rotate Infinibox credentials:"
    echo "1. Log into Infinibox management interface"
    echo "2. Navigate to: Settings → Users"
    echo "3. Change password for monitoring user"
    echo "4. Update .env file with new password"
    echo
    read -p "New Infinibox password: " -s INFINIBOX_PASS
    echo
    
    # Update .env file
    sed -i "s/^INFINIBOX_PASSWORD=.*/INFINIBOX_PASSWORD=$INFINIBOX_PASS/" "$PROJECT_DIR/.env"
    
    # Restart exporter
    print_info "Restarting Infinidat exporter..."
    cd "$PROJECT_DIR"
    docker-compose restart infinidat-exporter
    
    # Test connectivity
    sleep 5
    if curl -s http://localhost:9600/health | grep -q "OK"; then
        print_info "✅ Infinidat exporter restarted successfully"
    else
        print_error "Failed to restart exporter. Check logs: docker-compose logs infinidat-exporter"
    fi
}

rotate_vcenter() {
    print_info "Rotating vCenter credentials..."
    echo
    read -p "New vCenter password: " -s VCENTER_PASS
    echo
    
    sed -i "s/^VCENTER_PASSWORD=.*/VCENTER_PASSWORD=$VCENTER_PASS/" "$PROJECT_DIR/.env"
    
    print_info "Restarting VMware exporter..."
    cd "$PROJECT_DIR"
    docker-compose restart vmware-exporter
    
    sleep 5
    if curl -s http://localhost:9601/health | grep -q "OK"; then
        print_info "✅ VMware exporter restarted successfully"
    else
        print_error "Failed to restart exporter. Check logs: docker-compose logs vmware-exporter"
    fi
}

rotate_brocade() {
    print_info "Rotating Brocade SNMP credentials..."
    echo
    echo "Update config/brocade.yml with new SNMP community string"
    echo "Then restart the exporter"
    echo
    read -p "Press Enter after updating config/brocade.yml..."
    
    cd "$PROJECT_DIR"
    docker-compose restart brocade-exporter
    
    sleep 5
    if curl -s http://localhost:9602/health | grep -q "OK"; then
        print_info "✅ Brocade exporter restarted successfully"
    else
        print_error "Failed to restart exporter"
    fi
}

rotate_juniper() {
    print_info "Rotating Juniper SNMP credentials..."
    echo
    echo "Update config/juniper.yml with new SNMP community string"
    echo "Then restart the exporter"
    echo
    read -p "Press Enter after updating config/juniper.yml..."
    
    cd "$PROJECT_DIR"
    docker-compose restart juniper-exporter
    
    sleep 5
    if curl -s http://localhost:9603/health | grep -q "OK"; then
        print_info "✅ Juniper exporter restarted successfully"
    else
        print_error "Failed to restart exporter"
    fi
}

rotate_grafana() {
    print_info "Rotating Grafana admin credentials..."
    echo
    read -p "New Grafana admin password: " -s GRAFANA_PASS
    echo
    
    sed -i "s/^GRAFANA_ADMIN_PASSWORD=.*/GRAFANA_ADMIN_PASSWORD=$GRAFANA_PASS/" "$PROJECT_DIR/.env"
    
    print_info "Restarting Grafana..."
    cd "$PROJECT_DIR"
    docker-compose restart grafana
    
    sleep 10
    print_info "✅ Grafana restarted. Login with new password at http://localhost:3000"
}

case $CHOICE in
    1)
        rotate_infinibox
        ;;
    2)
        rotate_vcenter
        ;;
    3)
        rotate_brocade
        ;;
    4)
        rotate_juniper
        ;;
    5)
        rotate_grafana
        ;;
    6)
        rotate_infinibox
        rotate_vcenter
        rotate_brocade
        rotate_juniper
        rotate_grafana
        ;;
    *)
        print_error "Invalid choice"
        exit 1
        ;;
esac

echo
print_info "Credential rotation complete!"
echo
echo "Post-rotation checklist:"
echo "  ✅ Verify all exporters are collecting metrics"
echo "  ✅ Check Grafana dashboards show current data"
echo "  ✅ Review logs for any authentication errors"
echo "  ✅ Update credential vault/documentation"
echo
echo "Validation command:"
echo "  ./scripts/validate.sh"
