#!/bin/bash
################################################################################
# open-deep-inspect-for-infinibox - One-Command Deployment Script
# Open Source Community
# 
# This script deploys the complete monitoring stack in under 10 minutes
################################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Banner
echo "================================================================================"
echo "  open-deep-inspect-for-infinibox - Deployment Script"
echo "  Open Source Community"
echo "  Version: 1.0.0 framework code (NOT production-ready, see DISCLAIMER.txt)"
echo "================================================================================"
echo ""

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

log_info "Project root: $PROJECT_ROOT"
echo ""

################################################################################
# Step 1: Prerequisites Check
################################################################################

log_info "Step 1/8: Checking prerequisites..."

# Check Docker
if ! command -v docker &> /dev/null; then
    log_error "Docker is not installed. Please run: sudo ./scripts/install-prerequisites.sh"
    exit 1
fi
log_success "Docker installed: $(docker --version)"

# Check Docker Compose
if ! command -v docker-compose &> /dev/null; then
    log_error "Docker Compose is not installed. Please run: sudo ./scripts/install-prerequisites.sh"
    exit 1
fi
log_success "Docker Compose installed: $(docker-compose --version)"

# Check Docker daemon
if ! docker ps &> /dev/null; then
    log_error "Docker daemon is not running. Please start Docker."
    exit 1
fi
log_success "Docker daemon is running"

# Check disk space (need at least 10GB)
AVAILABLE_SPACE=$(df -BG "$PROJECT_ROOT" | tail -1 | awk '{print $4}' | sed 's/G//')
if [ "$AVAILABLE_SPACE" -lt 10 ]; then
    log_warning "Low disk space: ${AVAILABLE_SPACE}GB available (10GB recommended)"
else
    log_success "Disk space available: ${AVAILABLE_SPACE}GB"
fi

echo ""

################################################################################
# Step 2: Configuration Check
################################################################################

log_info "Step 2/8: Checking configuration files..."

# Check if .env file exists
if [ ! -f "$PROJECT_ROOT/.env" ]; then
    log_warning ".env file not found. Creating from example..."
    if [ -f "$PROJECT_ROOT/.env.example" ]; then
        cp "$PROJECT_ROOT/.env.example" "$PROJECT_ROOT/.env"
        log_warning "IMPORTANT: Edit .env file with your credentials before continuing!"
        log_warning "Run: nano .env"
        read -p "Press Enter after editing .env file..."
    else
        log_error ".env.example not found. Cannot proceed."
        exit 1
    fi
fi
log_success "Configuration file found: .env"

# Check config files
CONFIG_FILES=("config/infinidat.yml" "config/vmware.yml" "config/brocade.yml" "config/juniper.yml")
for config in "${CONFIG_FILES[@]}"; do
    if [ -f "$PROJECT_ROOT/$config" ]; then
        log_success "Config found: $config"
    else
        log_warning "Config not found: $config (may need to be created)"
    fi
done

echo ""

################################################################################
# Step 3: Build Docker Images
################################################################################

log_info "Step 3/8: Building Docker images for custom exporters..."

# Build Infinidat exporter
log_info "Building Infinidat exporter..."
if docker build -t open-deep-inspect/infinidat-exporter:latest "$PROJECT_ROOT/exporters/infinidat" > /dev/null 2>&1; then
    log_success "Infinidat exporter built successfully"
else
    log_error "Failed to build Infinidat exporter"
    exit 1
fi

# Build VMware exporter
log_info "Building VMware exporter..."
if docker build -t open-deep-inspect/vmware-exporter:latest "$PROJECT_ROOT/exporters/vmware" > /dev/null 2>&1; then
    log_success "VMware exporter built successfully"
else
    log_error "Failed to build VMware exporter"
    exit 1
fi

# Build Brocade exporter
log_info "Building Brocade exporter..."
if docker build -t open-deep-inspect/brocade-exporter:latest "$PROJECT_ROOT/exporters/brocade" > /dev/null 2>&1; then
    log_success "Brocade exporter built successfully"
else
    log_error "Failed to build Brocade exporter"
    exit 1
fi

# Build Juniper exporter
log_info "Building Juniper exporter..."
if docker build -t open-deep-inspect/juniper-exporter:latest "$PROJECT_ROOT/exporters/juniper" > /dev/null 2>&1; then
    log_success "Juniper exporter built successfully"
else
    log_error "Failed to build Juniper exporter"
    exit 1
fi

echo ""

################################################################################
# Step 4: Pull Base Images
################################################################################

log_info "Step 4/8: Pulling base Docker images..."

IMAGES=("prom/prometheus:latest" "victoriametrics/victoria-metrics:latest" "grafana/grafana:latest")
for image in "${IMAGES[@]}"; do
    log_info "Pulling $image..."
    if docker pull "$image" > /dev/null 2>&1; then
        log_success "Pulled $image"
    else
        log_error "Failed to pull $image"
        exit 1
    fi
done

echo ""

################################################################################
# Step 5: Start Services
################################################################################

log_info "Step 5/8: Starting monitoring services..."

# Stop any existing containers
log_info "Stopping existing containers..."
docker-compose down > /dev/null 2>&1 || true

# Start services
log_info "Starting all services..."
if docker-compose up -d; then
    log_success "All services started successfully"
else
    log_error "Failed to start services"
    exit 1
fi

echo ""

################################################################################
# Step 6: Wait for Services to be Ready
################################################################################

log_info "Step 6/8: Waiting for services to be ready..."

# Function to wait for service
wait_for_service() {
    local service=$1
    local port=$2
    local max_attempts=30
    local attempt=1
    
    log_info "Waiting for $service on port $port..."
    
    while [ $attempt -le $max_attempts ]; do
        if curl -s "http://localhost:$port" > /dev/null 2>&1 || \
           curl -s "http://localhost:$port/metrics" > /dev/null 2>&1 || \
           curl -s "http://localhost:$port/health" > /dev/null 2>&1; then
            log_success "$service is ready"
            return 0
        fi
        sleep 2
        attempt=$((attempt + 1))
    done
    
    log_error "$service failed to start within timeout"
    return 1
}

# Wait for each service
wait_for_service "Prometheus" 9090 || exit 1
wait_for_service "VictoriaMetrics" 8428 || exit 1
wait_for_service "Grafana" 3000 || exit 1
wait_for_service "Infinidat Exporter" 9600 || true  # May fail if no connection to Infinibox yet
wait_for_service "VMware Exporter" 9601 || true     # May fail if no connection to vCenter yet
wait_for_service "Brocade Exporter" 9602 || true    # May fail if no connection to switches yet
wait_for_service "Juniper Exporter" 9603 || true    # May fail if no connection to switches yet

echo ""

################################################################################
# Step 7: Validation
################################################################################

log_info "Step 7/8: Validating deployment..."

# Check if containers are running
REQUIRED_CONTAINERS=("prometheus" "victoriametrics" "grafana" "infinidat-exporter" "vmware-exporter" "brocade-exporter" "juniper-exporter")
ALL_RUNNING=true

for container in "${REQUIRED_CONTAINERS[@]}"; do
    if docker ps --format "{{.Names}}" | grep -q "$container"; then
        log_success "Container running: $container"
    else
        log_error "Container not running: $container"
        ALL_RUNNING=false
    fi
done

if [ "$ALL_RUNNING" = false ]; then
    log_error "Some containers failed to start. Check logs with: docker-compose logs"
    exit 1
fi

# Check Prometheus targets
log_info "Checking Prometheus targets..."
TARGETS_UP=$(curl -s http://localhost:9090/api/v1/targets 2>/dev/null | grep -o '"health":"up"' | wc -l || echo 0)
log_info "Prometheus targets UP: $TARGETS_UP"

# Check if Grafana is accessible
if curl -s http://localhost:3000/api/health > /dev/null 2>&1; then
    log_success "Grafana is accessible"
else
    log_warning "Grafana may not be fully ready yet"
fi

echo ""

################################################################################
# Step 8: Post-Deployment Summary
################################################################################

log_info "Step 8/8: Deployment complete!"

echo ""
echo "================================================================================"
echo "  DEPLOYMENT SUCCESSFUL!"
echo "================================================================================"
echo ""
echo "🎉 open-deep-inspect-for-infinibox is now running!"
echo ""
echo "📊 Access Points:"
echo "  - Grafana:          http://$(hostname -I | awk '{print $1}'):3000"
echo "  - Prometheus:       http://$(hostname -I | awk '{print $1}'):9090"
echo "  - VictoriaMetrics:  http://$(hostname -I | awk '{print $1}'):8428"
echo ""
echo "🔐 Default Credentials (Grafana):"
echo "  - Username: admin"
echo "  - Password: (check .env file or use 'admin')"
echo ""
echo "📈 Monitoring Intervals:"
echo "  - Infinibox:  1 second  (ultra high-frequency)"
echo "  - VMware:     5 seconds (high-frequency)"
echo "  - Brocade FC: 5 seconds (high-frequency)"
echo "  - Juniper:    5 seconds (high-frequency)"
echo ""
echo "💾 Data Retention:"
echo "  - Prometheus: 2 days (short-term, fast queries)"
echo "  - VictoriaMetrics: 30 days (long-term storage)"
echo ""
echo "📚 Next Steps:"
echo "  1. Access Grafana at http://$(hostname -I | awk '{print $1}'):3000"
echo "  2. Review pre-configured dashboards"
echo "  3. Verify all exporters are collecting metrics"
echo "  4. Configure alert notification channels"
echo "  5. Review documentation in docs/ directory"
echo ""
echo "🔍 Health Check:"
echo "  Run: ./scripts/health-check.sh"
echo ""
echo "🛠️  Troubleshooting:"
echo "  - View logs: docker-compose logs -f <service-name>"
echo "  - Restart:   docker-compose restart <service-name>"
echo "  - Stop all:  docker-compose down"
echo ""
echo "📖 Documentation:"
echo "  - README.md:                  Quick start guide"
echo "  - DEPLOYMENT_CHECKLIST.md:    Deployment verification"
echo "  - docs/TROUBLESHOOTING.md:    Problem resolution"
echo "  - docs/ARCHITECTURE.md:        Technical details"
echo ""
echo "================================================================================"
echo "  Delivered by: Open Source Community"
echo "  "
echo "  Solution: Infrastructure Monitoring with SSA (3 Active Controllers)"
echo "================================================================================"
echo ""

log_success "Deployment completed successfully in under 10 minutes! 🚀"
echo ""

# Offer to run health check
read -p "Would you like to run a full health check now? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    if [ -f "$SCRIPT_DIR/health-check.sh" ]; then
        "$SCRIPT_DIR/health-check.sh"
    else
        log_warning "Health check script not found"
    fi
fi

exit 0
