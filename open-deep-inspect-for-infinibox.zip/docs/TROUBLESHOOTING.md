# Troubleshooting Guide

**@codefromdom**
**Version:** 1.0.0  
**Date:** December 2, 2025

## Common Issues and Solutions

### 1. Services Won't Start

**Symptom**: `docker-compose up -d` fails or containers keep restarting

**Solutions**:

```bash
# Check Docker service
sudo systemctl status docker
sudo systemctl start docker

# Check logs for specific service
docker-compose logs [service-name]

# Common issues:
# - Port already in use
netstat -tulpn | grep -E "3000|9090|8428|9600|9601|9602|9603"

# - Insufficient resources
docker system df
docker system prune -a  # Warning: removes unused images

# - Configuration errors
./scripts/validate.sh
```

### 2. Exporter Shows as "Down" in Prometheus

**Symptom**: Target shows as "down" in Prometheus UI (http://localhost:9090/targets)

**Check exporter logs**:
```bash
docker-compose logs infinidat-exporter
docker-compose logs vmware-exporter
docker-compose logs brocade-exporter
docker-compose logs juniper-exporter
```

**Common causes**:

**Authentication failure**:
- Verify credentials in `.env` and config files
- Test API access manually:
  ```bash
  # Infinibox
  curl -k -u username:password https://INFINIBOX_IP/api/rest/system
  
  # vCenter
  curl -k -u username:password https://VCENTER_IP/rest/com/vmware/cis/session
  ```

**Network connectivity**:
- Verify network access:
  ```bash
  ping DEVICE_IP
  telnet DEVICE_IP PORT
  ```
- Check firewall rules
- Verify SNMP community strings for network devices

**Container issues**:
```bash
# Restart specific exporter
docker-compose restart infinidat-exporter

# Rebuild if code changes were made
docker-compose build infinidat-exporter
docker-compose up -d infinidat-exporter
```

### 3. No Metrics in Grafana Dashboards

**Symptom**: Grafana dashboards show "No data" or empty panels

**Step 1: Verify data sources**
- Navigate to: Configuration → Data Sources
- Test each datasource (Prometheus, VictoriaMetrics)
- Should show "Data source is working"

**Step 2: Check Prometheus is collecting metrics**
```bash
# Open Prometheus UI
http://YOUR_SERVER_IP:9090

# Go to Graph tab, enter query:
up

# Should show all targets
```

**Step 3: Check dashboard queries**
- Edit a dashboard panel
- Check the query for errors
- Try a simple query like `up` first

**Step 4: Verify time range**
- Check dashboard time range (top right)
- Try "Last 5 minutes" or "Last 1 hour"
- Ensure your time zone is correct

**Step 5: Check exporter metrics**
```bash
# Verify exporters are producing metrics
curl http://localhost:9600/metrics | grep infinibox
curl http://localhost:9601/metrics | grep vmware
curl http://localhost:9602/metrics | grep brocade
curl http://localhost:9603/metrics | grep juniper
```

### 4. High CPU or Memory Usage

**Symptom**: Server running slow, high resource usage

**Check resource usage**:
```bash
docker stats

# Look for containers using excessive CPU/memory
```

**Solutions**:

**Reduce scrape frequency**:
```bash
# Edit prometheus/prometheus.yml
nano prometheus/prometheus.yml

# Increase scrape_interval from 10s to 30s or 1m
# Restart Prometheus
docker-compose restart prometheus
```

**Reduce data retention**:
```bash
# Edit docker-compose.yml
nano docker-compose.yml

# Reduce VictoriaMetrics retention from 30d to 14d
# Under victoriametrics service:
# '--retentionPeriod=14d'

# Restart VictoriaMetrics
docker-compose restart victoriametrics
```

**Limit VM collection**:
```bash
# Edit config/vmware.yml
nano config/vmware.yml

# Set max_vms_to_collect: 100
# Restart VMware exporter
docker-compose restart vmware-exporter
```

### 5. Grafana Login Issues

**Forgot admin password**:
```bash
# Reset Grafana admin password
docker-compose exec grafana grafana-cli admin reset-admin-password newpassword

# Update .env file with new password
```

**Can't access Grafana UI**:
```bash
# Check Grafana is running
docker-compose ps | grep grafana

# Check logs
docker-compose logs grafana

# Verify port 3000 is accessible
netstat -tulpn | grep 3000

# Check firewall
sudo ufw status
sudo ufw allow 3000/tcp
```

### 6. Disk Space Issues

**Symptom**: Disk space running low or full

**Check disk usage**:
```bash
df -h

# Check Docker volumes
docker system df -v
```

**Solutions**:

**Clean up Docker**:
```bash
# Remove unused images and containers
docker system prune -a

# Remove old logs
docker-compose logs --tail=0 -f > /dev/null
```

**Reduce retention periods**:
```bash
# Reduce VictoriaMetrics retention (see High CPU/Memory section)
# Reduce Prometheus retention
nano docker-compose.yml
# Change '--storage.tsdb.retention.time=2d' to '1d'
docker-compose restart prometheus
```

**Move Docker data directory** (advanced):
```bash
# Stop Docker
sudo systemctl stop docker

# Move data
sudo mv /var/lib/docker /path/to/new/location

# Create symlink
sudo ln -s /path/to/new/location /var/lib/docker

# Start Docker
sudo systemctl start docker
```

### 7. SNMP Issues (Brocade/Juniper)

**Symptom**: Network device metrics not collected

**Test SNMP access**:
```bash
# Install snmpwalk (if not installed)
sudo apt-get install snmp

# Test Brocade
snmpwalk -v2c -c public BROCADE_IP system

# Test Juniper
snmpwalk -v2c -c public JUNIPER_IP system
```

**Common issues**:
- Wrong SNMP community string
- SNMP not enabled on device
- Firewall blocking UDP port 161
- Wrong SNMP version (try v1, v2c, v3)

**Fix configuration**:
```bash
# Edit device config
nano config/brocade.yml
nano config/juniper.yml

# Update community string
# Restart exporters
docker-compose restart brocade-exporter juniper-exporter
```

### 8. SSL/TLS Certificate Errors

**Symptom**: Exporters can't connect due to certificate errors

**For Infinibox/vCenter with self-signed certificates**:

The exporters are configured to ignore SSL verification. If you still have issues:

```bash
# Check exporter logs
docker-compose logs vmware-exporter

# Verify manually (should work with -k flag)
curl -k https://VCENTER_IP/rest/com/vmware/cis/session
```

### 9. Prometheus Out of Memory

**Symptom**: Prometheus container keeps restarting, OOM errors in logs

**Solutions**:

**Increase memory limit**:
```bash
# Edit docker-compose.yml
nano docker-compose.yml

# Add memory limits to prometheus service:
# deploy:
#   resources:
#     limits:
#       memory: 4G

docker-compose up -d prometheus
```

**Reduce metrics cardinality**:
```bash
# Reduce number of monitored VMs
# Reduce scrape frequency
# Reduce retention time
```

### 10. VictoriaMetrics Issues

**Symptom**: VictoriaMetrics not accepting writes or queries failing

**Check VictoriaMetrics logs**:
```bash
docker-compose logs victoriametrics
```

**Verify remote write is working**:
```bash
# Check Prometheus config
curl http://localhost:9090/api/v1/status/config | grep remote_write

# Test VictoriaMetrics endpoint
curl http://localhost:8428/-/healthy
```

**Restart and clear data (if needed)**:
```bash
# WARNING: This will delete all historical data
docker-compose down
docker volume rm open-deep-inspect-for-infinibox_victoriametrics-data
docker-compose up -d
```

## Getting More Help

### Check Logs

Always start by checking logs:
```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f [service-name]

# Last 100 lines
docker-compose logs --tail=100 [service-name]
```

### Run Health Check

```bash
./scripts/health-check.sh
```

### Validate Configuration

```bash
./scripts/validate.sh
```

### Contact Support

If issues persist:
1. Collect logs: `docker-compose logs > logs.txt`
2. Run health check: `./scripts/health-check.sh > health.txt`
3. Document the issue with:
   - What you were trying to do
   - What happened
   - Error messages
   - Steps to reproduce
4. Contact Open Source Community

## Emergency Procedures

### Complete Reset

**WARNING**: This will delete all monitoring data

```bash
# Stop all services
docker-compose down

# Remove all volumes
docker-compose down -v

# Restart
./scripts/install.sh
```

### Restore from Backup

```bash
# Extract backup
tar -xzf backups/backup_YYYYMMDD_HHMMSS.tar.gz

# Follow instructions in backup_info.txt

# Restart
docker-compose down
docker-compose up -d
```
