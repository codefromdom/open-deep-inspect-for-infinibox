# open-deep-inspect-for-infinibox Implementation Guide

**@codefromdom**
**Version:** 1.0.0  
**Date:** December 2, 2025

This guide provides step-by-step instructions to deploy the monitoring solution in your Organization environment.

## Solution Overview

This monitoring framework/toolbox (see DISCLAIMER.txt) provides:

- **Infrastructure Monitoring**: Real-time metrics from Infinibox storage, VMware vCenter, Brocade FC switches, and Juniper network switches
- **Unified Dashboards**: Grafana dashboards showing status, performance, and capacity across all components
- **Alerting**: Proactive notifications for critical events and threshold violations
- **End-to-End Topology Visualization**: *(NEW)* Complete path visibility from storage LUNs through the network fabric to virtual machines

### Key Features

#### Core Monitoring Capabilities
- Infinibox storage arrays (pools, volumes, performance)
- VMware vCenter (ESXi hosts, VMs, datastores)
- Brocade FC switches (4x DB720S with port-level metrics)
- Juniper QFX switches (core and leaf topology)

#### End-to-End Topology Visualization *(NEW)*

The solution now includes advanced topology correlation that provides complete visibility into storage-to-VM relationships:

**What You Can See:**
```
Infinibox Volume → FC Port → FC Zone → ESXi HBA → Datastore → Virtual Machine
```

**Capabilities:**
- Automatic discovery and correlation of storage, network, and compute relationships
- Visual representation of complete end-to-end paths
- Performance metrics at every layer of the stack
- Impact analysis: Understand which VMs are affected by storage or network changes
- Troubleshooting: Quickly identify where connectivity or performance issues occur

**Use Cases:**
- **Capacity Planning**: See which VMs consume which storage volumes
- **Change Management**: Identify impact before making changes to storage or network
- **Troubleshooting**: Trace performance issues from VM back to storage
- **Documentation**: Maintain accurate topology documentation automatically
- **Compliance**: Track data flow paths for security and compliance requirements

### Architecture Components

The monitoring solution consists of:

1. **Metrics Exporters** (Prometheus format)
   - Infinibox Exporter (port 9600) - Storage metrics + LUN mappings
   - VMware Exporter (port 9601) - vCenter metrics + VM-to-datastore relationships
   - Brocade FC Exporter (port 9602) - FC switch metrics + zoning + WWPNs
   - Juniper Exporter (port 9603) - Network switch metrics

2. **Time-Series Database**
   - VictoriaMetrics (primary storage, 30-day retention)
   - Prometheus (short-term buffer, 2-day retention)

3. **Topology Correlation** *(NEW)*
   - Topology Correlator Service (port 9700) - Correlates data from all exporters
   - PostgreSQL Database (port 5432) - Stores topology relationships
   - Discovery Scripts - Periodic topology discovery and validation

4. **Visualization**
   - Grafana (port 3000) - Dashboards and alerting
   - Pre-configured dashboards for all components
   - End-to-end topology dashboard with path visualization *(NEW)*

5. **Data Flow**
```
┌─────────────────────────────────────────────────────────────────┐
│                     INFRASTRUCTURE LAYER                         │
│  Infinibox ←→ Brocade FC ←→ ESXi Hosts ←→ Juniper Network     │
└──────────────────────────────┬──────────────────────────────────┘
                               │
┌──────────────────────────────┴──────────────────────────────────┐
│                      MONITORING LAYER                            │
│  Exporters (9600-9603) → Prometheus → VictoriaMetrics          │
└──────────────────────────────┬──────────────────────────────────┘
                               │
┌──────────────────────────────┴──────────────────────────────────┐
│                    CORRELATION LAYER (NEW)                       │
│  Topology Correlator ←→ PostgreSQL Database                     │
└──────────────────────────────┬──────────────────────────────────┘
                               │
┌──────────────────────────────┴──────────────────────────────────┐
│                   VISUALIZATION LAYER                            │
│  Grafana Dashboards (including Topology Dashboard)              │
└─────────────────────────────────────────────────────────────────┘
```

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Pre-Deployment Checklist](#pre-deployment-checklist)
3. [Installation Steps](#installation-steps)
4. [Configuration](#configuration)
5. [Topology Visualization Setup](#topology-visualization-setup)
6. [Validation](#validation)
7. [Post-Deployment](#post-deployment)
8. [Troubleshooting](#troubleshooting)

## Prerequisites

### Hardware Requirements

**Monitoring Server:**
- **CPU**: 4 cores minimum (8 cores recommended, 12+ for topology correlation)
- **RAM**: 8GB minimum (16GB recommended for 30-day retention, 24GB+ with topology)
- **Disk**: 100GB minimum (200GB recommended, 300GB+ with topology database)
- **Network**: Connectivity to all monitored devices

**Resource Breakdown:**
- Base monitoring stack: 4 cores, 8GB RAM, 100GB disk
- Topology correlation: +4 cores, +8GB RAM, +100GB disk (PostgreSQL database)
- Recommended production: 8-12 cores, 16-24GB RAM, 200-300GB disk

### Software Requirements

- **Operating System**: Linux (Ubuntu 20.04/22.04, RHEL 8/9, or similar)
- **Docker**: Version 20.10 or later
- **Docker Compose**: Version 2.0 or later
- **PostgreSQL**: Version 12 or later (for topology correlation)
- **Python**: Version 3.8+ (for topology correlator service)
- **Network access**: Ports required:
  - 3000 (Grafana)
  - 9090 (Prometheus)
  - 8428 (VictoriaMetrics)
  - 5432 (PostgreSQL - for topology)
  - 9700 (Topology Correlator API)

### Access Requirements

You will need the following credentials and access:

**Infinidat Infinibox:**
- Hostname/IP address
- Username with read-only API access
- Password

**VMware vCenter:**
- Hostname/IP address
- Username with read-only permissions
- Password

**Brocade FC Switches (4x DB720S):**
- IP addresses of all 4 switches
- SNMP community string (read-only)

**Juniper QFX Switches:**
- IP addresses (Core QFX5120 + Leaf QFX5110)
- SNMP community string (read-only)

## Pre-Deployment Checklist

Before starting the installation, verify:

- [ ] Docker and Docker Compose are installed
- [ ] Server has network access to all monitored devices
- [ ] You have collected all required credentials
- [ ] Firewall rules allow required ports
- [ ] You have sudo/root access on the monitoring server

### Verify Docker Installation

```bash
docker --version
docker-compose --version

# Should show versions 20.10+ and 2.0+ respectively
```

### Test Network Connectivity

```bash
# Test Infinibox connectivity
ping -c 3 <INFINIBOX_IP>
curl -k https://<INFINIBOX_IP>/api/rest/system

# Test vCenter connectivity
ping -c 3 <VCENTER_IP>
curl -k https://<VCENTER_IP>

# Test Brocade switches (all 4)
ping -c 3 <BROCADE_SWITCH_1_IP>
ping -c 3 <BROCADE_SWITCH_2_IP>
ping -c 3 <BROCADE_SWITCH_3_IP>
ping -c 3 <BROCADE_SWITCH_4_IP>

# Test Juniper switches
ping -c 3 <JUNIPER_CORE_1_IP>
ping -c 3 <JUNIPER_CORE_2_IP>
ping -c 3 <JUNIPER_LEAF_1_IP>
# ... and so on
```

## Installation Steps

### Step 1: Deploy the Toolbox

Choose a deployment location:

```bash
cd /opt
sudo mkdir -p Organization_monitoring
cd Organization_monitoring

# If you have a tar.gz package:
sudo tar -xzf /path/to/open-deep-inspect-for-infinibox.tar.gz

# Or if copying from another location:
sudo cp -r /path/to/open-deep-inspect-for-infinibox/* .

# Set proper ownership
sudo chown -R $(whoami):$(whoami) .
```

### Step 2: Configure Environment Variables

```bash
# Copy the example environment file
cp .env.example .env

# Edit with your preferred editor
nano .env
```

Configure the following in `.env`:

```bash
# Grafana Admin Credentials
GRAFANA_ADMIN_USER=admin
GRAFANA_ADMIN_PASSWORD=YourSecurePasswordHere123!

# Infinidat Infinibox
INFINIBOX_HOST=10.x.x.x          # Replace with actual IP
INFINIBOX_USER=monitoring
INFINIBOX_PASSWORD=YourInfiniboxPassword

# VMware vCenter
VCENTER_HOST=10.x.x.x            # Replace with actual IP
VCENTER_USER=monitoring@vsphere.local
VCENTER_PASSWORD=YourVCenterPassword

# Network Device SNMP (used in config files)
NETWORK_SNMP_COMMUNITY=public    # Change if using different community
```

**Security Note**: Use strong passwords and consider using a secrets management solution for production.

### Step 3: Configure Device Details

#### 3.1 Configure Infinibox

```bash
nano config/infinidat.yml
```

Update with your Infinibox details:

```yaml
host: 10.x.x.x                    # Your Infinibox IP
username: monitoring
password: YourPassword
port: 9600
scrape_interval: 10
```

#### 3.2 Configure VMware vCenter

```bash
nano config/vmware.yml
```

Update with your vCenter details:

```yaml
host: 10.x.x.x                    # Your vCenter IP
username: monitoring@vsphere.local
password: YourPassword
port: 9601
scrape_interval: 15
```

#### 3.3 Configure Brocade FC Switches

```bash
nano config/brocade.yml
```

Update with your 4 Brocade DB720S switch details:

```yaml
port: 9602
scrape_interval: 10

switches:
  - name: brocade-fc-switch-01
    host: 10.x.x.101              # First switch IP
    community: public             # Your SNMP community
    model: DB720S
    
  - name: brocade-fc-switch-02
    host: 10.x.x.102              # Second switch IP
    community: public
    model: DB720S
    
  - name: brocade-fc-switch-03
    host: 10.x.x.103              # Third switch IP
    community: public
    model: DB720S
    
  - name: brocade-fc-switch-04
    host: 10.x.x.104              # Fourth switch IP
    community: public
    model: DB720S
```

#### 3.4 Configure Juniper Switches

```bash
nano config/juniper.yml
```

Update with your Juniper switch details (adjust based on your actual topology):

```yaml
port: 9603
scrape_interval: 10

switches:
  # QFX5120 Core Switches (Stacked)
  - name: juniper-qfx5120-core-01
    host: 10.x.x.201
    community: public
    model: QFX5120
    role: core
    
  - name: juniper-qfx5120-core-02
    host: 10.x.x.202
    community: public
    model: QFX5120
    role: core
    
  # QFX5110 Leaf Switches (add all your leaf switches)
  - name: juniper-qfx5110-leaf-01
    host: 10.x.x.211
    community: public
    model: QFX5110
    role: leaf
    
  # Add more leaf switches as needed
```

### Step 4: Validate Configuration

Before deploying, validate your configuration:

```bash
./scripts/validate.sh
```

This script will:
- Check Docker installation
- Verify network connectivity to all devices
- Validate configuration file syntax
- Test API/SNMP access

**Address any errors before proceeding.**

### Step 5: Deploy the Stack

Run the installation script:

```bash
./scripts/install.sh
```

The script will:
1. Pull all required Docker images
2. Build custom exporters
3. Start all services
4. Verify services are running
5. Display access information

Expected output:
```
✅ Pulling Docker images...
✅ Building custom exporters...
✅ Starting monitoring stack...
✅ Waiting for services to be healthy...
✅ All services are running!

Access Information:
- Grafana: http://YOUR_SERVER_IP:3000
  Username: admin
  Password: (from your .env file)
  
- Prometheus: http://YOUR_SERVER_IP:9090
- VictoriaMetrics: http://YOUR_SERVER_IP:8428

Next steps:
1. Access Grafana and verify dashboards are loaded
2. Check that metrics are being collected
3. Configure alerting (optional)
```

### Step 6: Verify Deployment

```bash
# Check all containers are running
docker-compose ps

# Should show all services as "Up" and "healthy"

# Check logs for any errors
docker-compose logs -f

# Ctrl+C to exit logs
```

## Configuration

### Adjust Scrape Intervals

If you need to change scrape frequencies:

**For higher frequency (more resource intensive):**

```bash
# Edit prometheus/prometheus.yml
nano prometheus/prometheus.yml

# Change scrape_interval for specific jobs
# Example: Change from 10s to 5s for Infinibox

# Restart Prometheus
docker-compose restart prometheus
```

**For lower frequency (less resource intensive):**

Change from 10s to 30s or 1m in the same way.

### Adjust Data Retention

**VictoriaMetrics retention (default: 30 days):**

```bash
# Edit docker-compose.yml
nano docker-compose.yml

# Under victoriametrics service, modify:
# '--retentionPeriod=30d'  # Change to 60d or 90d

# Restart VictoriaMetrics
docker-compose restart victoriametrics
```

**Prometheus retention (default: 2 days):**

```bash
# Edit docker-compose.yml
nano docker-compose.yml

# Under prometheus service, modify:
# '--storage.tsdb.retention.time=2d'

# Restart Prometheus
docker-compose restart prometheus
```

## Topology Visualization Setup

The topology visualization feature provides end-to-end path visibility from Infinibox volumes through the FC network to virtual machines. This section guides you through deploying the topology correlation components.

### Overview

**What Gets Deployed:**
- PostgreSQL database for storing topology relationships
- Topology Correlator service that discovers and correlates paths
- Enhanced exporter metrics for topology data
- Grafana dashboard for visualization

**Time Required:** 30-45 minutes

### Step 1: Install PostgreSQL Database

#### 1.1 Install PostgreSQL

```bash
# Install PostgreSQL
sudo apt-get install -y postgresql postgresql-contrib

# Start and enable PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Verify installation
sudo systemctl status postgresql
```

#### 1.2 Create Topology Database

```bash
# Switch to postgres user and create database
sudo -u postgres psql <<EOF
CREATE DATABASE topology;
CREATE USER topology_user WITH PASSWORD 'CHANGE_THIS_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE topology TO topology_user;
\q
EOF
```

**Security Note**: Replace `CHANGE_THIS_PASSWORD` with a strong password. Store this securely as you'll need it for the correlator service configuration.

#### 1.3 Apply Database Schema

```bash
# Navigate to the topology correlator directory
cd /opt/Organization_monitoring/services/topology-correlator

# Apply the schema
sudo -u postgres psql -d topology -f schema.sql

# Verify tables were created
sudo -u postgres psql -d topology -c "\dt"
```

Expected output should show 19+ tables including:
- `volumes`, `host_mappings`, `fc_zones`, `fc_ports`
- `esxi_hosts`, `esxi_hbas`, `datastores`, `vms`
- `topology_paths`, `path_relationships`

### Step 2: Deploy Topology Correlator Service

The topology correlator service queries all exporters, correlates the data, and builds complete topology paths.

#### 2.1 Option A: Docker Deployment (Recommended)

```bash
# Navigate to the service directory
cd /opt/Organization_monitoring/services/topology-correlator

# Edit the docker-compose.yml to set your database password
nano docker-compose.yml

# Update the DATABASE_PASSWORD environment variable:
# environment:
#   - DATABASE_PASSWORD=YOUR_PASSWORD_HERE

# Deploy the service
docker-compose up -d

# Check service status
docker-compose ps

# View logs
docker-compose logs -f topology-correlator
```

#### 2.2 Option B: Systemd Service Deployment

```bash
cd /opt/Organization_monitoring/services/topology-correlator

# Install Python dependencies
pip3 install -r requirements.txt

# Edit configuration file
nano config.yml

# Update these settings:
# database:
#   host: localhost
#   port: 5432
#   name: topology
#   user: topology_user
#   password: YOUR_PASSWORD_HERE

# Copy systemd service file
sudo cp topology-correlator.service /etc/systemd/system/

# Edit service file if needed (adjust paths)
sudo nano /etc/systemd/system/topology-correlator.service

# Start the service
sudo systemctl daemon-reload
sudo systemctl start topology-correlator
sudo systemctl enable topology-correlator

# Check status
sudo systemctl status topology-correlator
```

#### 2.3 Verify Correlator Service

```bash
# Check health endpoint
curl http://localhost:9700/health

# Expected output:
# {"status": "healthy", "version": "1.0.0"}

# Check metrics
curl http://localhost:9700/metrics | grep topology

# Expected metrics include:
# topology_paths_total
# topology_volumes_total
# topology_correlation_duration_seconds
```

### Step 3: Configure Prometheus to Scrape Topology Correlator

```bash
# Edit Prometheus configuration
nano /opt/Organization_monitoring/prometheus/prometheus.yml

# Add this scrape job at the end:
```

Add the following to the `scrape_configs` section:

```yaml
  # Topology Correlation Service
  - job_name: 'topology-correlator'
    scrape_interval: 30s
    static_configs:
      - targets: ['localhost:9700']
        labels:
          service: 'topology-correlation'
```

```bash
# Restart Prometheus to apply changes
docker-compose restart prometheus

# Verify the target is up
# Open Prometheus UI: http://YOUR_SERVER_IP:9090
# Go to Status → Targets
# Look for "topology-correlator" - should show as UP
```

### Step 4: Configure PostgreSQL Data Source in Grafana

#### 4.1 Add Data Source

1. Open Grafana in your browser: `http://YOUR_SERVER_IP:3000`
2. Login with your admin credentials
3. Navigate to **Configuration** (⚙️) → **Data Sources**
4. Click **Add data source**
5. Select **PostgreSQL**

#### 4.2 Configure Connection

Fill in the following details:

| Field | Value |
|-------|-------|
| **Name** | `PostgreSQL-Topology` |
| **Host** | `localhost:5432` |
| **Database** | `topology` |
| **User** | `topology_user` |
| **Password** | Your database password |
| **SSL Mode** | `disable` (for local connections) |
| **Version** | `12+` |
| **TimescaleDB** | Leave unchecked |

Click **Save & Test** - you should see a green "Database Connection OK" message.

### Step 5: Import Topology Dashboard

#### 5.1 Copy Dashboard File

```bash
# Option 1: Copy to Grafana dashboards directory
sudo cp /opt/Organization_monitoring/grafana/dashboards/topology_endtoend.json \
    /var/lib/grafana/dashboards/

# Restart Grafana to detect new dashboard
docker-compose restart grafana
```

#### 5.2 Or Import via Grafana UI

1. In Grafana, click **+** → **Import**
2. Click **Upload JSON file**
3. Select `/opt/Organization_monitoring/grafana/dashboards/topology_endtoend.json`
4. In the import screen:
   - For Prometheus data source: Select your existing Prometheus/VictoriaMetrics
   - For PostgreSQL data source: Select `PostgreSQL-Topology`
5. Click **Import**

#### 5.3 Verify Dashboard

1. Navigate to **Dashboards** → **Browse**
2. Look for **End-to-End Topology Visualization**
3. Open the dashboard
4. You should see panels for:
   - Total paths discovered
   - Mapped volumes count
   - Datastores and VMs
   - Complete topology paths table
   - Volume path visualization

**Note**: Initially, the dashboard may show 0 paths. This is normal until the first correlation cycle completes (60 seconds by default).

### Step 6: Run Initial Topology Discovery

The discovery scripts perform one-time comprehensive topology mapping using direct API calls and SNMP.

#### 6.1 Configure FC Topology Discovery

```bash
# Navigate to scripts directory
cd /opt/Organization_monitoring/scripts/topology

# Run the script once to generate config template
./discover-fc-topology.sh

# Edit the configuration file
nano fc-topology-config.yml
```

Update with your environment details:

```yaml
infinibox:
  host: YOUR_INFINIBOX_IP
  user: monitoring
  password: YOUR_INFINIBOX_PASSWORD
  api_port: 443

brocade:
  switches:
    - name: brocade-fc-01
      host: 10.x.x.101
      snmp_community: public
    - name: brocade-fc-02
      host: 10.x.x.102
      snmp_community: public
    # Add all 4 switches...

vcenter:
  host: YOUR_VCENTER_IP
  user: YOUR_VCENTER_USER
  password: YOUR_VCENTER_PASSWORD
  verify_ssl: false

database:
  enabled: true
  host: localhost
  port: 5432
  name: topology
  user: topology_user
  password: YOUR_DB_PASSWORD
```

#### 6.2 Run FC Topology Discovery

```bash
# Run the discovery script
./discover-fc-topology.sh

# Monitor the log output
tail -f ../../logs/fc_topology_$(date +%Y%m%d)*.log

# Check the generated output file
cat ../../output/topology/fc_topology_*.json | jq . | less
```

The script will:
1. Query Infinibox for volumes, hosts, and LUN mappings
2. Query Brocade switches for port WWPNs and FC zones
3. Query vCenter for ESXi HBA information
4. Correlate WWPNs across all components
5. Store results in the topology database

#### 6.3 Run Network Topology Discovery (Optional)

For iSCSI and NFS paths:

```bash
# Configure network discovery
./discover-network-topology.sh  # First run creates config
nano network-topology-config.yml  # Edit with your settings

# Run network discovery
./discover-network-topology.sh

# View results
cat ../../output/topology/network_topology_*.json | jq .
```

### Step 7: Verify Topology Data

#### 7.1 Check Database Population

```bash
# Connect to PostgreSQL
sudo -u postgres psql -d topology

# Check row counts in key tables
SELECT 
    'volumes' as table_name, COUNT(*) as rows FROM volumes
UNION ALL
SELECT 'host_mappings', COUNT(*) FROM host_mappings
UNION ALL
SELECT 'fc_zones', COUNT(*) FROM fc_zones
UNION ALL
SELECT 'esxi_hbas', COUNT(*) FROM esxi_hbas
UNION ALL
SELECT 'datastores', COUNT(*) FROM datastores
UNION ALL
SELECT 'vms', COUNT(*) FROM vms
UNION ALL
SELECT 'topology_paths', COUNT(*) FROM topology_paths;

# View sample topology paths
SELECT * FROM v_complete_paths LIMIT 5;

# Exit
\q
```

#### 7.2 Query Topology via API

```bash
# Get all discovered paths
curl -s http://localhost:9700/api/v1/topology/paths | jq .

# Get path for a specific volume (replace with your volume name)
curl -s http://localhost:9700/api/v1/topology/volume/prod-vol-01 | jq .

# Get path for a specific VM (replace with your VM name)
curl -s http://localhost:9700/api/v1/topology/vm/web-server-01 | jq .
```

#### 7.3 View in Grafana Dashboard

1. Open **End-to-End Topology Visualization** dashboard
2. Use the **Volume** dropdown to select a volume
3. View the complete path visualization
4. Check performance metrics across all layers
5. Review FC zone configuration and port status

### Step 8: Schedule Periodic Topology Updates

Set up automated topology discovery to keep the data current.

```bash
# Edit crontab
crontab -e

# Add these entries:

# Run FC topology discovery daily at 2 AM
0 2 * * * /opt/Organization_monitoring/scripts/topology/discover-fc-topology.sh >> /opt/Organization_monitoring/logs/cron_fc_topology.log 2>&1

# Run network topology discovery daily at 3 AM
0 3 * * * /opt/Organization_monitoring/scripts/topology/discover-network-topology.sh >> /opt/Organization_monitoring/logs/cron_network_topology.log 2>&1

# Clean up old topology data weekly (keep 30 days)
0 4 * * 0 psql -h localhost -U topology_user -d topology -c "SELECT cleanup_old_data(30);" >> /opt/Organization_monitoring/logs/cron_topology_cleanup.log 2>&1
```

### Topology Metrics Reference

Once deployed, you'll have access to these topology-specific metrics:

**Topology Correlation Metrics** (from correlator service):
```
topology_paths_total                    # Total end-to-end paths discovered
topology_volumes_total                  # Volumes with mappings
topology_hosts_total                    # Hosts with LUN mappings
topology_vms_total                      # VMs discovered
topology_datastores_total               # Datastores mapped
topology_fc_zones_total                 # FC zones configured
topology_path_health                    # Path health status (1=healthy)
topology_correlation_duration_seconds   # Time to complete correlation
topology_last_update_timestamp          # Last successful update
```

**Infinibox Topology Metrics** (from enhanced exporter):
```
infinibox_lun_mapping{host_id,volume_id,lun_id}              # LUN mappings
infinibox_host_initiator_info{host_id,type,address}          # Host WWPNs/IQNs
infinibox_fc_port_info{port_id,wwpn}                         # Infinibox FC ports
```

**Brocade Topology Metrics** (from enhanced exporter):
```
brocade_port_wwpn_info{switch,port,wwpn}                     # FC port WWPNs
brocade_fc_zone_info{switch,zone_name,zoneset}               # FC zones
brocade_zone_member_info{zone_name,member_wwpn}              # Zone membership
```

### Troubleshooting Topology Deployment

#### No Topology Paths Showing

**Check**:
1. Verify all exporters are running and providing topology metrics
2. Check correlator service logs for errors
3. Ensure database connection is working
4. Trigger manual correlation: `curl -X POST http://localhost:9700/api/v1/topology/correlate`

```bash
# Check exporter metrics
curl http://localhost:9600/metrics | grep infinibox_lun_mapping | wc -l

# Check correlator logs
docker logs topology-correlator  # For Docker deployment
# OR
sudo journalctl -u topology-correlator -f  # For systemd deployment
```

#### Database Connection Errors

**Check**:
1. PostgreSQL is running: `sudo systemctl status postgresql`
2. Database exists: `sudo -u postgres psql -l | grep topology`
3. User has permissions: `sudo -u postgres psql -d topology -c "\du"`
4. Password is correct in config file

#### Grafana Dashboard Shows "N/A"

**Check**:
1. PostgreSQL data source is configured and tested
2. Data exists in database: `sudo -u postgres psql -d topology -c "SELECT COUNT(*) FROM topology_paths;"`
3. Dashboard queries are using correct data source
4. Check Grafana logs: `docker logs grafana` or `sudo journalctl -u grafana-server`

#### Discovery Scripts Fail

**Check**:
1. All credentials in config files are correct
2. Network connectivity to devices
3. Required tools installed: `jq`, `curl`, `snmpwalk`
4. Check script logs in `/opt/Organization_monitoring/logs/`

For detailed troubleshooting, see **[TOPOLOGY_DEPLOYMENT.md](TOPOLOGY_DEPLOYMENT.md)** in the docs folder.

### Topology Best Practices

1. **Initial Discovery**: Run discovery scripts manually first to validate configuration
2. **Monitoring**: Add topology correlation metrics to your monitoring alerts
3. **Maintenance**: Run database cleanup monthly to prevent unbounded growth
4. **Backups**: Include PostgreSQL topology database in your backup routine
5. **Documentation**: Document any custom zones or non-standard configurations
6. **Testing**: Test topology queries regularly to ensure correlation is working

---

## Validation

### 1. Verify Grafana Access

```bash
# Open browser
http://YOUR_SERVER_IP:3000

# Login with credentials from .env
# Username: admin
# Password: (your configured password)
```

### 2. Check Dashboards

Navigate to:
- **Dashboards → Organization → Organization Infrastructure Overview**

You should see:
- ✅ Infinibox status showing "UP"
- ✅ Active controllers count (should be 3)
- ✅ ESXi hosts online (should be 14)
- ✅ VMs running count
- ✅ Brocade FC switches online (should be 4)
- ✅ Juniper switches online

**If Topology is Deployed:**
- Navigate to **Dashboards → End-to-End Topology Visualization**
- You should see:
  - ✅ Total paths discovered (non-zero if correlation has run)
  - ✅ Mapped volumes count
  - ✅ Datastores and VMs count
  - ✅ Complete topology paths table with data
  - ✅ Volume dropdown selector populated with volume names
  - ✅ Performance metrics showing across the stack

### 3. Verify Metrics Collection

Check Prometheus targets:

```bash
# Open Prometheus UI
http://YOUR_SERVER_IP:9090

# Go to Status → Targets
# All targets should show as "UP" with green status
```

Expected targets:
- prometheus (self-monitoring)
- victoriametrics
- grafana
- infinibox
- vmware
- brocade-fc
- juniper
- topology-correlator (if topology is deployed)

### 4. Check Exporter Health

```bash
# Check Infinibox exporter
curl http://localhost:9600/metrics | head -20

# Check VMware exporter
curl http://localhost:9601/metrics | head -20

# Check Brocade exporter
curl http://localhost:9602/metrics | head -20

# Check Juniper exporter
curl http://localhost:9603/metrics | head -20

# If topology is deployed, check Topology Correlator
curl http://localhost:9700/health
curl http://localhost:9700/metrics | head -20
```

Each should return metrics in Prometheus format (or JSON for health endpoint).

## Post-Deployment

### Configure Alerting (Optional)

1. Review alert rules in `prometheus/rules/alerts.yml`
2. Configure Alertmanager (see CONFIGURATION_REFERENCE.md)
3. Set up notification channels (email, Slack, PagerDuty, etc.)

### Set Up Backups

```bash
# Run initial backup
./scripts/backup.sh

# Schedule daily backups via cron
crontab -e

# Add this line for daily backups at 2 AM:
0 2 * * * /opt/Organization_monitoring/scripts/backup.sh

# If topology is deployed, also backup PostgreSQL database:
0 2 * * * sudo -u postgres pg_dump topology | gzip > /backup/topology_$(date +\%Y\%m\%d).sql.gz
```

**Backup Locations:**
- Grafana dashboards and configuration: Included in `backup.sh`
- Prometheus/VictoriaMetrics data: Included in `backup.sh`
- Topology database: `/backup/topology_YYYYMMDD.sql.gz`

**Backup Retention:**
Consider setting up a retention policy to remove backups older than 30-90 days to manage disk space.

### Monitor the Monitoring System

```bash
# Set up a daily health check
crontab -e

# Add this line for hourly health checks:
0 * * * * /opt/Organization_monitoring/scripts/health-check.sh
```

### Document Your Deployment

Record the following in your internal documentation:
- Server IP addresses
- Access credentials (securely)
- Any customizations made
- Backup location
- Contact for support

## Troubleshooting

### Services Won't Start

```bash
# Check Docker status
sudo systemctl status docker

# Check logs for specific service
docker-compose logs [service-name]

# Common issues:
# - Port already in use: Change ports in docker-compose.yml
# - Permission denied: Run with sudo or fix permissions
# - Out of memory: Increase server RAM or reduce retention
```

### Exporters Show as "Down"

```bash
# Check exporter logs
docker-compose logs infinidat-exporter
docker-compose logs vmware-exporter
docker-compose logs brocade-exporter
docker-compose logs juniper-exporter

# Common issues:
# - Wrong credentials: Check config files
# - Network connectivity: Test ping and API access
# - Firewall blocking: Check firewall rules
```

### No Metrics in Grafana

```bash
# 1. Check Prometheus is collecting metrics
# Go to http://YOUR_SERVER_IP:9090/targets

# 2. Check datasource in Grafana
# Grafana → Configuration → Data Sources → Test

# 3. Check dashboard queries
# Edit a dashboard panel and check for query errors
```

### High CPU/Memory Usage

```bash
# Check resource usage
docker stats

# Common solutions:
# - Reduce scrape frequency
# - Limit VM collection (max_vms_to_collect in config)
# - Increase server resources
# - Reduce retention period
```

### Topology Issues (If Deployed)

#### No Topology Paths Showing

```bash
# Check if topology correlator is running
docker ps | grep topology-correlator
# OR
sudo systemctl status topology-correlator

# Check correlator logs for errors
docker logs topology-correlator
# OR
sudo journalctl -u topology-correlator -n 50

# Verify database connection
sudo -u postgres psql -d topology -c "SELECT COUNT(*) FROM topology_paths;"

# Trigger manual correlation
curl -X POST http://localhost:9700/api/v1/topology/correlate
```

#### Topology Dashboard Shows Empty or N/A

```bash
# Verify PostgreSQL data source in Grafana is configured
# Check if data exists in database
sudo -u postgres psql -d topology -c "SELECT COUNT(*) FROM v_complete_paths;"

# Ensure discovery scripts have been run at least once
cd /opt/Organization_monitoring/scripts/topology
./discover-fc-topology.sh
```

#### Discovery Scripts Fail

```bash
# Check configuration files
cat /opt/Organization_monitoring/scripts/topology/fc-topology-config.yml

# Verify credentials are correct
# Test connectivity to devices
ping -c 3 YOUR_INFINIBOX_IP
ping -c 3 YOUR_VCENTER_IP
curl -k https://YOUR_INFINIBOX_IP/api/rest/system

# Check script logs
tail -f /opt/Organization_monitoring/logs/fc_topology_*.log
```

For more troubleshooting, see [TROUBLESHOOTING.md](TROUBLESHOOTING.md) and [TOPOLOGY_DEPLOYMENT.md](TOPOLOGY_DEPLOYMENT.md).

## Next Steps

1. **Customize Dashboards**: Adjust dashboards to your needs
2. **Set Up Alerting**: Configure alerts for critical metrics
3. **Train Team**: Familiarize team with Grafana interface, including the new topology visualization
4. **Establish Procedures**: Document response procedures for alerts
5. **Regular Maintenance**: Schedule regular maintenance windows
6. **Topology Enhancement** (If deployed):
   - Review topology paths for completeness
   - Document any unmapped volumes or VMs
   - Schedule periodic topology audits
   - Use topology data for capacity planning and impact analysis

## Support

For additional assistance:
- Review [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
- Check logs: `docker-compose logs -f`
- Contact Open Source Community

---

**Congratulations!** Your Organization monitoring solution is now deployed and operational.
