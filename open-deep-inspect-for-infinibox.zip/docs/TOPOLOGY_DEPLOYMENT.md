# End-to-End Topology Visualization - Deployment Guide

**@codefromdom**
**Version:** 1.0.0  
**Date:** December 2, 2025

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Prerequisites](#prerequisites)
4. [Component Deployment](#component-deployment)
5. [Configuration](#configuration)
6. [Testing](#testing)
7. [Troubleshooting](#troubleshooting)
8. [Maintenance](#maintenance)

---

## Overview

This guide provides step-by-step instructions for deploying the complete end-to-end topology visualization and monitoring solution.

### What This Solution Provides

- **Complete Path Visibility**: Infinibox Volume → FC Zone → ESXi HBA → Datastore → VM
- **Real-time Topology Correlation**: Automatic discovery and correlation of relationships
- **Visual Dashboards**: Grafana dashboards showing complete end-to-end paths
- **Performance Monitoring**: Metrics across the entire stack
- **REST API**: Programmatic access to topology data

### Components

1. **Enhanced Infinibox Exporter**: Collects volume WWPNs, IQNs, host mappings, LUN data
2. **Enhanced Brocade Exporter**: Collects port WWPNs, FC zones, zone membership
3. **Topology Correlation Service**: Correlates data from all exporters
4. **PostgreSQL Database**: Stores topology relationships
5. **Grafana Dashboard**: Visualizes end-to-end paths
6. **Discovery Scripts**: One-time or periodic topology discovery

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      MONITORING LAYER                           │
│                                                                 │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │
│  │  Infinibox   │  │   Brocade    │  │    VMware    │        │
│  │  Exporter    │  │   Exporter   │  │   Exporter   │        │
│  │  :9600       │  │   :9602      │  │   :9605      │        │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘        │
│         │                  │                  │                 │
│         └──────────────────┼──────────────────┘                │
│                            │                                    │
│                   ┌────────▼────────┐                          │
│                   │   Prometheus    │                          │
│                   │   :9090         │                          │
│                   └────────┬────────┘                          │
│                            │                                    │
└────────────────────────────┼────────────────────────────────────┘
                             │
┌────────────────────────────┼────────────────────────────────────┐
│                 CORRELATION LAYER                               │
│                            │                                    │
│                   ┌────────▼────────┐                          │
│                   │   Topology      │                          │
│                   │   Correlator    │◄──────┐                 │
│                   │   :9700         │       │                 │
│                   └────────┬────────┘       │                 │
│                            │                │                 │
│                   ┌────────▼────────┐       │                 │
│                   │   PostgreSQL    │       │                 │
│                   │   :5432         │       │                 │
│                   └─────────────────┘       │                 │
│                                             │                 │
│  ┌──────────────────────────────────────────┘                │
│  │  Discovery Scripts (Periodic/On-Demand)                   │
│  │  - discover-fc-topology.sh                                │
│  │  - discover-network-topology.sh                           │
│  └───────────────────────────────────────────────────────────┘
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                             │
┌────────────────────────────┼────────────────────────────────────┐
│                  VISUALIZATION LAYER                            │
│                            │                                    │
│                   ┌────────▼────────┐                          │
│                   │    Grafana      │                          │
│                   │    :3000        │                          │
│                   └─────────────────┘                          │
│                                                                 │
│  Dashboards:                                                   │
│  - End-to-End Topology Visualization                          │
│  - Path Health Monitoring                                     │
│  - Performance Across Stack                                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Prerequisites

### System Requirements

- **Operating System**: Ubuntu 20.04 LTS or later (RHEL 8+ also supported)
- **CPU**: 4 cores minimum
- **RAM**: 8 GB minimum (16 GB recommended)
- **Disk**: 100 GB minimum for database and logs
- **Network**: Access to all monitored devices

### Software Requirements

```bash
# Install required packages
sudo apt-get update
sudo apt-get install -y \
    python3 \
    python3-pip \
    postgresql \
    postgresql-contrib \
    docker.io \
    docker-compose \
    jq \
    curl \
    snmp \
    git
```

### Network Access Requirements

| Component | Port | Protocol | Purpose |
|-----------|------|----------|---------|
| Infinibox | 443 | HTTPS | API access |
| Brocade Switches | 161 | SNMP | Metrics collection |
| Brocade Switches | 22 | SSH | Zone configuration (optional) |
| vCenter | 443 | HTTPS | API access |
| PostgreSQL | 5432 | TCP | Database |
| Topology Correlator | 9700 | HTTP | API & Metrics |
| Prometheus | 9090 | HTTP | Metrics scraping |
| Grafana | 3000 | HTTP | Dashboard access |

### Credentials Required

- Infinibox monitoring user credentials
- Brocade switch SNMP community string (and SSH credentials for zones)
- vCenter read-only user credentials
- PostgreSQL database credentials

---

## Component Deployment

### Step 1: Deploy Enhanced Infinibox Exporter

#### 1.1 Update Configuration

Edit `/opt/monitoring/config/infinibox.yml`:

```yaml
host: infinibox-mgmt.local
username: monitoring
password: YOUR_PASSWORD_HERE
exporter_port: 9600
scrape_interval: 5
```

#### 1.2 Restart Exporter

```bash
# If running as systemd service
sudo systemctl restart infinibox-exporter

# If running as Docker container
docker restart infinibox-exporter
```

#### 1.3 Verify Topology Metrics

```bash
# Check new topology metrics are being exported
curl http://localhost:9600/metrics | grep -E "infinibox_(lun_mapping|host_initiator|fc_port)"

# Expected output should include:
# infinibox_lun_mapping{host_id="...",volume_id="..."} 1
# infinibox_host_initiator_info{initiator_address="21:00:00:24:ff:..."} {...}
# infinibox_fc_port_info{port_id="1",wwpn="..."} {...}
```

---

### Step 2: Deploy Enhanced Brocade Exporter

#### 2.1 Update Configuration

Edit `/opt/monitoring/config/brocade.yml`:

```yaml
port: 9602
scrape_interval: 10

switches:
  - name: brocade-fc-01
    host: 10.0.1.10
    community: public
    active_ports: 56
  - name: brocade-fc-02
    host: 10.0.1.11
    community: public
    active_ports: 56
  - name: brocade-fc-03
    host: 10.0.1.12
    community: public
    active_ports: 56
  - name: brocade-fc-04
    host: 10.0.1.13
    community: public
    active_ports: 56
```

#### 2.2 Restart Exporter

```bash
sudo systemctl restart brocade-exporter
```

#### 2.3 Verify Topology Metrics

```bash
# Check WWPN and zone metrics
curl http://localhost:9602/metrics | grep -E "brocade_(port_wwpn|fc_zone)"

# Expected output:
# brocade_port_wwpn_info{switch_name="...",port_index="1",wwpn="..."} {...}
# brocade_fc_zone_info{switch_name="...",zone_name="..."} {...}
```

---

### Step 3: Deploy PostgreSQL Database

#### 3.1 Install and Configure PostgreSQL

```bash
# Install PostgreSQL
sudo apt-get install -y postgresql postgresql-contrib

# Start PostgreSQL
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

#### 3.2 Create Database and User

```bash
# Switch to postgres user
sudo -u postgres psql

# In PostgreSQL shell:
CREATE DATABASE topology;
CREATE USER topology_user WITH PASSWORD 'CHANGE_THIS_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE topology TO topology_user;
\q
```

#### 3.3 Apply Database Schema

```bash
# Apply the schema
cd /opt/monitoring/services/topology-correlator
sudo -u postgres psql -d topology -f schema.sql

# Verify tables were created
sudo -u postgres psql -d topology -c "\dt"
```

Expected output:
```
                List of relations
 Schema |         Name         | Type  |    Owner     
--------+----------------------+-------+--------------
 public | datastores           | table | topology_user
 public | esxi_hbas            | table | topology_user
 public | esxi_hosts           | table | topology_user
 public | fc_ports             | table | topology_user
 public | fc_switches          | table | topology_user
 public | fc_zone_members      | table | topology_user
 public | fc_zones             | table | topology_user
 public | fc_zonesets          | table | topology_user
 public | host_initiators      | table | topology_user
 public | host_mappings        | table | topology_user
 public | hosts                | table | topology_user
 public | lldp_neighbors       | table | topology_user
 public | network_switches     | table | topology_user
 public | path_relationships   | table | topology_user
 public | topology_paths       | table | topology_user
 public | vms                  | table | topology_user
 public | volume_iqns          | table | topology_user
 public | volume_wwpns         | table | topology_user
 public | volumes              | table | topology_user
```

---

### Step 4: Deploy Topology Correlation Service

#### 4.1 Option A: Docker Deployment (Recommended)

```bash
cd /opt/monitoring/services/topology-correlator

# Edit docker-compose.yml to set passwords
vim docker-compose.yml

# Deploy using Docker Compose
docker-compose up -d

# Check logs
docker-compose logs -f topology-correlator
```

#### 4.2 Option B: Systemd Service Deployment

```bash
cd /opt/monitoring/services/topology-correlator

# Install Python dependencies
pip3 install -r requirements.txt

# Edit configuration
vim config.yml

# Copy systemd service file
sudo cp topology-correlator.service /etc/systemd/system/

# Edit service file with correct paths
sudo vim /etc/systemd/system/topology-correlator.service

# Start service
sudo systemctl daemon-reload
sudo systemctl start topology-correlator
sudo systemctl enable topology-correlator

# Check status
sudo systemctl status topology-correlator
```

#### 4.3 Verify Correlation Service

```bash
# Check health endpoint
curl http://localhost:9700/health

# Check metrics
curl http://localhost:9700/metrics | grep topology

# Get all topology paths (should be empty initially)
curl http://localhost:9700/api/v1/topology/paths | jq .
```

Expected output:
```json
{
  "paths": [],
  "count": 0
}
```

---

### Step 5: Configure Prometheus

#### 5.1 Update Prometheus Configuration

Edit `/etc/prometheus/prometheus.yml`:

```yaml
scrape_configs:
  # Existing exporters...

  # Topology Correlation Service
  - job_name: 'topology-correlator'
    scrape_interval: 30s
    static_configs:
      - targets: ['localhost:9700']
        labels:
          service: 'topology-correlation'
```

#### 5.2 Reload Prometheus

```bash
# Reload configuration
sudo systemctl reload prometheus

# Or send SIGHUP
sudo killall -HUP prometheus
```

---

### Step 6: Deploy Grafana Dashboard

#### 6.1 Add PostgreSQL Data Source

1. Open Grafana: `http://your-grafana-server:3000`
2. Navigate to **Configuration → Data Sources**
3. Click **Add data source**
4. Select **PostgreSQL**
5. Configure:
   - **Name**: `PostgreSQL-Topology`
   - **Host**: `localhost:5432`
   - **Database**: `topology`
   - **User**: `topology_user`
   - **Password**: Your password
   - **SSL Mode**: `disable` (for local connections)
6. Click **Save & Test**

#### 6.2 Import Topology Dashboard

```bash
# Copy dashboard JSON
sudo cp /opt/monitoring/grafana/dashboards/topology_endtoend.json \
    /var/lib/grafana/dashboards/

# Or import via Grafana UI:
# 1. Click "+" → Import
# 2. Upload topology_endtoend.json
# 3. Select PostgreSQL-Topology as data source
# 4. Click Import
```

#### 6.3 Verify Dashboard

1. Navigate to **Dashboards → Browse**
2. Open **End-to-End Topology Visualization**
3. You should see:
   - Summary statistics (0 initially)
   - Empty tables (will populate after correlation)
   - Metric panels ready to display data

---

## Configuration

### Topology Correlation Service Configuration

Edit `/opt/monitoring/services/topology-correlator/config.yml`:

```yaml
# Database configuration
database:
  host: localhost
  port: 5432
  name: topology
  user: topology_user
  password: YOUR_DB_PASSWORD

# Exporter endpoints
exporters:
  infinibox: http://localhost:9600/metrics
  brocade: http://localhost:9602/metrics
  vmware: http://localhost:9605/metrics

# Correlation settings
correlation_interval: 60  # seconds (how often to run correlation)

# API settings
api_port: 9700

# Logging
log_level: INFO
```

### Discovery Scripts Configuration

#### FC Topology Discovery

Create `/opt/monitoring/scripts/topology/fc-topology-config.yml`:

```yaml
infinibox:
  host: infinibox-mgmt.local
  user: monitoring
  password: YOUR_PASSWORD
  api_port: 443

brocade:
  switches:
    - name: brocade-fc-01
      host: 10.0.1.10
      snmp_community: public
    - name: brocade-fc-02
      host: 10.0.1.11
      snmp_community: public
    - name: brocade-fc-03
      host: 10.0.1.12
      snmp_community: public
    - name: brocade-fc-04
      host: 10.0.1.13
      snmp_community: public

vcenter:
  host: vcenter.local
  user: administrator@vsphere.local
  password: YOUR_PASSWORD
  verify_ssl: false

database:
  enabled: true
  host: localhost
  port: 5432
  name: topology
  user: topology_user
  password: YOUR_PASSWORD
```

#### Network Topology Discovery

Create `/opt/monitoring/scripts/topology/network-topology-config.yml`:

```yaml
juniper:
  switches:
    - name: juniper-core-01
      host: 10.0.2.10
      user: admin
      password: YOUR_PASSWORD
      snmp_community: public
    - name: juniper-core-02
      host: 10.0.2.11
      user: admin
      password: YOUR_PASSWORD
      snmp_community: public

vcenter:
  host: vcenter.local
  user: administrator@vsphere.local
  password: YOUR_PASSWORD
  verify_ssl: false

discovery:
  enable_lldp: true
  enable_cdp: true
  enable_snmp: true
  timeout: 30

database:
  enabled: true
  host: localhost
  port: 5432
  name: topology
  user: topology_user
  password: YOUR_PASSWORD
```

---

## Testing

### Test 1: Verify Data Collection

```bash
# Check Infinibox topology metrics
curl -s http://localhost:9600/metrics | grep -c "infinibox_lun_mapping"

# Check Brocade topology metrics
curl -s http://localhost:9602/metrics | grep -c "brocade_port_wwpn"

# Expected: Non-zero counts
```

### Test 2: Run Manual Correlation

```bash
# Trigger immediate correlation via API
curl -X POST http://localhost:9700/api/v1/topology/correlate

# Check correlation metrics
curl -s http://localhost:9700/metrics | grep topology_paths_total

# Expected output:
# topology_paths_total 15.0  (or your actual count)
```

### Test 3: Verify Database Population

```bash
# Connect to database
sudo -u postgres psql -d topology

# Check data in key tables
SELECT COUNT(*) FROM volumes;
SELECT COUNT(*) FROM host_mappings;
SELECT COUNT(*) FROM fc_zones;
SELECT COUNT(*) FROM topology_paths;

# View sample data
SELECT volume_name, volume_serial FROM volumes LIMIT 5;
SELECT host_name, volume_id, lun_id FROM host_mappings LIMIT 5;

# Exit
\q
```

### Test 4: Query Topology Paths

```bash
# Get all paths
curl -s http://localhost:9700/api/v1/topology/paths | jq '.paths | length'

# Get path for specific volume
curl -s http://localhost:9700/api/v1/topology/volume/vol-prod-01 | jq .

# Expected: JSON with complete path information
```

### Test 5: Run Discovery Scripts

```bash
# Run FC topology discovery
cd /opt/monitoring/scripts/topology
./discover-fc-topology.sh

# Check output
tail -f ../../logs/fc_topology_*.log

# Run network topology discovery
./discover-network-topology.sh

# Check output
tail -f ../../logs/network_topology_*.log
```

### Test 6: Verify Grafana Dashboard

1. Open Grafana dashboard
2. Select a volume from the dropdown
3. Verify you see:
   - Complete path from Volume → VM
   - Performance metrics
   - FC zone information
   - Host initiator details

---

## Troubleshooting

### Issue: No Topology Data Appearing

**Symptoms**: Dashboard shows 0 paths, database tables are empty

**Solutions**:

1. Check exporter connectivity:
```bash
# Test each exporter
curl http://localhost:9600/metrics | head
curl http://localhost:9602/metrics | head
curl http://localhost:9605/metrics | head
```

2. Check correlation service logs:
```bash
# Docker
docker logs topology-correlator

# Systemd
sudo journalctl -u topology-correlator -f
```

3. Verify database connection:
```bash
# Test from correlation service host
psql -h localhost -U topology_user -d topology -c "SELECT version();"
```

4. Manual correlation trigger:
```bash
curl -X POST http://localhost:9700/api/v1/topology/correlate
```

---

### Issue: Incomplete Path Information

**Symptoms**: Some paths show "Unknown" or missing components

**Solutions**:

1. Check which data is missing:
```sql
-- Check for volumes without mappings
SELECT v.volume_name FROM volumes v
LEFT JOIN host_mappings hm ON v.volume_id = hm.volume_id
WHERE hm.host_id IS NULL;

-- Check for hosts without initiators
SELECT h.host_name FROM hosts h
LEFT JOIN host_initiators hi ON h.host_id = hi.host_id
WHERE hi.id IS NULL;
```

2. Verify exporter metrics include topology data:
```bash
# Check for specific metrics
curl -s http://localhost:9600/metrics | grep "infinibox_lun_mapping{" | head -5
curl -s http://localhost:9602/metrics | grep "brocade_port_wwpn{" | head -5
```

3. Check FC zone configuration:
```bash
# Zones might not be available via SNMP - may need SSH access
# Check Brocade exporter logs for errors
docker logs brocade-exporter 2>&1 | grep -i zone
```

---

### Issue: High Database Size

**Symptoms**: PostgreSQL using too much disk space

**Solutions**:

1. Check database size:
```sql
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename))
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

2. Run cleanup function:
```sql
-- Delete data older than 7 days
SELECT cleanup_old_data(7);

-- Vacuum database
VACUUM ANALYZE;
```

3. Adjust retention in correlation service configuration

---

### Issue: Slow Dashboard Performance

**Symptoms**: Grafana dashboard takes long to load

**Solutions**:

1. Check database query performance:
```sql
-- Enable query timing
\timing on

-- Test slow queries
EXPLAIN ANALYZE 
SELECT * FROM v_complete_paths;
```

2. Ensure indexes exist:
```sql
-- Check indexes
SELECT tablename, indexname FROM pg_indexes WHERE schemaname = 'public';

-- Recreate if missing
CREATE INDEX CONCURRENTLY idx_volumes_name ON volumes(volume_name);
```

3. Reduce dashboard refresh interval:
   - Change from 30s to 1m or 5m

---

### Issue: Discovery Scripts Fail

**Symptoms**: Scripts exit with errors

**Solutions**:

1. Check dependencies:
```bash
# Verify all required tools are installed
jq --version
curl --version
python3 --version
snmpwalk -V
```

2. Verify configurations:
```bash
# Check config file exists and is valid YAML
cat scripts/topology/fc-topology-config.yml
python3 -c "import yaml; yaml.safe_load(open('scripts/topology/fc-topology-config.yml'))"
```

3. Test connectivity:
```bash
# Test Infinibox API
curl -sk -u monitoring:password https://infinibox-mgmt.local/api/rest/system

# Test SNMP
snmpwalk -v2c -c public brocade-fc-01 sysDescr
```

4. Check logs:
```bash
tail -f logs/fc_topology_*.log
```

---

## Maintenance

### Daily Tasks

1. **Check Service Health**
```bash
# Check all services are running
systemctl status infinibox-exporter
systemctl status brocade-exporter
systemctl status vmware-exporter
systemctl status topology-correlator
systemctl status postgresql
```

2. **Monitor Correlation Status**
```bash
# Check last successful correlation
curl -s http://localhost:9700/metrics | grep topology_last_update

# Check for errors
curl -s http://localhost:9700/metrics | grep topology_correlation_errors_total
```

### Weekly Tasks

1. **Database Maintenance**
```sql
-- Connect to database
sudo -u postgres psql -d topology

-- Run cleanup
SELECT cleanup_old_data(7);

-- Vacuum and analyze
VACUUM ANALYZE;

-- Check database size
SELECT pg_size_pretty(pg_database_size('topology'));
```

2. **Run Discovery Scripts**
```bash
# Update topology data
cd /opt/monitoring/scripts/topology
./discover-fc-topology.sh
./discover-network-topology.sh
```

3. **Review Logs**
```bash
# Check for errors in correlation service
sudo journalctl -u topology-correlator --since "7 days ago" | grep -i error

# Check exporter logs
docker logs infinibox-exporter 2>&1 | grep -i error
docker logs brocade-exporter 2>&1 | grep -i error
```

### Monthly Tasks

1. **Update Credentials** (if rotated)
   - Update exporter configurations
   - Update discovery script configurations
   - Update correlation service database credentials

2. **Review Capacity**
```bash
# Check disk usage
df -h /var/lib/postgresql

# Check log sizes
du -sh /opt/monitoring/logs/*
```

3. **Backup Database**
```bash
# Backup topology database
sudo -u postgres pg_dump topology > /backup/topology_$(date +%Y%m%d).sql

# Compress
gzip /backup/topology_$(date +%Y%m%d).sql
```

### Periodic Updates

1. **Update Discovery Scripts**
```bash
cd /opt/monitoring
git pull origin main

# Restart services if needed
systemctl restart topology-correlator
```

2. **Update Dashboard**
   - Import new dashboard versions from Grafana UI
   - Test changes in dev environment first

---

## Automated Deployment Script

For quick deployment, use this script:

```bash
#!/bin/bash
# deploy-topology.sh

set -e

echo "=========================================="
echo "Topology Visualization Deployment"
echo "=========================================="

# 1. Install dependencies
echo "Installing dependencies..."
sudo apt-get update
sudo apt-get install -y postgresql docker.io docker-compose jq curl python3-pip

# 2. Setup database
echo "Setting up database..."
sudo systemctl start postgresql
sudo systemctl enable postgresql

sudo -u postgres psql <<EOF
CREATE DATABASE topology;
CREATE USER topology_user WITH PASSWORD 'changeme';
GRANT ALL PRIVILEGES ON DATABASE topology TO topology_user;
EOF

# 3. Apply schema
echo "Applying database schema..."
sudo -u postgres psql -d topology -f services/topology-correlator/schema.sql

# 4. Deploy correlation service
echo "Deploying correlation service..."
cd services/topology-correlator
docker-compose up -d

# 5. Configure Prometheus
echo "Configuring Prometheus..."
# Add scrape config...

# 6. Import Grafana dashboard
echo "Import Grafana dashboard manually via UI"

echo "=========================================="
echo "Deployment Complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Configure exporters with topology metrics"
echo "2. Update correlation service config.yml"
echo "3. Import Grafana dashboard"
echo "4. Run discovery scripts"
echo ""
echo "Verify: curl http://localhost:9700/health"
```

---

## Support

For issues or questions:
- **Open Source Community**: support@infinidat.com
- **Organization IT**: it-support@Organization.local
- **Documentation**: `/opt/monitoring/docs/`
- **Logs**: `/opt/monitoring/logs/`

---

## Appendix A: Service Ports Reference

| Service | Port | Purpose |
|---------|------|---------|
| Infinibox Exporter | 9600 | Metrics & Health |
| Brocade Exporter | 9602 | Metrics & Health |
| VMware Exporter | 9605 | Metrics & Health |
| Topology Correlator | 9700 | API & Metrics |
| PostgreSQL | 5432 | Database |
| Prometheus | 9090 | Metrics Collection |
| Grafana | 3000 | Dashboards |

## Appendix B: Database Schema Reference

See `services/topology-correlator/schema.sql` for complete schema details.

Key tables:
- `volumes` - Infinibox volumes
- `host_mappings` - LUN mappings
- `fc_zones` - FC zone configurations
- `esxi_hbas` - ESXi HBA information
- `datastores` - VMware datastores
- `vms` - Virtual machines
- `topology_paths` - Complete correlated paths

## Appendix C: API Reference

### Topology Correlator REST API

**Base URL**: `http://localhost:9700`

#### Endpoints

```
GET  /health                           - Health check
GET  /metrics                          - Prometheus metrics
GET  /api/v1/topology/paths            - Get all topology paths
GET  /api/v1/topology/volume/{name}    - Get path for volume
GET  /api/v1/topology/vm/{name}        - Get path for VM
POST /api/v1/topology/correlate        - Trigger immediate correlation
```

#### Example Responses

**Get All Paths**:
```bash
curl http://localhost:9700/api/v1/topology/paths
```

```json
{
  "paths": [
    {
      "path_id": "vol123_host456",
      "volume_name": "prod-db-vol-01",
      "volume_id": "vol123",
      "host_mappings": ["esx-host-01"],
      "fc_zones": ["zone_infinibox_to_esx01"],
      "esxi_hosts": ["esx-host-01.local"],
      "datastores": ["prod-datastore-01"],
      "vms": ["db-server-01", "db-server-02"],
      "health_status": "healthy",
      "last_update": "2025-10-22T10:30:00Z"
    }
  ],
  "count": 1
}
```

---

**End of Deployment Guide**
