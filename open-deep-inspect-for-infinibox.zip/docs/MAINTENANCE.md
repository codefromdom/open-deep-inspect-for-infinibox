# Maintenance Guide

**open-deep-inspect-for-infinibox**  
**@codefromdom**
**Version:** 1.0.0  
**Date:** December 2, 2025

## Regular Maintenance Tasks

### Daily Tasks

#### Health Check
```bash
cd /opt/Organization_monitoring
./scripts/health-check.sh
```

**What it checks**:
- All services running
- Prometheus targets up
- Grafana responding
- Disk space available
- Memory usage

**Action**: Review output for any warnings or errors.

### Weekly Tasks

#### Review Dashboards
- Check all four main dashboards for anomalies
- Verify data is being collected
- Look for any "No data" panels

#### Check Logs for Errors
```bash
docker-compose logs --since 7d | grep -i error
```

#### Verify Backups
```bash
ls -lh backups/
# Ensure recent backups exist
```

### Monthly Tasks

#### Update Software
```bash
# Backup first
./scripts/backup.sh

# Pull latest images
docker-compose pull

# Restart with new images
docker-compose up -d

# Verify all services are running
./scripts/health-check.sh
```

#### Review and Optimize
- Check disk space usage trends
- Review and adjust retention policies if needed
- Optimize dashboard queries if slow
- Review alert thresholds

#### Rotate Credentials
Best practice: Rotate monitoring credentials quarterly
1. Update credentials on monitored devices
2. Update `.env` and config files
3. Restart affected exporters
4. Verify connectivity

### Quarterly Tasks

#### Full System Review
- Review capacity planning
- Assess need for scaling
- Update documentation with any changes
- Test disaster recovery procedures

#### Performance Tuning
```bash
# Check Prometheus query performance
curl http://localhost:9090/api/v1/status/tsdb

# Check VictoriaMetrics metrics
curl http://localhost:8428/metrics | grep vm_
```

#### Audit and Compliance
- Review access logs
- Verify security configurations
- Check for unused dashboards/users
- Document any changes made

## Backup Procedures

### Automated Daily Backups

Set up via cron:
```bash
crontab -e

# Add this line for daily backups at 2 AM:
0 2 * * * /opt/Organization_monitoring/scripts/backup.sh
```

### Manual Backup
```bash
./scripts/backup.sh
```

**Backup includes**:
- Configuration files
- Grafana dashboards and settings
- Prometheus rules
- Environment variables

**Backup location**: `backups/backup_YYYYMMDD_HHMMSS.tar.gz`

**Retention**: Script automatically keeps last 7 days

### Restore Procedure

1. Extract backup:
   ```bash
   cd /opt/Organization_monitoring
   tar -xzf backups/backup_YYYYMMDD_HHMMSS.tar.gz
   ```

2. Stop services:
   ```bash
   docker-compose down
   ```

3. Restore files:
   ```bash
   cp -r backup_YYYYMMDD_HHMMSS/config/* config/
   cp backup_YYYYMMDD_HHMMSS/.env .env
   cp -r backup_YYYYMMDD_HHMMSS/prometheus/* prometheus/
   cp -r backup_YYYYMMDD_HHMMSS/grafana_dashboards/* grafana/dashboards/
   ```

4. Restore Grafana data (if backed up):
   ```bash
   docker run --rm -v open-deep-inspect-for-infinibox_grafana-data:/data \
     -v $(pwd)/backup_YYYYMMDD_HHMMSS:/backup alpine \
     tar xzf /backup/grafana-data.tar.gz -C /
   ```

5. Restart:
   ```bash
   docker-compose up -d
   ./scripts/health-check.sh
   ```

## Update Procedures

### Update Exporter Code

If you modify exporter code:

```bash
# Rebuild specific exporter
docker-compose build infinidat-exporter
docker-compose up -d infinidat-exporter

# Or rebuild all
docker-compose build
docker-compose up -d
```

### Update Configuration

**Prometheus configuration**:
```bash
nano prometheus/prometheus.yml
# Make changes
docker-compose restart prometheus
```

**Exporter configuration**:
```bash
nano config/infinidat.yml  # or vmware.yml, etc.
docker-compose restart infinidat-exporter  # or appropriate exporter
```

**Grafana provisioning**:
```bash
# Dashboards are auto-loaded on Grafana startup
# For changes to take effect:
docker-compose restart grafana
```

### Update Docker Images

```bash
# Check current versions
docker-compose images

# Pull latest versions
docker-compose pull

# Apply updates
docker-compose up -d

# Verify
./scripts/health-check.sh
```

## Monitoring Best Practices

### Dashboard Usage

1. **Use appropriate time ranges**
   - Real-time monitoring: Last 5-15 minutes
   - Troubleshooting: Last 1-6 hours
   - Trend analysis: Last 7-30 days

2. **Leverage variables and filters**
   - Filter by specific hosts/devices
   - Compare time ranges
   - Use annotations for incidents

3. **Create custom dashboards**
   - Copy existing dashboards
   - Customize for your needs
   - Share with team

### Alert Management

1. **Review alerts regularly**
   - Check for false positives
   - Adjust thresholds as needed
   - Add new alerts for emerging issues

2. **Document alert responses**
   - Create runbooks for common alerts
   - Define escalation procedures
   - Track MTTR (Mean Time To Resolution)

### Data Retention

**Current setup**:
- Prometheus: 2 days (high resolution)
- VictoriaMetrics: 30 days

**To adjust**:
```bash
# Edit docker-compose.yml
nano docker-compose.yml

# VictoriaMetrics retention:
# '--retentionPeriod=60d'  # Change to 60 days

# Prometheus retention:
# '--storage.tsdb.retention.time=3d'  # Change to 3 days

# Restart services
docker-compose up -d
```

**Considerations**:
- Longer retention = more disk space
- Balance retention vs. storage costs
- Consider archiving to object storage for very long-term needs

## Troubleshooting Common Maintenance Issues

### Service Won't Restart

```bash
# Check logs
docker-compose logs [service-name]

# Force recreate
docker-compose up -d --force-recreate [service-name]

# Last resort: remove and recreate
docker-compose rm -f [service-name]
docker-compose up -d [service-name]
```

### Dashboard Changes Not Applying

```bash
# Grafana caches dashboards
# Solution 1: Restart Grafana
docker-compose restart grafana

# Solution 2: Clear browser cache
# Ctrl+Shift+R in browser

# Solution 3: Re-provision
docker-compose down grafana
docker-compose up -d grafana
```

### Metrics Gaps After Restart

This is normal. Historical data in Prometheus is preserved, but:
- Short gap during restart
- VictoriaMetrics retains all data
- New metrics start collecting immediately

### High Resource Usage After Update

```bash
# Check what's consuming resources
docker stats

# Roll back if necessary
docker-compose down
# Restore from backup
./scripts/backup.sh  # Use recent backup
# Follow restore procedure
```

## Capacity Planning

### Monitor Growth

Track these metrics monthly:
- Disk space usage trend
- Memory usage trend
- Number of time series
- Query performance

### When to Scale

**Disk space**:
- Warning: > 70% used
- Action: > 80% used (add space or reduce retention)

**Memory**:
- Warning: > 80% used
- Action: > 90% used (add RAM or optimize)

**CPU**:
- Warning: > 70% sustained
- Action: > 85% sustained (add cores or optimize)

### Scaling Options

**Vertical scaling** (recommended for single node):
```bash
# Increase server resources
# - Add more CPU cores
# - Add more RAM
# - Add more disk space

# No configuration changes needed
# Docker will use available resources
```

**Horizontal scaling** (for multiple sites):
- Deploy separate monitoring stacks per site
- Use Prometheus federation for central view
- Consider VictoriaMetrics cluster mode

## Log Management

### View Logs

```bash
# All services
docker-compose logs -f

# Specific service
docker-compose logs -f grafana

# Last N lines
docker-compose logs --tail=100 prometheus

# Since specific time
docker-compose logs --since 24h
```

### Rotate Logs

Docker handles log rotation automatically, but you can configure:

```bash
# Edit /etc/docker/daemon.json
sudo nano /etc/docker/daemon.json

# Add:
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}

# Restart Docker
sudo systemctl restart docker
```

### Export Logs for Analysis

```bash
# Export last 24 hours
docker-compose logs --since 24h > logs_$(date +%Y%m%d).txt

# Export specific service
docker-compose logs grafana > grafana_logs.txt
```

## Security Maintenance

### Regular Security Tasks

1. **Update passwords quarterly**
   ```bash
   # Update .env
   nano .env
   # Update Grafana admin password
   docker-compose exec grafana grafana-cli admin reset-admin-password newpass
   ```

2. **Review access logs monthly**
   ```bash
   docker-compose logs grafana | grep -i login
   ```

3. **Check for security updates**
   ```bash
   docker-compose pull  # Gets latest security patches
   docker-compose up -d
   ```

4. **Audit user access**
   - Review Grafana users
   - Remove inactive users
   - Check user permissions

### Security Checklist

- [ ] Strong passwords in use
- [ ] .env file has restricted permissions (600)
- [ ] Firewall rules in place
- [ ] Only necessary ports exposed
- [ ] Regular backups working
- [ ] Logs reviewed for suspicious activity
- [ ] Software up to date

## Documentation

### Keep Documentation Updated

When you make changes:
1. Document in a change log
2. Update relevant config files
3. Update this maintenance guide if procedures change
4. Share with team

### Change Log Template

```
Date: YYYY-MM-DD
Changed by: Name
Change: Brief description
Reason: Why the change was made
Impact: Services affected
Rollback: How to revert if needed
```

## Emergency Contacts

Document your support contacts:

**Open Source Community**:
- Email: [support contact]
- Phone: [support phone]
- Hours: [support hours]

**Internal Contacts**:
- Primary Administrator: [name/contact]
- Backup Administrator: [name/contact]
- Escalation Contact: [name/contact]

## Maintenance Windows

Recommended maintenance schedule:

**Minor updates** (monthly):
- Duration: 30 minutes
- Impact: Minimal, brief service restarts
- Schedule: During low-usage periods

**Major updates** (quarterly):
- Duration: 1-2 hours
- Impact: Possible downtime
- Schedule: Planned maintenance window
- Require: Change management approval

---

**Last Updated**: October 2025  
**Next Review**: January 2026  
**Maintained By**: Open Source Community
