# Configuration Reference

**@codefromdom**
**Version:** 1.0.0  
**Date:** December 2, 2025

Complete reference for all configuration options in the monitoring toolbox.

## Table of Contents

1. [Environment Variables](#environment-variables)
2. [Prometheus Configuration](#prometheus-configuration)
3. [VictoriaMetrics Configuration](#victoriametrics-configuration)
4. [Grafana Configuration](#grafana-configuration)
5. [Exporter Configuration](#exporter-configuration)
6. [Alert Rules](#alert-rules)

## Environment Variables

All environment variables are configured in the `.env` file.

### Grafana Settings

| Variable | Default | Description |
|----------|---------|-------------|
| `GRAFANA_ADMIN_USER` | admin | Grafana admin username |
| `GRAFANA_ADMIN_PASSWORD` | (required) | Grafana admin password |

### Infinibox Settings

| Variable | Default | Description |
|----------|---------|-------------|
| `INFINIBOX_HOST` | (required) | Infinibox management IP or hostname |
| `INFINIBOX_USER` | monitoring_user | Read-only user for API access |
| `INFINIBOX_PASSWORD` | (required) | User password |

### VMware Settings

| Variable | Default | Description |
|----------|---------|-------------|
| `VCENTER_HOST` | (required) | vCenter hostname or IP |
| `VCENTER_USER` | monitoring@vsphere.local | Read-only user |
| `VCENTER_PASSWORD` | (required) | User password |

### Data Retention

| Variable | Default | Description |
|----------|---------|-------------|
| `PROMETHEUS_RETENTION` | 2d | Prometheus data retention (short-term) |
| `VICTORIAMETRICS_RETENTION` | 30d | VictoriaMetrics retention (long-term) |

### Scrape Intervals

| Variable | Default | Description |
|----------|---------|-------------|
| `SCRAPE_INTERVAL_INFINIBOX` | 10 | Infinibox scrape interval (seconds) |
| `SCRAPE_INTERVAL_VMWARE` | 15 | VMware scrape interval (seconds) |
| `SCRAPE_INTERVAL_BROCADE` | 10 | Brocade scrape interval (seconds) |
| `SCRAPE_INTERVAL_JUNIPER` | 10 | Juniper scrape interval (seconds) |

## Prometheus Configuration

File: `prometheus/prometheus.yml`

### Global Settings

```yaml
global:
  scrape_interval: 15s      # Default scrape interval
  evaluation_interval: 15s  # Rule evaluation interval
  external_labels:
    cluster: 'Organization-prod'
    environment: 'production'
```

### Remote Write

```yaml
remote_write:
  - url: http://victoriametrics:8428/api/v1/write
    queue_config:
      max_samples_per_send: 10000
      batch_send_deadline: 5s
      max_shards: 20
```

## VictoriaMetrics Configuration

### Command-line Arguments

- `--storageDataPath=/victoria-metrics-data` - Data storage location
- `--retentionPeriod=30d` - Data retention period
- `--httpListenAddr=:8428` - HTTP listen address

### Memory Management

For 30-day retention with high-frequency scraping:
- Minimum: 4GB RAM
- Recommended: 8GB RAM
- Storage: ~100GB for 30 days

## Grafana Configuration

### Plugins

Auto-installed plugins:
- `grafana-clock-panel`
- `grafana-simple-json-datasource`
- `grafana-piechart-panel`

### Dashboard Provisioning

Dashboards are automatically loaded from:
- `grafana/dashboards/*.json`

### Data Source Configuration

VictoriaMetrics is configured as the primary data source:
```yaml
- name: VictoriaMetrics
  type: prometheus
  url: http://victoriametrics:8428
  access: proxy
  isDefault: true
```

## Exporter Configuration

### Infinidat Exporter

File: `config/infinidat.yml`

```yaml
host: infinibox.Organization.local
username: monitoring_user
password: changeme
port: 9600
scrape_interval: 10
```

### VMware Exporter

File: `config/vmware.yml`

```yaml
host: vcenter.Organization.local
username: monitoring@vsphere.local
password: changeme
port: 9601
scrape_interval: 15
skip_ssl_verify: true
```

### Brocade Exporter

File: `config/brocade.yml`

```yaml
port: 9602
scrape_interval: 10

switches:
  - name: brocade-fc-sw01
    host: 10.0.1.11
    community: public
    active_ports: 56
    model: DB720S
```

### Juniper Exporter

File: `config/juniper.yml`

```yaml
port: 9603
scrape_interval: 10

switches:
  - name: juniper-qfx5120-core-01
    host: 10.0.2.1
    community: public
    model: QFX5120
```

## Alert Rules

File: `prometheus/rules/alerts.yml`

Alert rules are organized by severity:
- **Critical**: Immediate attention required
- **Warning**: Attention needed within business hours
- **Info**: Informational

### Example Alert Configuration

```yaml
groups:
  - name: infinibox_critical
    interval: 30s
    rules:
      - alert: InfiniboxSystemDown
        expr: infinibox_system_status == 0
        for: 1m
        labels:
          severity: critical
          layer: storage
        annotations:
          summary: "Infinibox system is DOWN"
          description: "..."
          action: "..."
```

## Performance Tuning

### For High-Load Environments

1. **Increase VictoriaMetrics resources**:
   ```yaml
   resources:
     limits:
       memory: 16Gi
       cpu: 8
   ```

2. **Adjust Prometheus retention**:
   ```yaml
   --storage.tsdb.retention.time=1d
   ```

3. **Optimize scrape intervals**:
   - Non-critical metrics: 30s
   - Critical metrics: 10-15s

### For Resource-Constrained Environments

1. **Reduce retention**:
   ```yaml
   --retentionPeriod=14d
   ```

2. **Limit VM metrics collection**:
   Edit exporter to collect only powered-on VMs

3. **Reduce alert evaluation frequency**:
   ```yaml
   evaluation_interval: 30s
   ```

## Security Best Practices

1. **Change default passwords** immediately after deployment
2. **Use read-only accounts** for all monitoring credentials
3. **Enable HTTPS** for Grafana in production
4. **Rotate credentials** quarterly using `scripts/rotate-credentials.sh`
5. **Restrict network access** using firewalls
6. **Enable audit logging** in Grafana

## Backup Configuration

Backup these critical files:
- `.env` - Credentials (store securely)
- `grafana/dashboards/*.json` - Dashboard definitions
- `prometheus/rules/*.yml` - Alert rules
- `config/*.yml` - Exporter configurations

Use the backup script:
```bash
./scripts/backup.sh
```

## Troubleshooting Tips

### High Memory Usage

1. Check VictoriaMetrics cardinality:
   ```bash
   curl http://localhost:8428/api/v1/labels
   ```

2. Review scrape targets:
   ```bash
   curl http://localhost:9090/api/v1/targets
   ```

### Missing Metrics

1. Check exporter health:
   ```bash
   curl http://localhost:9600/health
   ```

2. Review exporter logs:
   ```bash
   docker-compose logs infinidat-exporter
   ```

3. Verify Prometheus scrape config:
   ```bash
   curl http://localhost:9090/api/v1/status/config
   ```

