Here's the result of running `cat -n` on /home/ubuntu/open-deep-inspect-for-infinibox/docs/ARCHITECTURE.md:
     1  # Architecture Documentation
     2  
     3  **@codefromdom**
     4  **Version:** 1.0.0  
     5  **Date:** December 2, 2025
     6  ## Overview
     7  
     8  This document describes the technical architecture of the Organization monitoring solution, including component interactions, data flow, and design decisions.
     9  
    10  ## High-Level Architecture
    11  
    12  ```
    13  ┌─────────────────────────────────────────────────────────────────┐
    14  │                         User Access Layer                       │
    15  │                                                                 │
    16  │  ┌──────────────────────────────────────────────────────┐      │
    17  │  │              Grafana (Port 3000)                     │      │
    18  │  │  - Dashboard Rendering                               │      │
    19  │  │  - User Authentication                               │      │
    20  │  │  - Query Builder                                     │      │
    21  │  │  - Alerting UI                                       │      │
    22  │  └────────────┬──────────────────┬───────────┬──────────┘      │
    23  └───────────────┼──────────────────┼───────────┼──────────────────┘
    24                  │                  │           │
    25                  ▼                  ▼           ▼
    26  ┌─────────────────────────────────────────────────────────────────┐
    27  │                      Data Query Layer                           │
    28  │                                                                 │
    29  │  ┌──────────────────┐  ┌─────────────────┐  ┌─────────────┐   │
    30  │  │  Prometheus      │  │VictoriaMetrics  │  │ PostgreSQL  │   │
    31  │  │  (Port 9090)     │──▶  (Port 8428)    │  │ (Port 5432) │   │
    32  │  │                  │  │                 │  │             │   │
    33  │  │  - Short-term    │  │  - Long-term    │  │ - Topology  │   │
    34  │  │  - 2-day         │  │  - 30-day       │  │   Database  │   │
    35  │  │  - PromQL        │  │  - Efficient    │  │ - Paths     │   │
    36  │  │  - Alert rules   │  │  - PromQL       │  │ - Relations │   │
    37  │  └────────┬─────────┘  └─────────────────┘  └──────▲──────┘   │
    38  └───────────┼──────────────────────────────────────────┼──────────┘
    39              │ Pull Metrics                             │
    40              ▼                                          │ Store
    41  ┌─────────────────────────────────────────────────────┼──────────┐
    42  │               Metrics Collection & Correlation      │          │
    43  │                                                      │          │
    44  │  ┌────────┐  ┌────────┐  ┌────────┐  ┌────────┐   │          │
    45  │  │Infinidat VMware  │  │Brocade │  │Juniper │   │          │
    46  │  │Exporter│  │Exporter│  │Exporter│  │Exporter│   │          │
    47  │  │:9600   │  │:9601   │  │:9602   │  │:9603   │   │          │
    48  │  │+TOPOLOGY│ │        │  │+TOPOLOGY│ │        │   │          │
    49  │  └───┬────┘  └───┬────┘  └───┬────┘  └───┬────┘   │          │
    50  │      └───────────┼───────────┼───────────┘         │          │
    51  │                  │           │                     │          │
    52  │                  └───────────┼─────────────────────┘          │
    53  │                              │                                │
    54  │                  ┌───────────▼──────────┐                     │
    55  │                  │  Topology Correlator │                     │
    56  │                  │  (Port 9700)         │─────────────────────┘
    57  │                  │  - Queries exporters │
    58  │                  │  - WWPN matching     │
    59  │                  │  - Path building     │
    60  │                  │  - REST API          │
    61  │                  └──────────────────────┘
    62  └─────────────────────────────────────────────────────────────────┘
    63                │             │             │             │
    64                │ REST API    │ REST API    │ SNMP        │ SNMP
    65                ▼             ▼             ▼             ▼
    66  ┌─────────────────────────────────────────────────────────────────┐
    67  │                    Infrastructure Layer                         │
    68  │                                                                 │
    69  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
    70  │  │Infinibox │  │ vCenter  │  │ Brocade  │  │ Juniper  │       │
    71  │  │          │  │          │  │ FC Switches│ QFX Switches│      │
    72  │  │3 Active  │  │14x ESXi  │  │ 4x DB720S│  │Core+Leaf │       │
    73  │  │Controllers│ │  Hosts   │  │56 ports  │  │          │       │
    74  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘       │
    75  └─────────────────────────────────────────────────────────────────┘
    76  ```
    77  
    78  ## Component Details
    79  
    80  ### Grafana (Visualization Layer)
    81  
    82  **Purpose**: User interface for viewing metrics, creating dashboards, and managing alerts
    83  
    84  **Key Features**:
    85  - Pre-provisioned dashboards for all infrastructure layers
    86  - Multi-datasource support (Prometheus + VictoriaMetrics)
    87  - Role-based access control (RBAC)
    88  - Alerting and notification system
    89  - Dashboard versioning and sharing
    90  
    91  **Configuration**:
    92  - Port: 3000
    93  - Data persistence: Docker volume
    94  - Auto-provisioning: `grafana/provisioning/`
    95  - Dashboards: `grafana/dashboards/`
    96  
    97  **Resource Requirements**:
    98  - CPU: 0.5-1 cores
    99  - Memory: 512MB-1GB
   100  - Disk: 10GB for data
   101  
   102  ### Prometheus (Time-Series Database - Short Term)
   103  
   104  **Purpose**: Collect and store short-term metrics with high frequency
   105  
   106  **Key Features**:
   107  - Pull-based metric collection
   108  - PromQL query language
   109  - Service discovery
   110  - Alert rule evaluation
   111  - Remote write to VictoriaMetrics
   112  
   113  **Configuration**:
   114  - Port: 9090
   115  - Retention: 2 days (configurable)
   116  - Scrape intervals: 10-15 seconds
   117  - Configuration: `prometheus/prometheus.yml`
   118  - Alert rules: `prometheus/rules/`
   119  
   120  **Resource Requirements**:
   121  - CPU: 1-2 cores
   122  - Memory: 2-4GB
   123  - Disk: 20GB for 2-day retention
   124  
   125  **Data Flow**:
   126  1. Scrape metrics from exporters every 10-15s
   127  2. Store locally with 2-day retention
   128  3. Remote write to VictoriaMetrics for long-term storage
   129  4. Evaluate alert rules every 15s
   130  
   131  ### VictoriaMetrics (Time-Series Database - Long Term)
   132  
   133  **Purpose**: Efficient long-term storage of metrics
   134  
   135  **Key Features**:
   136  - PromQL-compatible query engine
   137  - Compressed storage format
   138  - High write throughput
   139  - Efficient resource usage
   140  - Downsampling for older data
   141  
   142  **Configuration**:
   143  - Port: 8428
   144  - Retention: 30 days (configurable up to 90 days)
   145  - Storage path: Docker volume
   146  - Remote write endpoint: `/api/v1/write`
   147  
   148  **Resource Requirements**:
   149  - CPU: 1-2 cores
   150  - Memory: 2-4GB
   151  - Disk: 50-100GB for 30-day retention
   152  
   153  **Storage Efficiency**:
   154  - Average compression ratio: 10:1
   155  - Estimated storage: ~2GB per day for typical deployment
   156  - Automatic downsampling after 7 days
### Topology Correlation Service (Port 9700) ⭐ **NEW**

**Purpose**: Correlate metrics from all exporters to build end-to-end topology paths from storage LUNs through network fabric to virtual machines

**Technology**: Python 3.11 with PostgreSQL database

**Key Features**:
- Automatic correlation of WWPNs across Infinibox, Brocade switches, and VMware
- Real-time topology path discovery and updates
- REST API for programmatic access to topology data
- Prometheus metrics export for monitoring correlation health
- Periodic discovery with configurable intervals (default: 60 seconds)
- Complete path visualization: LUN → FC Zone → ESXi HBA → Datastore → VM

**Configuration**:
- Port: 9700 (HTTP REST API)
- Database: PostgreSQL on port 5432
- Configuration file: `services/topology-correlator/config.yml`
- Database schema: `services/topology-correlator/schema.sql`

**Resource Requirements**:
- CPU: 0.5-1 cores
- Memory: 512MB-1GB
- Disk: 5-10GB for topology database

**Data Flow**:
1. Query Prometheus exporters for topology metrics every 60 seconds
2. Extract WWPNs, IQNs, volume mappings, FC zones, and HBA information
3. Correlate data by matching WWPNs across all components
4. Build complete paths from volumes to VMs
5. Store relationships in PostgreSQL database
6. Expose topology data via REST API and Grafana dashboard

**REST API Endpoints**:
- `GET /health` - Health check
- `GET /metrics` - Prometheus metrics
- `GET /api/v1/topology/paths` - Get all topology paths
- `GET /api/v1/topology/volume/{name}` - Get path for specific volume
- `GET /api/v1/topology/vm/{name}` - Get path for specific VM
- `POST /api/v1/topology/correlate` - Trigger manual correlation

**Key Metrics Exported**:
```
topology_paths_total                    # Total paths discovered
topology_volumes_total                  # Mapped volumes
topology_vms_total                      # VMs discovered
topology_correlation_duration_seconds   # Correlation performance
topology_last_update_timestamp          # Last successful update
```

**Database Schema**:
- 19+ tables for volumes, hosts, switches, zones, datastores, VMs
- Views for complete path queries
- Indexes for fast WWPN lookups
- Functions for data cleanup and maintenance

**Use Cases**:
- **Impact Analysis**: Understand which VMs are affected by storage or network changes
- **Troubleshooting**: Trace performance issues from VM back to storage volume
- **Capacity Planning**: See which VMs consume which storage volumes
- **Documentation**: Maintain accurate topology documentation automatically
- **Compliance**: Track data flow paths for security requirements

   157  
   158  ### Custom Exporters
   159  
   160  #### Infinidat Exporter (Port 9600)
   161  
   162  **Purpose**: Collect metrics from Infinibox storage system
   163  
   164  **Technology**: Python 3.11 with REST API client
   165  
   166  **Metrics Collected**:
   167  - System health and uptime
   168  - Controller status (3 active controllers)
   169  - Pool capacity and data reduction ratios
   170  - Volume IOPS, throughput, latency
   171  - Network port status and speed
   172  - System-wide performance statistics
   173  - **Topology data**: Volume WWPNs, IQNs, host mappings, LUN IDs ⭐ **NEW**
   174  
   175  **Scrape Frequency**: 10 seconds
   176  
   177  **API**: Infinibox REST API v2
   178  
   179  **Key Metrics**:
   180  ```
   181  infinibox_system_status
   182  infinibox_controller_status
   183  infinibox_pool_total_capacity_bytes
   184  infinibox_volume_iops
   185  infinibox_volume_latency_ms
   186  infinibox_port_status
   187  
   188  # Topology metrics (NEW)
   189  infinibox_lun_mapping{host_id,volume_id,lun_id}
   190  infinibox_host_initiator_info{host_id,initiator_type,initiator_address}
   191  infinibox_fc_port_info{port_id,wwpn}
   192  ```
   187  
   188  #### VMware Exporter (Port 9601)
   189  
   190  **Purpose**: Collect metrics from vCenter and ESXi hosts
   191  
   192  **Technology**: Python 3.11 with vCenter REST API
   193  
   194  **Metrics Collected**:
   195  - ESXi host status and performance
   196  - Host CPU and memory utilization
   197  - VM power states and resource usage
   198  - Cluster aggregate metrics
   199  - Datastore capacity and usage
   200  
   201  **Scrape Frequency**: 15 seconds
   202  
   203  **API**: vCenter REST API
   204  
   205  **Key Metrics**:
   206  ```
   207  vmware_host_status
   208  vmware_host_cpu_usage_percent
   209  vmware_host_memory_usage_percent
   210  vmware_vm_status
   211  vmware_datastore_usage_percent
   212  ```
   213  
   214  #### Brocade Exporter (Port 9602)
   215  
   216  **Purpose**: Collect metrics from Brocade FC switches
   217  
   218  **Technology**: Python 3.11 with SNMP (pysnmp)
   219  
   220  **Metrics Collected**:
   221  - Switch operational status
   222  - Port status (56 active ports per switch)
   223  - Port traffic (TX/RX words and frames)
   224  - Port errors (CRC, encoding)
   225  - Port speed and physical state
   226  - **Topology data**: Port WWPNs, FC zones, zone membership ⭐ **NEW**
   227  
   228  **Scrape Frequency**: 10 seconds
   229  
   230  **Protocol**: SNMPv2c (+ SSH for zone data, optional)
   231  
   232  **Key Metrics**:
   233  ```
   234  brocade_switch_status
   235  brocade_port_status
   236  brocade_port_tx_words_total
   237  brocade_port_crc_errors_total
   238  brocade_port_speed_gbps
   239  
   240  # Topology metrics (NEW)
   241  brocade_port_wwpn_info{switch_name,port_index,wwpn}
   242  brocade_fc_zone_info{switch_name,zone_name,zoneset_name}
   243  brocade_zone_member_info{zone_name,member_wwpn}
   244  ```
   239  
   240  #### Juniper Exporter (Port 9603)
   241  
   242  **Purpose**: Collect metrics from Juniper QFX switches
   243  
   244  **Technology**: Python 3.11 with SNMP (pysnmp)
   245  
   246  **Metrics Collected**:
   247  - Switch operational status and uptime
   248  - Interface status and admin state
   249  - Interface traffic (TX/RX octets)
   250  - Interface errors and discards
   251  - CPU and memory utilization
   252  
   253  **Scrape Frequency**: 10 seconds
   254  
   255  **Protocol**: SNMPv2c using standard MIBs (IF-MIB, HOST-RESOURCES-MIB)
   256  
   257  **Key Metrics**:
   258  ```
   259  juniper_switch_status
   260  juniper_interface_status
   261  juniper_interface_in_octets_total
   262  juniper_interface_in_errors_total
   263  juniper_cpu_utilization_percent
   264  ```
   265  
   266  ## Data Flow
   267  
   268  ### Metric Collection Flow
   269  
   270  1. **Collection**: Exporters query devices every 10-15 seconds
   271  2. **Exposure**: Metrics exposed in Prometheus format on HTTP endpoints
   272  3. **Scraping**: Prometheus scrapes all exporters
   273  4. **Storage**: Metrics stored in Prometheus TSDB
   274  5. **Forwarding**: Prometheus writes metrics to VictoriaMetrics
   275  6. **Query**: Grafana queries Prometheus (recent) or VictoriaMetrics (historical)
   276  
   277  ### Query Flow
   278  
   279  **Recent Data (< 2 days)**:
   280  ```
   281  Grafana → Prometheus → Exporters → Devices
   282  ```
   283  
   284  **Historical Data (> 2 days)**:
   285  ```
   286  Grafana → VictoriaMetrics
   287  ```
   288  
   289  ### Alert Flow
   290  
   291  ```
   292  Prometheus → Evaluate Rules → Fire Alerts → Alertmanager (optional) → Notifications
   293  ```
   294  
   295  ## Design Decisions
   296  
   297  ### High-Frequency Scraping (10-15s)
   298  
   299  **Rationale**: 
   300  - Real-time visibility into infrastructure changes
   301  - Quick detection of performance issues
   302  - Sub-minute latency critical for storage and network
   303  
   304  **Trade-offs**:
   305  - Higher CPU/memory usage
   306  - More storage required
   307  - Network overhead
   308  
   309  **Mitigation**:
   310  - VictoriaMetrics for efficient storage
   311  - Tunable scrape intervals
   312  - Selective metric collection
   313  
   314  ### Two-Tier Storage (Prometheus + VictoriaMetrics)
   315  
   316  **Rationale**:
   317  - Prometheus for real-time queries and alerting
   318  - VictoriaMetrics for efficient long-term storage
   319  - Best of both worlds
   320  
   321  **Benefits**:
   322  - Fast recent data queries
   323  - Cost-effective long-term retention
   324  - Simplified backup strategy
   325  
   326  ### Custom Exporters vs. Existing Exporters
   327  
   328  **Decision**: Build custom exporters
   329  
   330  **Rationale**:
   331  - Infinibox: No native Prometheus exporter
   332  - VMware: Custom metrics needed, simplified deployment
   333  - Network: Tailored to specific device models and metrics
   334  
   335  **Benefits**:
   336  - Full control over metrics
   337  - Optimized for environment
   338  - Easy to extend and customize
   339  
   340  ### Docker Compose Deployment
   341  
   342  **Rationale**:
   343  - Simplified deployment and management
   344  - Version-controlled configuration
   345  - Easy backup and restore
   346  - Portable across environments
   347  
   348  **Alternative Considered**: Kubernetes
   349  - Rejected due to complexity for single-node deployment
   350  - Can be migrated to K8s if needed
   351  
   352  ## Scalability Considerations
   353  
   354  ### Current Capacity
   355  
   356  The solution is designed for:
   357  - 1x Infinibox system
   358  - 1x vCenter (14 ESXi hosts, 200+ VMs)
   359  - 4x Brocade FC switches (224 ports total)
   360  - 6x Juniper switches
   361  
   362  ### Scaling Options
   363  
   364  **Vertical Scaling**:
   365  - Increase server resources (CPU, RAM, disk)
   366  - Extend retention periods
   367  - Add more monitored VMs
   368  
   369  **Horizontal Scaling**:
   370  - Multiple monitoring servers for different environments
   371  - Prometheus federation for multi-site
   372  - VictoriaMetrics cluster mode for large scale
   373  
   374  ### Resource Estimates
   375  
   376  **For 30-day retention**:
   377  - CPU: 8 cores recommended
   378  - Memory: 16GB recommended
   379  - Disk: 200GB recommended
   380  - Network: 1Gbps
   381  
   382  **For 90-day retention**:
   383  - CPU: 12 cores recommended
   384  - Memory: 24GB recommended
   385  - Disk: 500GB recommended
   386  
   387  ## Security Considerations
   388  
   389  ### Authentication
   390  
   391  - Grafana: User authentication required
   392  - Prometheus/VictoriaMetrics: No authentication (internal only)
   393  - Exporters: Use read-only credentials
   394  
   395  ### Network Security
   396  
   397  - All services run on Docker bridge network
   398  - Only Grafana exposed externally
   399  - Device credentials stored in environment variables
   400  - SNMP community strings in configuration files
   401  
   402  ### Recommendations
   403  
   404  1. Use strong passwords
   405  2. Implement firewall rules
   406  3. Enable HTTPS for Grafana
   407  4. Rotate credentials regularly
   408  5. Use secrets management (HashiCorp Vault, etc.)
   409  
   410  ## Monitoring the Monitoring System
   411  
   412  ### Self-Monitoring
   413  
   414  Prometheus monitors itself and all components:
   415  - Exporter health checks
   416  - Scrape success rates
   417  - Query performance
   418  - Storage usage
   419  
   420  ### Alerts
   421  
   422  Pre-configured alerts for:
   423  - Exporter downtime
   424  - High error rates
   425  - Storage issues
   426  - Service unavailability
   427  
   428  ### Health Checks
   429  
   430  Automated health checks via:
   431  - Docker health checks
   432  - `health-check.sh` script
   433  - Prometheus target status
   434  
   435  ## Backup and Recovery
   436  
   437  ### What's Backed Up
   438  
   439  - Configuration files
   440  - Grafana dashboards and settings
   441  - Prometheus alert rules
   442  - (Optional) Time-series data
   443  
   444  ### Backup Strategy
   445  
   446  - Automated daily backups
   447  - Retention: 7 days
   448  - Stored as compressed archives
   449  - Includes restore instructions
   450  
   451  ### Recovery Time
   452  
   453  - Configuration restore: 5 minutes
   454  - Full restore (with data): 30-60 minutes
   455  
   456  ## Future Enhancements
   457  
   458  ### Planned Improvements
   459  
   460  1. Alertmanager integration for notifications
   461  2. Advanced alerting rules
   462  3. Custom dashboard templates
   463  4. Integration with ticketing systems
   464  5. Predictive analytics using historical data
   465  6. Multi-tenancy support
   466  
   467  ### Extensibility
   468  
   469  Easy to add:
   470  - New exporters for additional devices
   471  - Custom metrics
   472  - Additional dashboards
   473  - Integration with other tools
   474  
   475  ---
   476  
   477  **Document Version**: 1.0  
   478  **Last Updated**: October 2025  
   479  **Maintained By**: Open Source Community
   480  