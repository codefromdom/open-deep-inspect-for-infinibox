# open-deep-inspect-for-infinibox - Complete Deployment Guide

**@codefromdom**
**Version:** 1.0.0  
**Date:** December 2, 2025

---

## 🎯 Executive Summary

This monitoring solution provides **real-time visibility** into your entire betting platform infrastructure with **1-5 second data collection intervals**. It's designed specifically for revenue-critical operations where every millisecond counts.

### Key Highlights

✅ **Ultra High-Frequency Monitoring**: 1-5 second intervals (industry standard is 60s)  
✅ **SSA Technology**: Monitors all 3 active Infinibox controllers  
✅ **87 Intelligent Alerts**: Automated incident detection across all layers  
✅ **One-Command Deployment**: Full stack running in under 10 minutes  
✅ **Betting Operations Focus**: Peak-hour monitoring and revenue-impact alerting  
✅ **30-90 Day Retention**: Long-term trend analysis included

---

## 📋 Prerequisites

### Hardware Requirements

- **Server**: Linux server (Ubuntu 20.04+ or RHEL 8+)
- **CPU**: 8 cores minimum (16 recommended)
- **RAM**: 16GB minimum (32GB recommended for 90-day retention)
- **Disk**: 200GB minimum (500GB recommended)
- **Network**: 1Gbps connectivity to all monitored devices

### Software Requirements

- Docker 20.10+
- Docker Compose 2.0+
- Git (optional, for version control)

### Network Requirements

**Firewall Rules Needed:**

| Source | Destination | Port | Protocol | Purpose |
|--------|-------------|------|----------|---------|
| Monitoring Server | Infinibox | 443 | HTTPS | InfiniSDK API |
| Monitoring Server | vCenter | 443 | HTTPS | vSphere API |
| Monitoring Server | Brocade Switches (4x) | 161 | SNMPv3 | SNMP polling |
| Monitoring Server | Juniper Switches | 161 | SNMPv3 | SNMP polling |
| Admin Workstations | Monitoring Server | 3000 | HTTPS | Grafana access |

### Access Requirements

1. **Infinibox**: Read-only monitoring user with API access
2. **vCenter**: Read-only role for monitoring
3. **Brocade**: SNMPv3 community string (read-only)
4. **Juniper**: SNMPv3 community string (read-only)

---

## 🚀 Quick Start (10-Minute Deployment)

### Step 1: Install Prerequisites

```bash
# Download and run prerequisites installer
sudo ./scripts/install-prerequisites.sh
```

This installs:
- Docker and Docker Compose
- System dependencies
- Optimized kernel settings
- Data directories

### Step 2: Configure Credentials

```bash
# Copy environment template
cp .env.example .env

# Edit with your credentials
nano .env
```

**Required Configuration:**
- `INFINIBOX_HOST`: Infinibox management IP/hostname
- `INFINIBOX_USER`: monitoring
- `INFINIBOX_PASSWORD`: Your secure password
- `VCENTER_HOST`: vCenter server hostname
- `VCENTER_USER`: monitoring@vsphere.local
- `VCENTER_PASSWORD`: Your secure password
- `GRAFANA_ADMIN_PASSWORD`: Choose a strong password

### Step 3: Configure Device IPs

Update device configurations:

```bash
# Update Brocade switch IPs (4x switches)
nano config/brocade.yml

# Update Juniper switch IPs
nano config/juniper.yml

# Verify Infinibox and vCenter config
nano config/infinidat.yml
nano config/vmware.yml
```

### Step 4: Deploy

```bash
# One command to deploy everything
./scripts/deploy.sh
```

**What Happens:**
1. ✓ Prerequisites validation
2. ✓ Configuration check
3. ✓ Docker image building (4 custom exporters)
4. ✓ Base image pulling (Prometheus, Grafana, VictoriaMetrics)
5. ✓ Service startup
6. ✓ Health validation
7. ✓ Post-deployment summary

**Expected Duration:** 5-10 minutes

### Step 5: Access Grafana

```bash
# Open browser to:
http://your-server-ip:3000

# Default login:
Username: admin
Password: (from .env file)
```

### Step 6: Verify Data Collection

```bash
# Run health check
./scripts/health-check.sh
```

Expected output:
```
✓ All containers running
✓ All services healthy
✓ Prometheus targets UP: 7/7
✓ Metrics being collected
Health Score: 100%
```

---

## 📊 Dashboards Overview

Navigate to **Dashboards** in Grafana to access:

### 1. **Infinidat Overview Dashboard**
- **SSA Controller Status** (3 active controllers)
- Pool capacity with trend forecasting
- Real-time IOPS, throughput, latency
- Top 10 volumes by performance
- Recent alerts panel

### 2. **Infinibox-to-VM Mapping Dashboard** ⭐ **CRITICAL**
- Visual correlation: Infinibox volumes → ESXi hosts → VMs
- Datastore-to-volume mapping
- End-to-end performance correlation
- Storage path topology

### 3. **VMware Infrastructure Dashboard**
- Cluster health (14x Lenovo SR950 v3 servers)
- ESXi host performance
- VM performance matrix (sortable)
- Datastore capacity and latency
- Network statistics

### 4. **Storage Performance Dashboard**
- End-to-end latency tracking
- IOPS breakdown by volume
- Throughput analysis
- Queue depth monitoring

### 5. **Network Infrastructure Dashboard**
- Brocade FC fabric health (4x DB720S, 56 ports each)
- Juniper switch performance (QFX5120/5110)
- Port-level statistics
- Error rates and bandwidth utilization

### 6. **Betting Operations Dashboard** 💰
- **Revenue-critical metrics**
- Peak-hour performance (6 PM - 11 PM)
- Transaction latency
- System availability
- Capacity projections

### 7. **Executive Summary Dashboard**
- High-level KPIs
- SLA compliance tracking
- Capacity forecasting
- Incident summary
- Business impact metrics

---

## 🚨 Alert Rules (87 Rules)

Alerts are organized by severity and infrastructure layer:

### Critical Alerts (Revenue Impact)
- Infinibox controller failure
- Storage capacity <10%
- VM swapping detected
- FC fabric segmentation
- End-to-end latency >20ms
- Betting platform database degradation

### Warning Alerts
- Capacity <20%
- High latency (>10ms)
- Network errors increasing
- Hardware sensor warnings
- Backup window missed

### Info Alerts
- Old snapshots detected
- Firmware outdated
- Unusual activity patterns

**Alert Delivery:**
- Grafana UI (built-in)
- Email (configure in Grafana)
- Slack/Teams (configure in Grafana)
- PagerDuty integration (optional)

---

## 🔍 Monitoring Intervals

### Ultra High-Frequency Collection

| Component | Interval | Reason |
|-----------|----------|--------|
| **Infinibox** | **1 second** | Critical storage, real-time betting data |
| **VMware** | 5 seconds | VM performance, high transaction rate |
| **Brocade FC** | 5 seconds | SAN fabric, I/O path monitoring |
| **Juniper** | 5 seconds | Network, betting platform connectivity |

**Industry Comparison:**
- Standard monitoring: 60 seconds
- Our solution: 1-5 seconds
- **20-60x faster visibility**

### Data Retention

| Storage | Retention | Purpose |
|---------|-----------|---------|
| Prometheus | 2 days | Fast queries, recent data |
| VictoriaMetrics | 30 days | Long-term trends (expandable to 90 days) |

---

## 🔧 Post-Deployment Tasks

### 1. Configure Alert Notifications

```bash
# In Grafana:
1. Go to: Alerting → Contact Points
2. Add email/Slack/Teams notification channel
3. Test notification delivery
```

### 2. Customize Dashboards

All dashboards are pre-configured but can be customized:
- Add your specific VM names
- Adjust thresholds for your SLAs
- Add custom panels for specific KPIs

### 3. Schedule Regular Health Checks

```bash
# Add to cron
0 8 * * * /opt/open-deep-inspect-for-infinibox/scripts/health-check.sh | mail -s "Monitoring Health" ops@Organization.local
```

### 4. Configure Backups

```bash
# Run weekly backups
0 2 * * 0 /opt/open-deep-inspect-for-infinibox/scripts/backup.sh
```

---

## 📚 Operational Procedures

### Daily Operations

**Morning Health Check:**
```bash
./scripts/health-check.sh
```

**Review Alerts:**
- Check Grafana → Alerting → Alert Rules
- Review overnight incidents
- Verify all targets are UP

### Weekly Tasks

**Capacity Review:**
- Check Infinibox pool capacity trends
- Review datastore usage
- Validate retention periods

**Performance Review:**
- Review latency trends
- Check for anomalies
- Validate SLA compliance

### Monthly Tasks

**Credential Rotation:**
```bash
./scripts/rotate-credentials.sh
```

**System Updates:**
```bash
# Pull latest images
docker-compose pull

# Restart with new images
docker-compose up -d
```

---

## 🆘 Troubleshooting

### Common Issues

#### 1. Exporter Not Collecting Metrics

**Symptoms:** Target DOWN in Prometheus

**Solutions:**
```bash
# Check exporter logs
docker-compose logs infinidat-exporter

# Verify connectivity
ping infinibox-mgmt.local

# Test credentials
curl -k https://infinibox-mgmt.local/api/rest/system
```

#### 2. High Disk Usage

**Symptoms:** Disk space alerts

**Solutions:**
```bash
# Check disk usage
df -h

# Reduce retention (if needed)
# Edit docker-compose.yml:
# VICTORIAMETRICS_RETENTION=14d

# Restart VictoriaMetrics
docker-compose restart victoriametrics
```

#### 3. Slow Dashboard Loading

**Symptoms:** Grafana dashboards take >5s to load

**Solutions:**
- Reduce time range (use last 1h instead of 24h)
- Increase server resources
- Check Prometheus performance

#### 4. Alerts Not Firing

**Symptoms:** No alerts despite issues

**Solutions:**
```bash
# Check Prometheus rules
curl http://localhost:9090/api/v1/rules | jq .

# Verify alert rules loaded
docker-compose logs prometheus | grep "rules"

# Test alert manually in Prometheus → Alerts
```

---

## 🔐 Security Best Practices

### 1. Credential Management
- ✅ Use read-only accounts
- ✅ Rotate passwords quarterly
- ✅ Store .env securely (do NOT commit to git)
- ✅ Use strong passwords (16+ characters)

### 2. Network Security
- ✅ Restrict Grafana access to admin network
- ✅ Use HTTPS for Grafana (configure reverse proxy)
- ✅ Enable firewall rules
- ✅ SNMPv3 with encryption (where supported)

### 3. Access Control
- ✅ Limit SSH access to monitoring server
- ✅ Use Grafana RBAC for user permissions
- ✅ Enable audit logging
- ✅ Regular security updates

---

## 📈 Performance Tuning

### For High-Frequency Monitoring

If experiencing performance issues with 1-5s intervals:

**Option 1: Reduce Infinibox Interval**
```yaml
# prometheus.yml
- job_name: 'infinibox'
  scrape_interval: 2s  # Instead of 1s
```

**Option 2: Increase Server Resources**
- Add CPU cores (16 recommended)
- Add RAM (32GB recommended)
- Use SSD storage

**Option 3: Enable Metric Caching**
```yaml
# config/infinidat.yml
cache_ttl: 2  # Cache metrics for 2 seconds
```

---

## 🔄 Upgrade Procedures

### Upgrading the Stack

```bash
# 1. Backup current configuration
./scripts/backup.sh

# 2. Pull latest images
docker-compose pull

# 3. Restart services
docker-compose down
docker-compose up -d

# 4. Verify health
./scripts/health-check.sh
```

### Upgrading Exporters

```bash
# 1. Pull latest code (if using git)
git pull

# 2. Rebuild images
docker-compose build

# 3. Restart
docker-compose up -d
```

---

## 📞 Support and Maintenance

### Open Source Community Support

**Primary Contact:** Open Source Community  
**Email:** N/A  
**Phone:** [Contact your account manager]

**Support Scope:**
- ✅ Infinibox exporter issues
- ✅ SSA monitoring questions
- ✅ Integration with Infinidat systems
- ✅ Performance optimization
- ✅ Custom dashboard development

### Self-Service Resources

**Documentation:**
- `/docs/ARCHITECTURE.md` - Technical architecture details
- `/docs/TROUBLESHOOTING.md` - Detailed troubleshooting guide
- `/docs/MAINTENANCE.md` - Maintenance procedures

**Scripts:**
- `./scripts/health-check.sh` - System health validation
- `./scripts/validate.sh` - Configuration validation
- `./scripts/backup.sh` - Backup configuration

---

## 🎓 Training

### For System Administrators

**Recommended Learning Path:**
1. ✓ Complete this deployment guide
2. ✓ Review all 7 dashboards
3. ✓ Understand alert rules (`prometheus/rules/alerts.yml`)
4. ✓ Practice troubleshooting scenarios
5. ✓ Configure alert notifications
6. ✓ Run backup/restore procedures

**Estimated Time:** 4-6 hours

### For Management

**Key Dashboards to Review:**
1. Executive Summary Dashboard
2. Betting Operations Dashboard
3. Infinibox Overview Dashboard

**Focus Areas:**
- Revenue-impact metrics
- SLA compliance
- Capacity forecasting
- Incident trends

---

## 📝 Appendix A: Creating Monitoring Users

### Infinibox Monitoring User

```bash
# SSH to Infinibox management
ssh admin@infinibox-mgmt.local

# Create read-only user
infinishell> user.create name=monitoring email=monitoring@Organization.local
infinishell> user.set_password monitoring
infinishell> user.add_role monitoring read_only
infinishell> user.set_enabled monitoring true
infinishell> exit
```

### vCenter Monitoring User

```powershell
# Connect to vCenter
Connect-VIServer -Server vcenter.Organization.local

# Create read-only role
New-VIRole -Name "Monitoring-ReadOnly" -Privilege (
    Get-VIPrivilege -Id "System.Anonymous",
    Get-VIPrivilege -Id "System.Read",
    Get-VIPrivilege -Id "System.View"
)

# Assign to user
New-VIPermission -Role "Monitoring-ReadOnly" `
    -Principal "monitoring@vsphere.local" `
    -Entity (Get-Folder -NoRecursion)
```

### Brocade SNMPv3 Configuration

```bash
# SSH to each Brocade switch
ssh admin@brocade-sw01.Organization.local

# Configure SNMPv3
brocade-sw01:admin> snmpconfig --set snmpv3
brocade-sw01:admin> snmpconfig --create user monitoring
brocade-sw01:admin> snmpconfig --set user monitoring auth SHA authPassword <password>
brocade-sw01:admin> snmpconfig --set user monitoring priv AES128 privPassword <password>
brocade-sw01:admin> snmpconfig --add access monitoring read
brocade-sw01:admin> exit

# Repeat for sw02, sw03, sw04
```

---

## 📝 Appendix B: Betting Operations Context

### Why Ultra High-Frequency Monitoring Matters

**Betting Platform Characteristics:**
- **Peak hours**: 6 PM - 11 PM (major sporting events)
- **Transaction spikes**: 1000s of bets per second during key moments
- **Revenue impact**: Every millisecond of latency = lost bets
- **Compliance**: Regulatory requirement for transaction tracking

**Real-World Scenario:**
```
Example: Premier League goal scored
- t=0s: Goal scored
- t=1s: Betting suspended (odds change)
- t=1-5s: 10,000+ users attempt to place bets
- Storage IOPS: 5,000 → 50,000 (10x increase)
- Network traffic: 100 Mbps → 800 Mbps (8x increase)

With 60-second monitoring: You see one data point, miss the spike
With 1-second monitoring: You see 5 data points, can troubleshoot
```

### SSA (Solid State Array) Advantage

**Infinibox SSA Technology:**
- **3 Active Controllers**: All controllers serve I/O simultaneously
- **No single point of failure**: Controller failure = no downtime
- **Linear performance scaling**: Adding controllers = more performance

**Why We Monitor All 3:**
- Verify all controllers are active
- Detect degraded performance if one fails
- Capacity planning for growth

---

## 📝 Appendix C: Quick Reference Commands

### Essential Commands

```bash
# Deploy everything
./scripts/deploy.sh

# Check health
./scripts/health-check.sh

# View logs
docker-compose logs -f <service>

# Restart service
docker-compose restart <service>

# Stop everything
docker-compose down

# Start everything
docker-compose up -d

# Backup
./scripts/backup.sh

# Restore
./scripts/restore.sh <backup-file>
```

### Service Endpoints

| Service | URL | Purpose |
|---------|-----|---------|
| Grafana | http://localhost:3000 | Dashboards & alerts |
| Prometheus | http://localhost:9090 | Metrics & queries |
| VictoriaMetrics | http://localhost:8428 | Long-term storage |
| Infinibox Exporter | http://localhost:9600/metrics | Metrics endpoint |
| VMware Exporter | http://localhost:9601/metrics | Metrics endpoint |
| Brocade Exporter | http://localhost:9602/metrics | Metrics endpoint |
| Juniper Exporter | http://localhost:9603/metrics | Metrics endpoint |

---

## 📝 Appendix D: Metric Examples

### Key Prometheus Queries

**Infinibox SSA Controller Status:**
```promql
infinibox_controller_status
```

**Total IOPS Across All Volumes:**
```promql
sum(rate(infinibox_volume_iops_read[1m])) + sum(rate(infinibox_volume_iops_write[1m]))
```

**VM-to-Datastore Latency Correlation:**
```promql
vmware_vm_disk_latency_ms + on(datastore_name) group_left infinibox_volume_latency_read_ms
```

**Brocade FC Port Utilization:**
```promql
rate(brocade_port_tx_bytes[1m]) * 8 / brocade_port_speed_gbps / 1e9 * 100
```

**End-to-End Storage Latency:**
```promql
infinibox_volume_latency_read_ms + brocade_fabric_latency_ms + vmware_datastore_latency_ms
```

---

## ✅ Deployment Checklist

Use this checklist to verify successful deployment:

### Pre-Deployment
- [ ] Server meets hardware requirements (8 CPU, 16GB RAM, 200GB disk)
- [ ] Docker and Docker Compose installed
- [ ] Network connectivity to all devices verified
- [ ] Firewall rules configured
- [ ] Monitoring users created (Infinibox, vCenter, switches)
- [ ] Credentials documented securely

### Deployment
- [ ] `.env` file configured with all credentials
- [ ] `config/*.yml` files updated with device IPs
- [ ] `deploy.sh` executed successfully
- [ ] All 7 containers running (`docker-compose ps`)
- [ ] Health check passed (100% score)

### Post-Deployment
- [ ] Grafana accessible via browser
- [ ] All 7 dashboards visible and loading
- [ ] Prometheus shows 7/7 targets UP
- [ ] Metrics being collected (check dashboard data)
- [ ] Alert rules loaded (87 rules)
- [ ] Alert notifications configured (email/Slack)
- [ ] Backup scheduled (weekly cron job)
- [ ] Health check scheduled (daily cron job)

### Validation
- [ ] Infinibox: 3 controllers showing active
- [ ] VMware: All 14 hosts visible
- [ ] Brocade: 224 ports (56x4) monitored
- [ ] Juniper: All switches responding
- [ ] No errors in exporter logs
- [ ] Data retention working (check VictoriaMetrics)

### Documentation
- [ ] Team trained on dashboard navigation
- [ ] Alert response procedures documented
- [ ] Escalation path defined
- [ ] Support contacts shared with team
- [ ] This guide bookmarked for reference

---

## 🎉 Deployment Complete!

Congratulations! Your Organization monitoring solution is now operational.

### What You Now Have:

✅ **Real-time visibility** into your entire betting platform infrastructure  
✅ **1-5 second monitoring** - 20-60x faster than industry standard  
✅ **87 intelligent alerts** - automated incident detection  
✅ **7 professional dashboards** - from technical to executive views  
✅ **30-90 day retention** - long-term trend analysis  
✅ **SSA monitoring** - all 3 Infinibox controllers tracked  
✅ **framework code (NOT production-ready, see DISCLAIMER.txt)** - deployed in under 10 minutes

### Next Steps:

1. **Explore dashboards** - Familiarize yourself with all 7 views
2. **Test alerts** - Verify notification delivery
3. **Customize thresholds** - Adjust to your SLAs
4. **Monitor peak hours** - Observe betting event performance
5. **Schedule training** - Ensure team knows the system

---

**Questions or Issues?**

📧 Email: N/A  
📚 Documentation: See `/docs` directory  
🆘 Emergency: Check `TROUBLESHOOTING.md`

---

**Delivered with ❤️ by Open Source Community**

*Making every millisecond count for your betting operations.*
