# Kubernetes Deployment Guide

**Open Source Community**

This directory contains Kubernetes manifests for deploying the monitoring solution in a Kubernetes cluster.

## Prerequisites

- Kubernetes cluster 1.24+
- kubectl configured
- StorageClass available for PersistentVolumeClaims
- At least 32GB RAM and 8 CPU cores available

## Quick Deployment

1. **Update secrets** with your actual credentials:
   ```bash
   # Edit 02-secrets.yaml with your credentials
   kubectl edit -f 02-secrets.yaml
   ```

2. **Deploy all components**:
   ```bash
   kubectl apply -f 00-namespace.yaml
   kubectl apply -f 01-configmaps.yaml
   kubectl apply -f 02-secrets.yaml
   kubectl apply -f 03-storage.yaml
   kubectl apply -f 04-deployments.yaml
   kubectl apply -f 05-services.yaml
   ```

3. **Verify deployment**:
   ```bash
   kubectl get pods -n Organization-monitoring
   kubectl get services -n Organization-monitoring
   ```

4. **Access Grafana**:
   ```bash
   # Get Grafana service URL
   kubectl get svc grafana -n Organization-monitoring
   
   # Or port-forward for local access
   kubectl port-forward -n Organization-monitoring svc/grafana 3000:3000
   ```

## Components

- **VictoriaMetrics**: Long-term metrics storage (30 days)
- **Prometheus**: Short-term metrics collection (2 days)
- **Grafana**: Visualization and dashboards
- **Exporters**: Custom metrics collectors for each infrastructure layer

## Storage Requirements

- VictoriaMetrics: 100GB (30-day retention)
- Prometheus: 20GB (2-day retention)
- Grafana: 10GB (dashboards and configuration)

## Resource Requirements

| Component | CPU Request | Memory Request | CPU Limit | Memory Limit |
|-----------|-------------|----------------|-----------|--------------|
| VictoriaMetrics | 2 cores | 4GB | 4 cores | 8GB |
| Prometheus | 1 core | 2GB | 2 cores | 4GB |
| Grafana | 0.5 cores | 1GB | 1 core | 2GB |
| Exporters (each) | 0.25 cores | 256MB | 0.5 cores | 512MB |

## Customization

### Adjust Retention Period

Edit `04-deployments.yaml`, VictoriaMetrics deployment:
```yaml
args:
  - '--retentionPeriod=60d'  # Change to 60 days
```

### Add More Exporters

Copy the exporter deployment template and adjust:
- Deployment name
- Image
- Environment variables
- Ports

### Configure Ingress

Create an Ingress resource for external access:
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: grafana
  namespace: Organization-monitoring
spec:
  rules:
  - host: grafana.Organization.local
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: grafana
            port:
              number: 3000
```

## Monitoring

Check pod logs:
```bash
kubectl logs -n Organization-monitoring -l app=victoriametrics
kubectl logs -n Organization-monitoring -l app=prometheus
kubectl logs -n Organization-monitoring -l app=grafana
```

## Troubleshooting

### Pods not starting
```bash
kubectl describe pod <pod-name> -n Organization-monitoring
kubectl logs <pod-name> -n Organization-monitoring
```

### PVC not binding
```bash
kubectl get pvc -n Organization-monitoring
kubectl describe pvc <pvc-name> -n Organization-monitoring
```

Ensure your cluster has a default StorageClass or update `03-storage.yaml` with your StorageClass name.

## Scaling

To handle larger environments, increase replicas and resources:

```yaml
spec:
  replicas: 2  # Increase replicas
  resources:
    requests:
      memory: "8Gi"  # Increase memory
```

## Backup

Backup PersistentVolumes regularly:
```bash
kubectl get pvc -n Organization-monitoring
# Use your storage provider's snapshot/backup functionality
```

