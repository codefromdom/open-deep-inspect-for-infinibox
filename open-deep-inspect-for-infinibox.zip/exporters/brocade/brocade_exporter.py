#!/usr/bin/env python3
"""
Brocade FC Switch SNMP Exporter
Open Source Community

Monitors 4x DB720S switches with 56 active ports each.
High-frequency polling (10 seconds) for FC SAN metrics.
"""

import os
import sys
import time
import logging
import yaml
from prometheus_client import Gauge, Counter, Info, generate_latest, REGISTRY
from flask import Flask, Response
from pysnmp.hlapi import *
import threading

logging.basicConfig(
    level=os.environ.get('LOG_LEVEL', 'INFO'),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('brocade_exporter')

app = Flask(__name__)

# ============================================================================
# Prometheus Metrics
# ============================================================================

# Port Metrics
brocade_port_status = Gauge('brocade_port_status', 'Port operational status (1=Up)', 
                            ['switch_name', 'switch_ip', 'port_index', 'port_name'])
brocade_port_admin_status = Gauge('brocade_port_admin_status', 'Port admin status',
                                  ['switch_name', 'switch_ip', 'port_index'])
brocade_port_tx_bytes = Counter('brocade_port_tx_bytes_total', 'Port transmitted bytes',
                                ['switch_name', 'switch_ip', 'port_index'])
brocade_port_rx_bytes = Counter('brocade_port_rx_bytes_total', 'Port received bytes',
                                ['switch_name', 'switch_ip', 'port_index'])
brocade_port_errors = Counter('brocade_port_errors_total', 'Port errors',
                              ['switch_name', 'switch_ip', 'port_index', 'error_type'])
brocade_port_link_failures = Counter('brocade_port_link_failures_total', 'Port link failures',
                                     ['switch_name', 'switch_ip', 'port_index'])
brocade_port_speed = Gauge('brocade_port_speed_gbps', 'Port speed in Gbps',
                           ['switch_name', 'switch_ip', 'port_index'])

# Switch Metrics
brocade_switch_status = Gauge('brocade_switch_status', 'Switch overall status (1=OK)',
                              ['switch_name', 'switch_ip'])
brocade_switch_temperature = Gauge('brocade_switch_temperature_celsius', 'Switch temperature',
                                   ['switch_name', 'switch_ip', 'sensor_name'])

# Exporter Metrics
brocade_scrape_duration = Gauge('brocade_scrape_duration_seconds', 'Scrape duration', ['switch_name'])
brocade_scrape_errors = Counter('brocade_scrape_errors_total', 'Scrape errors',
                                ['switch_name', 'error_type'])
brocade_exporter_info = Info('brocade_exporter', 'Exporter info')

# TOPOLOGY METRICS - For end-to-end path visualization
brocade_port_wwpn = Info('brocade_port_wwpn', 'Port WWPN for FC topology',
                        ['switch_name', 'switch_ip', 'port_index'])
brocade_fc_zone_info = Info('brocade_fc_zone', 'FC zone configuration',
                           ['switch_name', 'zone_name', 'zoneset_name'])
brocade_zone_member = Info('brocade_zone_member', 'FC zone member information',
                          ['switch_name', 'zone_name', 'member_wwpn'])
brocade_active_zoneset = Info('brocade_active_zoneset', 'Active zoneset information',
                             ['switch_name', 'zoneset_name'])

# ============================================================================
# Brocade SNMP OIDs
# ============================================================================

BROCADE_OIDS = {
    'sysDescr': '1.3.6.1.2.1.1.1.0',
    'sysUpTime': '1.3.6.1.2.1.1.3.0',
    'ifNumber': '1.3.6.1.2.1.2.1.0',
    'ifDescr': '1.3.6.1.2.1.2.2.1.2',
    'ifType': '1.3.6.1.2.1.2.2.1.3',
    'ifSpeed': '1.3.6.1.2.1.2.2.1.5',
    'ifOperStatus': '1.3.6.1.2.1.2.2.1.8',
    'ifAdminStatus': '1.3.6.1.2.1.2.2.1.7',
    'ifInOctets': '1.3.6.1.2.1.2.2.1.10',
    'ifOutOctets': '1.3.6.1.2.1.2.2.1.16',
    'ifInErrors': '1.3.6.1.2.1.2.2.1.14',
    'ifOutErrors': '1.3.6.1.2.1.2.2.1.20',
    # Brocade-specific OIDs
    'swFCPortTxWords': '1.3.6.1.4.1.1588.2.1.1.1.6.2.1.8',
    'swFCPortRxWords': '1.3.6.1.4.1.1588.2.1.1.1.6.2.1.9',
    'swFCPortLinkFailures': '1.3.6.1.4.1.1588.2.1.1.1.6.2.1.11',
    'swFCPortName': '1.3.6.1.4.1.1588.2.1.1.1.6.2.1.36',
    # TOPOLOGY OIDs - For end-to-end path visualization
    'swFCPortWWN': '1.3.6.1.4.1.1588.2.1.1.1.6.2.1.4',  # Port WWN/WWPN
    'swFCPortNodeName': '1.3.6.1.4.1.1588.2.1.1.1.6.2.1.37',  # Connected node WWN
    'swZoneName': '1.3.6.1.4.1.1588.2.1.1.1.22.2.1.2',  # Zone names
    'swZoneSetName': '1.3.6.1.4.1.1588.2.1.1.1.22.3.1.2',  # Zone set names
    'swZoneSetActivate': '1.3.6.1.4.1.1588.2.1.1.1.22.3.1.3',  # Active zone set
}

# ============================================================================
# SNMP Client
# ============================================================================

class SNMPClient:
    def __init__(self, host, community='public', port=161):
        self.host = host
        self.community = community
        self.port = port
        
    def get(self, oid):
        try:
            iterator = getCmd(
                SnmpEngine(),
                CommunityData(self.community),
                UdpTransportTarget((self.host, self.port), timeout=5, retries=2),
                ContextData(),
                ObjectType(ObjectIdentity(oid))
            )
            
            errorIndication, errorStatus, errorIndex, varBinds = next(iterator)
            
            if errorIndication or errorStatus:
                return None
            
            return varBinds[0][1].prettyPrint()
        except Exception as e:
            logger.debug(f"SNMP GET error for {oid}: {e}")
            return None
    
    def walk(self, oid):
        results = []
        try:
            iterator = nextCmd(
                SnmpEngine(),
                CommunityData(self.community),
                UdpTransportTarget((self.host, self.port), timeout=5, retries=2),
                ContextData(),
                ObjectType(ObjectIdentity(oid)),
                lexicographicMode=False
            )
            
            for errorIndication, errorStatus, errorIndex, varBinds in iterator:
                if errorIndication or errorStatus:
                    break
                for varBind in varBinds:
                    oid_str = varBind[0].prettyPrint()
                    value = varBind[1].prettyPrint()
                    # Extract port index from OID
                    port_idx = oid_str.split('.')[-1]
                    results.append((port_idx, value))
        except Exception as e:
            logger.debug(f"SNMP WALK error for {oid}: {e}")
        
        return results

# ============================================================================
# Brocade Collector
# ============================================================================

class BrocadeCollector:
    def __init__(self, switches):
        self.switches = switches
    
    def collect_switch(self, switch_config):
        switch_name = switch_config['name']
        switch_ip = switch_config['host']
        community = switch_config.get('community', 'public')
        active_ports = switch_config.get('active_ports', 56)
        
        start_time = time.time()
        
        try:
            client = SNMPClient(switch_ip, community)
            
            # Test connectivity
            sys_descr = client.get(BROCADE_OIDS['sysDescr'])
            if not sys_descr:
                logger.warning(f"Cannot connect to {switch_name} ({switch_ip})")
                brocade_switch_status.labels(switch_name=switch_name, switch_ip=switch_ip).set(0)
                brocade_scrape_errors.labels(switch_name=switch_name, error_type='connection').inc()
                return
            
            brocade_switch_status.labels(switch_name=switch_name, switch_ip=switch_ip).set(1)
            
            # Collect port metrics
            port_statuses = client.walk(BROCADE_OIDS['ifOperStatus'])
            port_admin_statuses = client.walk(BROCADE_OIDS['ifAdminStatus'])
            port_speeds = client.walk(BROCADE_OIDS['ifSpeed'])
            port_names = client.walk(BROCADE_OIDS['swFCPortName'])
            port_rx_octets = client.walk(BROCADE_OIDS['ifInOctets'])
            port_tx_octets = client.walk(BROCADE_OIDS['ifOutOctets'])
            port_in_errors = client.walk(BROCADE_OIDS['ifInErrors'])
            port_out_errors = client.walk(BROCADE_OIDS['ifOutErrors'])
            
            # Process metrics for active ports only
            for port_idx, status in port_statuses:
                port_num = int(port_idx)
                if port_num > active_ports:
                    continue
                
                port_name = f"port-{port_idx}"
                for idx, name in port_names:
                    if idx == port_idx:
                        port_name = name
                        break
                
                # Port status (1=up, 2=down)
                oper_status = 1 if status == '1' else 0
                brocade_port_status.labels(
                    switch_name=switch_name,
                    switch_ip=switch_ip,
                    port_index=port_idx,
                    port_name=port_name
                ).set(oper_status)
                
                # Port speed (convert to Gbps)
                for idx, speed in port_speeds:
                    if idx == port_idx:
                        speed_gbps = int(speed) / 1000000000 if speed.isdigit() else 0
                        brocade_port_speed.labels(
                            switch_name=switch_name,
                            switch_ip=switch_ip,
                            port_index=port_idx
                        ).set(speed_gbps)
                        break
                
                # Port traffic
                for idx, rx_octets in port_rx_octets:
                    if idx == port_idx and rx_octets.isdigit():
                        brocade_port_rx_bytes.labels(
                            switch_name=switch_name,
                            switch_ip=switch_ip,
                            port_index=port_idx
                        ).inc(int(rx_octets))
                        break
                
                for idx, tx_octets in port_tx_octets:
                    if idx == port_idx and tx_octets.isdigit():
                        brocade_port_tx_bytes.labels(
                            switch_name=switch_name,
                            switch_ip=switch_ip,
                            port_index=port_idx
                        ).inc(int(tx_octets))
                        break
                
                # Port errors
                for idx, errors in port_in_errors:
                    if idx == port_idx and errors.isdigit():
                        brocade_port_errors.labels(
                            switch_name=switch_name,
                            switch_ip=switch_ip,
                            port_index=port_idx,
                            error_type='rx'
                        ).inc(int(errors))
                        break
                
                for idx, errors in port_out_errors:
                    if idx == port_idx and errors.isdigit():
                        brocade_port_errors.labels(
                            switch_name=switch_name,
                            switch_ip=switch_ip,
                            port_index=port_idx,
                            error_type='tx'
                        ).inc(int(errors))
                        break
            
            # Collect topology data for end-to-end visualization
            self._collect_topology_data(client, switch_name, switch_ip, active_ports)
            
            duration = time.time() - start_time
            brocade_scrape_duration.labels(switch_name=switch_name).set(duration)
            logger.debug(f"Collected metrics for {switch_name} in {duration:.2f}s")
            
        except Exception as e:
            logger.error(f"Error collecting from {switch_name}: {e}")
            brocade_scrape_errors.labels(switch_name=switch_name, error_type='collection').inc()
    
    def _collect_topology_data(self, client, switch_name, switch_ip, active_ports):
        """
        Collect topology data for end-to-end path visualization
        CRITICAL for correlating Infinibox WWPNs → FC Zones → ESXi HBAs
        """
        try:
            # 1. Collect Port WWPNs
            port_wwns = client.walk(BROCADE_OIDS['swFCPortWWN'])
            port_node_names = client.walk(BROCADE_OIDS['swFCPortNodeName'])
            
            for port_idx, wwn_hex in port_wwns:
                port_num = int(port_idx)
                if port_num > active_ports:
                    continue
                
                # Convert hex WWN to colon-separated format
                try:
                    # WWN comes as hex string, convert to standard WWPN format
                    wwpn = self._format_wwpn(wwn_hex)
                    
                    # Get connected node name if available
                    connected_node = None
                    for idx, node_name in port_node_names:
                        if idx == port_idx:
                            connected_node = node_name
                            break
                    
                    brocade_port_wwpn.labels(
                        switch_name=switch_name,
                        switch_ip=switch_ip,
                        port_index=port_idx
                    ).info({
                        'wwpn': wwpn,
                        'connected_node': connected_node or 'unknown',
                        'port_state': 'active'
                    })
                except Exception as e:
                    logger.debug(f"Could not format WWPN for port {port_idx}: {e}")
            
            logger.debug(f"Collected WWPNs for {len(port_wwns)} ports on {switch_name}")
            
            # 2. Collect FC Zone Configuration
            # Note: Zone data may require SSH/CLI access for full details
            # For now, we'll collect what's available via SNMP
            try:
                zone_names = client.walk(BROCADE_OIDS['swZoneName'])
                zoneset_names = client.walk(BROCADE_OIDS['swZoneSetName'])
                active_zonesets = client.walk(BROCADE_OIDS['swZoneSetActivate'])
                
                # Collect active zoneset info
                for idx, zoneset_name in zoneset_names:
                    for idx2, is_active in active_zonesets:
                        if idx == idx2 and is_active == '1':
                            brocade_active_zoneset.labels(
                                switch_name=switch_name,
                                zoneset_name=zoneset_name
                            ).info({
                                'status': 'active',
                                'zoneset_index': idx
                            })
                
                # Collect zone information
                for zone_idx, zone_name in zone_names:
                    # Find which zoneset this zone belongs to
                    zoneset = 'default'
                    for idx, zs_name in zoneset_names:
                        if idx == zone_idx:
                            zoneset = zs_name
                            break
                    
                    brocade_fc_zone_info.labels(
                        switch_name=switch_name,
                        zone_name=zone_name,
                        zoneset_name=zoneset
                    ).info({
                        'zone_index': zone_idx,
                        'zone_type': 'standard'
                    })
                
                logger.debug(f"Collected {len(zone_names)} zones and {len(zoneset_names)} zonesets from {switch_name}")
                
            except Exception as e:
                logger.debug(f"Could not collect zone data via SNMP (may need CLI access): {e}")
                logger.info(f"For full zone membership details, enable SSH access to {switch_name}")
                
        except Exception as e:
            logger.error(f"Error collecting topology data from {switch_name}: {e}")
            brocade_scrape_errors.labels(switch_name=switch_name, error_type='topology').inc()
    
    def _format_wwpn(self, wwn_hex):
        """
        Format WWN from hex string to standard colon-separated WWPN format
        Example: 0x500601653ee00000 -> 50:06:01:65:3e:e0:00:00
        """
        # Remove '0x' prefix if present
        wwn_clean = wwn_hex.replace('0x', '').replace('0X', '')
        
        # If it's a byte string, convert it
        if isinstance(wwn_clean, bytes):
            wwn_clean = wwn_clean.hex()
        
        # Ensure it's 16 characters (pad with zeros if needed)
        wwn_clean = wwn_clean.zfill(16)
        
        # Format as colon-separated
        wwpn = ':'.join([wwn_clean[i:i+2] for i in range(0, 16, 2)])
        
        return wwpn.lower()
    
    def collect_all(self):
        logger.info("Collecting metrics from all Brocade switches")
        threads = []
        for switch in self.switches:
            thread = threading.Thread(target=self.collect_switch, args=(switch,))
            threads.append(thread)
            thread.start()
        
        for thread in threads:
            thread.join(timeout=15)

# ============================================================================
# Flask Routes
# ============================================================================

@app.route('/health')
def health():
    return Response("OK", status=200)

@app.route('/metrics')
def metrics():
    return Response(generate_latest(REGISTRY), mimetype='text/plain')

# ============================================================================
# Main
# ============================================================================

def main():
    brocade_exporter_info.info({
        'version': '1.0.0',
        'build_date': '2025-10-22',
        'solution': 'Open Source Community'
    })
    
    config_file = os.environ.get('CONFIG_FILE', '/app/config.yml')
    with open(config_file, 'r') as f:
        config = yaml.safe_load(f)
    
    switches = config.get('switches', [])
    if not switches:
        logger.error("No switches configured")
        sys.exit(1)
    
    exporter_port = int(os.environ.get('EXPORTER_PORT', config.get('port', 9602)))
    scrape_interval = int(os.environ.get('SCRAPE_INTERVAL', config.get('scrape_interval', 10)))
    
    logger.info(f"Starting Brocade Exporter for {len(switches)} switches")
    
    collector = BrocadeCollector(switches)
    
    def collect_loop():
        while True:
            try:
                collector.collect_all()
            except Exception as e:
                logger.error(f"Error in collection loop: {e}")
            time.sleep(scrape_interval)
    
    collection_thread = threading.Thread(target=collect_loop, daemon=True)
    collection_thread.start()
    
    logger.info(f"Exporter ready on port {exporter_port}")
    app.run(host='0.0.0.0', port=exporter_port, debug=False)

if __name__ == '__main__':
    main()
