
# VMware vCenter Exporter for Prometheus

framework code (NOT production-ready, see DISCLAIMER.txt) Prometheus exporter for VMware vCenter.

## Features

✅ **Comprehensive Metrics Collection**
- vCenter Information
- Cluster CPU and Memory
- ESXi Host Metrics (14x Lenovo SR950 v3 servers)
- VM Performance Metrics
- Datastore Capacity and Performance
- VM-to-Datastore Mappings (critical for correlation)

✅ **framework code (NOT production-ready, see DISCLAIMER.txt)**
- Automatic connection retry
- Metrics caching
- Structured JSON logging
- Health check endpoint
- Support for 5-second scrape intervals

## Prerequisites

- Python 3.11+
- vCenter Network Access
- Read-only monitoring user on vCenter

## Creating vCenter Monitoring User

```powershell
# Connect to vCenter
Connect-VIServer -Server vcenter.Organization.local

# Create read-only role
New-VIRole -Name "Monitoring-ReadOnly" -Privilege (
    Get-VIPrivilege -Id "System.Anonymous",
    Get-VIPrivilege -Id "System.Read",
    Get-VIPrivilege -Id "System.View"
)

# Create user and assign role
New-VIPermission -Role "Monitoring-ReadOnly" `
    -Principal "monitoring@vsphere.local" `
    -Entity (Get-Folder -NoRecursion)
```

## Installation

### Docker

```bash
docker build -t vmware-exporter:latest .

docker run -d \
  --name vmware-exporter \
  -p 9601:9601 \
  -e VCENTER_HOST=vcenter.local \
  -e VCENTER_USER=monitoring@vsphere.local \
  -e VCENTER_PASSWORD=password \
  -e SCRAPE_INTERVAL=5 \
  vmware-exporter:latest
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `VCENTER_HOST` | vCenter hostname/IP | `vcenter.local` |
| `VCENTER_USER` | vCenter username | `monitoring@vsphere.local` |
| `VCENTER_PASSWORD` | vCenter password | `changeme` |
| `VCENTER_PORT` | vCenter port | `443` |
| `VERIFY_SSL` | Verify SSL certificate | `false` |
| `EXPORTER_PORT` | Exporter port | `9601` |
| `SCRAPE_INTERVAL` | Collection interval (seconds) | `5` |

## Metrics

### vCenter Info
- `vmware_vcenter_info` - vCenter information

### Cluster Metrics
- `vmware_cluster_cpu_mhz_total` - Total CPU capacity
- `vmware_cluster_cpu_mhz_used` - Used CPU
- `vmware_cluster_memory_bytes_total` - Total memory
- `vmware_cluster_memory_bytes_used` - Used memory

### ESXi Host Metrics
- `vmware_host_connection_state` - Connection state
- `vmware_host_power_state` - Power state
- `vmware_host_cpu_usage_mhz` - CPU usage
- `vmware_host_memory_usage_bytes` - Memory usage
- `vmware_host_uptime_seconds` - Uptime

### VM Metrics
- `vmware_vm_power_state` - VM power state
- `vmware_vm_cpu_usage_mhz` - VM CPU usage
- `vmware_vm_memory_usage_bytes` - VM memory usage
- `vmware_vm_disk_read_bytes_per_sec` - Disk read rate
- `vmware_vm_network_rx_bytes_per_sec` - Network receive rate

### Datastore Metrics
- `vmware_datastore_capacity_bytes` - Total capacity
- `vmware_datastore_free_bytes` - Free space
- `vmware_datastore_used_percent` - Usage percentage

## Prometheus Configuration

```yaml
scrape_configs:
  - job_name: 'vmware'
    scrape_interval: 5s
    scrape_timeout: 4s
    static_configs:
      - targets: ['vmware-exporter:9601']
```

## License

Proprietary - Open Source Community
