
#!/usr/bin/env python3
"""
Juniper Switch SNMP Exporter
Open Source Community

Monitors Juniper QFX5120 (Core) and QFX5110 (Leaf) switches.
High-frequency polling (10 seconds) for network metrics.
"""

import os
import sys
import time
import logging
import yaml
from prometheus_client import Gauge, Counter, Info, generate_latest, REGISTRY
from flask import Flask, Response
from pysnmp.hlapi import *
import threading

logging.basicConfig(
    level=os.environ.get('LOG_LEVEL', 'INFO'),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('juniper_exporter')

app = Flask(__name__)

# ============================================================================
# Prometheus Metrics
# ============================================================================

# Interface Metrics
juniper_interface_status = Gauge('juniper_interface_status', 'Interface status (1=Up)',
                                 ['switch_name', 'switch_ip', 'interface', 'description'])
juniper_interface_admin_status = Gauge('juniper_interface_admin_status', 'Interface admin status',
                                       ['switch_name', 'switch_ip', 'interface'])
juniper_interface_speed = Gauge('juniper_interface_speed_mbps', 'Interface speed in Mbps',
                                ['switch_name', 'switch_ip', 'interface'])
juniper_interface_rx_bytes = Counter('juniper_interface_rx_bytes_total', 'Interface received bytes',
                                     ['switch_name', 'switch_ip', 'interface'])
juniper_interface_tx_bytes = Counter('juniper_interface_tx_bytes_total', 'Interface transmitted bytes',
                                     ['switch_name', 'switch_ip', 'interface'])
juniper_interface_errors = Counter('juniper_interface_errors_total', 'Interface errors',
                                   ['switch_name', 'switch_ip', 'interface', 'direction'])

# Switch Metrics
juniper_switch_status = Gauge('juniper_switch_status', 'Switch status (1=OK)',
                              ['switch_name', 'switch_ip'])
juniper_cpu_usage = Gauge('juniper_cpu_usage_percent', 'CPU usage percentage',
                          ['switch_name', 'switch_ip'])
juniper_memory_usage = Gauge('juniper_memory_usage_percent', 'Memory usage percentage',
                             ['switch_name', 'switch_ip'])

# Exporter Metrics
juniper_scrape_duration = Gauge('juniper_scrape_duration_seconds', 'Scrape duration', ['switch_name'])
juniper_scrape_errors = Counter('juniper_scrape_errors_total', 'Scrape errors',
                                ['switch_name', 'error_type'])
juniper_exporter_info = Info('juniper_exporter', 'Exporter info')

# ============================================================================
# Juniper SNMP OIDs
# ============================================================================

JUNIPER_OIDS = {
    'sysDescr': '1.3.6.1.2.1.1.1.0',
    'sysUpTime': '1.3.6.1.2.1.1.3.0',
    'ifDescr': '1.3.6.1.2.1.2.2.1.2',
    'ifAlias': '1.3.6.1.2.1.31.1.1.1.18',
    'ifSpeed': '1.3.6.1.2.1.2.2.1.5',
    'ifHighSpeed': '1.3.6.1.2.1.31.1.1.1.15',
    'ifOperStatus': '1.3.6.1.2.1.2.2.1.8',
    'ifAdminStatus': '1.3.6.1.2.1.2.2.1.7',
    'ifInOctets': '1.3.6.1.2.1.2.2.1.10',
    'ifOutOctets': '1.3.6.1.2.1.2.2.1.16',
    'ifInErrors': '1.3.6.1.2.1.2.2.1.14',
    'ifOutErrors': '1.3.6.1.2.1.2.2.1.20',
    # Juniper-specific
    'jnxOperatingCPU': '1.3.6.1.4.1.2636.3.1.13.1.8',
    'jnxOperatingBuffer': '1.3.6.1.4.1.2636.3.1.13.1.11',
}

# ============================================================================
# SNMP Client
# ============================================================================

class SNMPClient:
    def __init__(self, host, community='public', port=161):
        self.host = host
        self.community = community
        self.port = port
        
    def get(self, oid):
        try:
            iterator = getCmd(
                SnmpEngine(),
                CommunityData(self.community),
                UdpTransportTarget((self.host, self.port), timeout=5, retries=2),
                ContextData(),
                ObjectType(ObjectIdentity(oid))
            )
            
            errorIndication, errorStatus, errorIndex, varBinds = next(iterator)
            
            if errorIndication or errorStatus:
                return None
            
            return varBinds[0][1].prettyPrint()
        except Exception as e:
            logger.debug(f"SNMP GET error: {e}")
            return None
    
    def walk(self, oid):
        results = []
        try:
            iterator = nextCmd(
                SnmpEngine(),
                CommunityData(self.community),
                UdpTransportTarget((self.host, self.port), timeout=5, retries=2),
                ContextData(),
                ObjectType(ObjectIdentity(oid)),
                lexicographicMode=False
            )
            
            for errorIndication, errorStatus, errorIndex, varBinds in iterator:
                if errorIndication or errorStatus:
                    break
                for varBind in varBinds:
                    oid_str = varBind[0].prettyPrint()
                    value = varBind[1].prettyPrint()
                    if_idx = oid_str.split('.')[-1]
                    results.append((if_idx, value))
        except Exception as e:
            logger.debug(f"SNMP WALK error: {e}")
        
        return results

# ============================================================================
# Juniper Collector
# ============================================================================

class JuniperCollector:
    def __init__(self, switches):
        self.switches = switches
    
    def collect_switch(self, switch_config):
        switch_name = switch_config['name']
        switch_ip = switch_config['host']
        community = switch_config.get('community', 'public')
        
        start_time = time.time()
        
        try:
            client = SNMPClient(switch_ip, community)
            
            # Test connectivity
            sys_descr = client.get(JUNIPER_OIDS['sysDescr'])
            if not sys_descr:
                logger.warning(f"Cannot connect to {switch_name}")
                juniper_switch_status.labels(switch_name=switch_name, switch_ip=switch_ip).set(0)
                juniper_scrape_errors.labels(switch_name=switch_name, error_type='connection').inc()
                return
            
            juniper_switch_status.labels(switch_name=switch_name, switch_ip=switch_ip).set(1)
            
            # Collect interface metrics
            if_descriptions = client.walk(JUNIPER_OIDS['ifDescr'])
            if_aliases = client.walk(JUNIPER_OIDS['ifAlias'])
            if_statuses = client.walk(JUNIPER_OIDS['ifOperStatus'])
            if_admin_statuses = client.walk(JUNIPER_OIDS['ifAdminStatus'])
            if_speeds = client.walk(JUNIPER_OIDS['ifHighSpeed'])
            if_rx_octets = client.walk(JUNIPER_OIDS['ifInOctets'])
            if_tx_octets = client.walk(JUNIPER_OIDS['ifOutOctets'])
            if_in_errors = client.walk(JUNIPER_OIDS['ifInErrors'])
            if_out_errors = client.walk(JUNIPER_OIDS['ifOutErrors'])
            
            # Build interface name mapping
            if_names = {}
            if_descs = {}
            for idx, desc in if_descriptions:
                if_names[idx] = desc
            for idx, alias in if_aliases:
                if_descs[idx] = alias if alias else ''
            
            # Process interface metrics
            for if_idx, status in if_statuses:
                if_name = if_names.get(if_idx, f"if-{if_idx}")
                if_desc = if_descs.get(if_idx, '')
                
                # Skip management interfaces in some deployments
                if 'lo0' in if_name or 'me0' in if_name:
                    continue
                
                # Interface status
                oper_status = 1 if status == '1' else 0
                juniper_interface_status.labels(
                    switch_name=switch_name,
                    switch_ip=switch_ip,
                    interface=if_name,
                    description=if_desc
                ).set(oper_status)
                
                # Interface speed
                for idx, speed in if_speeds:
                    if idx == if_idx and speed.isdigit():
                        juniper_interface_speed.labels(
                            switch_name=switch_name,
                            switch_ip=switch_ip,
                            interface=if_name
                        ).set(int(speed))
                        break
                
                # Interface traffic
                for idx, rx_octets in if_rx_octets:
                    if idx == if_idx and rx_octets.isdigit():
                        juniper_interface_rx_bytes.labels(
                            switch_name=switch_name,
                            switch_ip=switch_ip,
                            interface=if_name
                        ).inc(int(rx_octets))
                        break
                
                for idx, tx_octets in if_tx_octets:
                    if idx == if_idx and tx_octets.isdigit():
                        juniper_interface_tx_bytes.labels(
                            switch_name=switch_name,
                            switch_ip=switch_ip,
                            interface=if_name
                        ).inc(int(tx_octets))
                        break
                
                # Interface errors
                for idx, errors in if_in_errors:
                    if idx == if_idx and errors.isdigit():
                        juniper_interface_errors.labels(
                            switch_name=switch_name,
                            switch_ip=switch_ip,
                            interface=if_name,
                            direction='rx'
                        ).inc(int(errors))
                        break
                
                for idx, errors in if_out_errors:
                    if idx == if_idx and errors.isdigit():
                        juniper_interface_errors.labels(
                            switch_name=switch_name,
                            switch_ip=switch_ip,
                            interface=if_name,
                            direction='tx'
                        ).inc(int(errors))
                        break
            
            # CPU and Memory
            cpu_usage = client.get(JUNIPER_OIDS['jnxOperatingCPU'] + '.1.0.0.0')
            if cpu_usage and cpu_usage.isdigit():
                juniper_cpu_usage.labels(switch_name=switch_name, switch_ip=switch_ip).set(int(cpu_usage))
            
            memory_usage = client.get(JUNIPER_OIDS['jnxOperatingBuffer'] + '.1.0.0.0')
            if memory_usage and memory_usage.isdigit():
                juniper_memory_usage.labels(switch_name=switch_name, switch_ip=switch_ip).set(int(memory_usage))
            
            duration = time.time() - start_time
            juniper_scrape_duration.labels(switch_name=switch_name).set(duration)
            logger.debug(f"Collected metrics for {switch_name} in {duration:.2f}s")
            
        except Exception as e:
            logger.error(f"Error collecting from {switch_name}: {e}")
            juniper_scrape_errors.labels(switch_name=switch_name, error_type='collection').inc()
    
    def collect_all(self):
        logger.info("Collecting metrics from all Juniper switches")
        threads = []
        for switch in self.switches:
            thread = threading.Thread(target=self.collect_switch, args=(switch,))
            threads.append(thread)
            thread.start()
        
        for thread in threads:
            thread.join(timeout=15)

# ============================================================================
# Flask Routes
# ============================================================================

@app.route('/health')
def health():
    return Response("OK", status=200)

@app.route('/metrics')
def metrics():
    return Response(generate_latest(REGISTRY), mimetype='text/plain')

# ============================================================================
# Main
# ============================================================================

def main():
    juniper_exporter_info.info({
        'version': '1.0.0',
        'build_date': '2025-10-22',
        'solution': 'Open Source Community'
    })
    
    config_file = os.environ.get('CONFIG_FILE', '/app/config.yml')
    with open(config_file, 'r') as f:
        config = yaml.safe_load(f)
    
    switches = config.get('switches', [])
    if not switches:
        logger.error("No switches configured")
        sys.exit(1)
    
    exporter_port = int(os.environ.get('EXPORTER_PORT', config.get('port', 9603)))
    scrape_interval = int(os.environ.get('SCRAPE_INTERVAL', config.get('scrape_interval', 10)))
    
    logger.info(f"Starting Juniper Exporter for {len(switches)} switches")
    
    collector = JuniperCollector(switches)
    
    def collect_loop():
        while True:
            try:
                collector.collect_all()
            except Exception as e:
                logger.error(f"Error in collection loop: {e}")
            time.sleep(scrape_interval)
    
    collection_thread = threading.Thread(target=collect_loop, daemon=True)
    collection_thread.start()
    
    logger.info(f"Exporter ready on port {exporter_port}")
    app.run(host='0.0.0.0', port=exporter_port, debug=False)

if __name__ == '__main__':
    main()

