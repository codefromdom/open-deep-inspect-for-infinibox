
# Infinidat InfiniBox Exporter for Prometheus

framework code (NOT production-ready, see DISCLAIMER.txt) Prometheus exporter for Infinidat InfiniBox storage systems.

## Features

✅ **Comprehensive Metrics Collection**
- SSA Controller Status (3 active controllers monitoring)
- Pool Capacity (total, used, free, percentage)
- Volume Performance (IOPS, throughput, latency)
- Volume Details (size, pool assignment)
- Host Mappings
- Events and Alerts
- System Information

✅ **framework code (NOT production-ready, see DISCLAIMER.txt)**
- Automatic connection retry with exponential backoff
- Metrics caching to reduce API load
- Structured JSON logging
- Health check endpoint
- Graceful error handling
- Support for 1-5 second scrape intervals

✅ **Prometheus Compatible**
- Standard Prometheus metrics format
- Proper label usage
- Counter, Gauge, and Histogram metrics
- Exporter self-monitoring metrics

## Prerequisites

- Python 3.11+
- InfiniBox Management Network Access
- Read-only monitoring user on InfiniBox

## Installation

### Docker (Recommended)

```bash
# Build the image
docker build -t infinibox-exporter:latest .

# Run the exporter
docker run -d \
  --name infinibox-exporter \
  -p 9600:9600 \
  -e INFINIBOX_HOST=infinibox-mgmt.local \
  -e INFINIBOX_USER=monitoring \
  -e INFINIBOX_PASSWORD=secretpassword \
  -e SCRAPE_INTERVAL=5 \
  infinibox-exporter:latest
```

### Python Virtual Environment

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run exporter
export INFINIBOX_HOST=infinibox-mgmt.local
export INFINIBOX_USER=monitoring
export INFINIBOX_PASSWORD=secretpassword
export EXPORTER_PORT=9600
export SCRAPE_INTERVAL=5

python infinidat_exporter.py
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `INFINIBOX_HOST` | InfiniBox management hostname/IP | `infinibox-mgmt.local` |
| `INFINIBOX_USER` | InfiniBox username | `monitoring` |
| `INFINIBOX_PASSWORD` | InfiniBox password | `changeme` |
| `EXPORTER_PORT` | Port for Prometheus metrics | `9600` |
| `SCRAPE_INTERVAL` | Collection interval in seconds (1-5 for high-frequency) | `5` |
| `CACHE_TTL` | Metrics cache TTL in seconds | `5` |
| `CONFIG_FILE` | Path to YAML config file | `/app/config.yml` |

### Configuration File

Create `config.yml`:

```yaml
host: "infinibox-mgmt.Organization.local"
username: "monitoring"
password: "your-secure-password"
exporter_port: 9600
scrape_interval: 5
cache_ttl: 5
```

## Creating InfiniBox Monitoring User

```bash
# SSH to InfiniBox management
ssh admin@infinibox-mgmt.local

# Create read-only monitoring user
infinishell> user.create name=monitoring email=monitoring@Organization.local
infinishell> user.set_password monitoring
infinishell> user.add_role monitoring read_only
infinishell> user.set_enabled monitoring true
infinishell> exit
```

## Metrics

### System Metrics

- `infinibox_system_info` - System information (name, serial, version, model)
- `infinibox_exporter_connection_status` - Connection status (1=connected, 0=disconnected)

### Controller Metrics (SSA - 3 Active Controllers)

- `infinibox_controller_status{controller_id, controller_name}` - Controller status (1=active, 0=inactive)
- `infinibox_controller_cpu_usage_percent{controller_id, controller_name}` - CPU usage
- `infinibox_controller_memory_usage_percent{controller_id, controller_name}` - Memory usage

### Capacity Metrics

- `infinibox_pool_capacity_bytes{pool_id, pool_name}` - Total pool capacity
- `infinibox_pool_capacity_free_bytes{pool_id, pool_name}` - Free capacity
- `infinibox_pool_capacity_used_bytes{pool_id, pool_name}` - Used capacity
- `infinibox_pool_capacity_used_percent{pool_id, pool_name}` - Usage percentage

### Volume Metrics

- `infinibox_volumes_total{pool_id, pool_name}` - Number of volumes per pool
- `infinibox_volume_size_bytes{volume_id, volume_name, pool_name}` - Volume size
- `infinibox_volume_iops_read{volume_id, volume_name}` - Read IOPS
- `infinibox_volume_iops_write{volume_id, volume_name}` - Write IOPS
- `infinibox_volume_throughput_read_bytes{volume_id, volume_name}` - Read throughput
- `infinibox_volume_throughput_write_bytes{volume_id, volume_name}` - Write throughput
- `infinibox_volume_latency_read_ms{volume_id, volume_name}` - Read latency
- `infinibox_volume_latency_write_ms{volume_id, volume_name}` - Write latency

### Host Metrics

- `infinibox_hosts_total` - Total number of registered hosts

### Event Metrics

- `infinibox_events_total{severity, event_type}` - Event counters

### Exporter Metrics

- `infinibox_scrape_duration_seconds{operation}` - Scrape duration histogram
- `infinibox_scrape_errors_total{operation}` - Error counters

## Prometheus Configuration

Add to `prometheus.yml`:

```yaml
scrape_configs:
  - job_name: 'infinibox'
    scrape_interval: 5s  # High-frequency monitoring
    scrape_timeout: 4s
    static_configs:
      - targets: ['infinibox-exporter:9600']
    relabel_configs:
      - target_label: instance
        replacement: 'infinibox-primary'
      - target_label: vendor
        replacement: 'infinidat'
```

## Health Check

```bash
# Check if exporter is running
curl http://localhost:9600/metrics

# Check connection status
curl -s http://localhost:9600/metrics | grep infinibox_exporter_connection_status
```

## Troubleshooting

### Connection Issues

```bash
# Check logs
docker logs infinibox-exporter

# Verify network connectivity
ping infinibox-mgmt.local

# Test API access
curl -k https://infinibox-mgmt.local/api/rest/system
```

### High API Load

If InfiniBox API becomes overloaded:

1. Increase `CACHE_TTL` to 10-15 seconds
2. Increase `SCRAPE_INTERVAL` to 10-15 seconds
3. Reduce number of volumes being monitored (filter in Prometheus)

### Missing Metrics

- Check exporter logs for errors
- Verify user permissions on InfiniBox
- Ensure InfiniBox firmware version is compatible with InfiniSDK

## Performance Tuning

### High-Frequency Monitoring (1-5 seconds)

```yaml
# Optimized for 1-5 second scrapes
scrape_interval: 2  # 2 seconds
cache_ttl: 2  # Cache for 2 seconds
```

### Standard Monitoring (10-15 seconds)

```yaml
# Balanced configuration
scrape_interval: 10
cache_ttl: 10
```

## Support

- **Documentation**: See main README and docs/ directory
- **Issues**: Check logs with JSON logging enabled
- **Contact**: Open Source Community

## License

Proprietary - Open Source Community
