
#!/usr/bin/env python3
"""
Infinidat InfiniBox Exporter for Prometheus
framework code (NOT production-ready, see DISCLAIMER.txt) Implementation

Collects comprehensive metrics from InfiniBox storage system:
- SSA Controller status (3 active controllers)
- Capacity metrics (pools, volumes)
- Performance metrics (IOPS, throughput, latency)
- Volume details and mappings
- Host information
- Events and alerts
- Hardware health

Supports 1-5 second scrape intervals with caching and connection pooling.
"""

import os
import sys
import time
import json
import logging
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field

import yaml
from prometheus_client import start_http_server, Gauge, Counter, Histogram, Info
from prometheus_client.core import REGISTRY, GaugeMetricFamily, CounterMetricFamily

# InfiniSDK for Infinibox API
try:
    from infinisdk import InfiniBox
    from infinisdk.core.exceptions import APICommandFailed, InfiniSDKException
except ImportError:
    print("ERROR: infinisdk not installed. Install with: pip install infinisdk")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='{"timestamp": "%(asctime)s", "level": "%(levelname)s", "module": "%(name)s", "message": "%(message)s"}',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Configuration
@dataclass
class ExporterConfig:
    """Configuration for the Infinibox exporter"""
    infinibox_host: str
    infinibox_user: str
    infinibox_password: str
    exporter_port: int = 9600
    scrape_interval: int = 5  # seconds
    cache_ttl: int = 5  # seconds - cache metrics to reduce API load
    connection_timeout: int = 30
    max_retries: int = 3
    retry_delay: int = 5
    
    @classmethod
    def from_env(cls):
        """Load configuration from environment variables"""
        return cls(
            infinibox_host=os.getenv('INFINIBOX_HOST', 'infinibox-mgmt.local'),
            infinibox_user=os.getenv('INFINIBOX_USER', 'monitoring'),
            infinibox_password=os.getenv('INFINIBOX_PASSWORD', 'changeme'),
            exporter_port=int(os.getenv('EXPORTER_PORT', '9600')),
            scrape_interval=int(os.getenv('SCRAPE_INTERVAL', '5')),
            cache_ttl=int(os.getenv('CACHE_TTL', '5')),
        )
    
    @classmethod
    def from_file(cls, config_path: str):
        """Load configuration from YAML file"""
        try:
            with open(config_path, 'r') as f:
                config_data = yaml.safe_load(f)
            
            return cls(
                infinibox_host=config_data.get('host', 'infinibox-mgmt.local'),
                infinibox_user=config_data.get('username', 'monitoring'),
                infinibox_password=config_data.get('password', 'changeme'),
                exporter_port=config_data.get('exporter_port', 9600),
                scrape_interval=config_data.get('scrape_interval', 5),
            )
        except Exception as e:
            logger.error(f"Failed to load config from {config_path}: {e}")
            return cls.from_env()

# Metrics cache
@dataclass
class MetricsCache:
    """Cache for metrics to reduce API load"""
    data: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    ttl: int = 5  # seconds
    
    def is_valid(self) -> bool:
        """Check if cache is still valid"""
        return (datetime.now() - self.timestamp).total_seconds() < self.ttl
    
    def update(self, data: Dict[str, Any]):
        """Update cache with new data"""
        self.data = data
        self.timestamp = datetime.now()
    
    def get(self, key: str, default=None):
        """Get cached value"""
        if self.is_valid():
            return self.data.get(key, default)
        return default

class InfiniboxCollector:
    """
    framework code (NOT production-ready, see DISCLAIMER.txt) collector for InfiniBox metrics
    Implements connection pooling, retry logic, and caching
    """
    
    def __init__(self, config: ExporterConfig):
        self.config = config
        self.system: Optional[InfiniBox] = None
        self.cache = MetricsCache(ttl=config.cache_ttl)
        self.connection_lock = threading.Lock()
        self.last_connection_attempt = datetime.now()
        self.connection_retry_delay = timedelta(seconds=config.retry_delay)
        
        # Prometheus metrics
        self._init_metrics()
        
        logger.info(f"Initialized InfiniboxCollector for {config.infinibox_host}")
    
    def _init_metrics(self):
        """Initialize Prometheus metrics"""
        # System info
        self.system_info = Info('infinibox_system', 'InfiniBox system information')
        
        # Controller metrics
        self.controller_status = Gauge('infinibox_controller_status', 
                                       'Controller status (1=active, 0=inactive)',
                                       ['controller_id', 'controller_name'])
        self.controller_cpu_usage = Gauge('infinibox_controller_cpu_usage_percent',
                                          'Controller CPU usage percentage',
                                          ['controller_id', 'controller_name'])
        self.controller_memory_usage = Gauge('infinibox_controller_memory_usage_percent',
                                             'Controller memory usage percentage',
                                             ['controller_id', 'controller_name'])
        
        # Capacity metrics
        self.pool_capacity_total = Gauge('infinibox_pool_capacity_bytes',
                                         'Total pool capacity in bytes',
                                         ['pool_id', 'pool_name'])
        self.pool_capacity_free = Gauge('infinibox_pool_capacity_free_bytes',
                                        'Free pool capacity in bytes',
                                        ['pool_id', 'pool_name'])
        self.pool_capacity_used = Gauge('infinibox_pool_capacity_used_bytes',
                                        'Used pool capacity in bytes',
                                        ['pool_id', 'pool_name'])
        self.pool_capacity_percent = Gauge('infinibox_pool_capacity_used_percent',
                                           'Pool capacity used percentage',
                                           ['pool_id', 'pool_name'])
        
        # Volume metrics
        self.volume_count = Gauge('infinibox_volumes_total',
                                  'Total number of volumes',
                                  ['pool_id', 'pool_name'])
        self.volume_size = Gauge('infinibox_volume_size_bytes',
                                 'Volume size in bytes',
                                 ['volume_id', 'volume_name', 'pool_name'])
        self.volume_iops_read = Gauge('infinibox_volume_iops_read',
                                      'Volume read IOPS',
                                      ['volume_id', 'volume_name'])
        self.volume_iops_write = Gauge('infinibox_volume_iops_write',
                                       'Volume write IOPS',
                                       ['volume_id', 'volume_name'])
        self.volume_throughput_read = Gauge('infinibox_volume_throughput_read_bytes',
                                            'Volume read throughput in bytes/sec',
                                            ['volume_id', 'volume_name'])
        self.volume_throughput_write = Gauge('infinibox_volume_throughput_write_bytes',
                                             'Volume write throughput in bytes/sec',
                                             ['volume_id', 'volume_name'])
        self.volume_latency_read = Gauge('infinibox_volume_latency_read_ms',
                                         'Volume read latency in milliseconds',
                                         ['volume_id', 'volume_name'])
        self.volume_latency_write = Gauge('infinibox_volume_latency_write_ms',
                                          'Volume write latency in milliseconds',
                                          ['volume_id', 'volume_name'])
        
        # Host metrics
        self.host_count = Gauge('infinibox_hosts_total',
                                'Total number of registered hosts')
        
        # TOPOLOGY METRICS - For end-to-end path visualization
        self.volume_wwpn_info = Info('infinibox_volume_wwpn',
                                     'Volume WWPNs for FC topology',
                                     ['volume_id', 'volume_name'])
        self.volume_iqn_info = Info('infinibox_volume_iqn',
                                    'Volume IQNs for iSCSI topology',
                                    ['volume_id', 'volume_name'])
        self.host_mapping_info = Info('infinibox_host_mapping',
                                      'Host to volume mapping information',
                                      ['host_id', 'host_name', 'volume_id', 'volume_name'])
        self.lun_mapping = Gauge('infinibox_lun_mapping',
                                'LUN mapping information',
                                ['host_id', 'host_name', 'volume_id', 'volume_name', 'lun_id'])
        self.host_initiator_info = Info('infinibox_host_initiator',
                                        'Host initiator WWPNs and IQNs',
                                        ['host_id', 'host_name', 'initiator_type', 'initiator_address'])
        self.fc_port_wwpn = Info('infinibox_fc_port',
                                'Infinibox FC port WWPNs',
                                ['port_id', 'node_id'])
        
        # Event metrics
        self.events_total = Counter('infinibox_events_total',
                                    'Total number of events',
                                    ['severity', 'event_type'])
        
        # Exporter metrics
        self.scrape_duration = Histogram('infinibox_scrape_duration_seconds',
                                         'Duration of scrape operations',
                                         ['operation'])
        self.scrape_errors = Counter('infinibox_scrape_errors_total',
                                     'Total number of scrape errors',
                                     ['operation'])
        self.connection_status = Gauge('infinibox_exporter_connection_status',
                                       'Connection status to InfiniBox (1=connected, 0=disconnected)')
    
    def _connect(self) -> bool:
        """
        Establish connection to InfiniBox with retry logic
        Returns True if connected successfully
        """
        with self.connection_lock:
            # Check if we should retry connection
            if self.system is not None:
                try:
                    # Test connection
                    self.system.api.get('system')
                    return True
                except Exception:
                    logger.warning("Existing connection failed, reconnecting...")
                    self.system = None
            
            # Throttle connection attempts
            if datetime.now() - self.last_connection_attempt < self.connection_retry_delay:
                return False
            
            self.last_connection_attempt = datetime.now()
            
            # Attempt connection with retries
            for attempt in range(self.config.max_retries):
                try:
                    logger.info(f"Connecting to InfiniBox at {self.config.infinibox_host} (attempt {attempt + 1}/{self.config.max_retries})")
                    
                    self.system = InfiniBox(
                        self.config.infinibox_host,
                        auth=(self.config.infinibox_user, self.config.infinibox_password)
                    )
                    self.system.login()
                    
                    # Test connection
                    system_info = self.system.api.get('system')
                    logger.info(f"Successfully connected to InfiniBox: {system_info.get('name', 'Unknown')}")
                    
                    self.connection_status.set(1)
                    return True
                    
                except Exception as e:
                    logger.error(f"Connection attempt {attempt + 1} failed: {str(e)}")
                    if attempt < self.config.max_retries - 1:
                        time.sleep(self.config.retry_delay)
            
            self.connection_status.set(0)
            logger.error(f"Failed to connect after {self.config.max_retries} attempts")
            return False
    
    def _collect_system_info(self):
        """Collect system-level information"""
        try:
            with self.scrape_duration.labels(operation='system_info').time():
                system_data = self.system.api.get('system')
                
                self.system_info.info({
                    'name': str(system_data.get('name', 'Unknown')),
                    'serial': str(system_data.get('serial', 'Unknown')),
                    'version': str(system_data.get('version', 'Unknown')),
                    'model': str(system_data.get('model', 'Unknown')),
                })
                
                logger.debug("Collected system info")
        except Exception as e:
            logger.error(f"Failed to collect system info: {e}")
            self.scrape_errors.labels(operation='system_info').inc()
    
    def _collect_controller_metrics(self):
        """Collect SSA controller metrics - CRITICAL for customer (3 active controllers)"""
        try:
            with self.scrape_duration.labels(operation='controllers').time():
                # Get controllers (InfiniBox SSA has 3 active controllers)
                controllers = self.system.components.nodes.to_list()
                
                for controller in controllers:
                    controller_id = str(controller.get_id())
                    controller_name = str(controller.get_name() or f"Controller-{controller_id}")
                    
                    # Controller status
                    state = controller.get_state()
                    status_value = 1 if state == 'ACTIVE' else 0
                    self.controller_status.labels(
                        controller_id=controller_id,
                        controller_name=controller_name
                    ).set(status_value)
                    
                    # CPU and Memory usage (if available)
                    try:
                        stats = controller.get_field('stats', {})
                        if 'cpu_usage' in stats:
                            self.controller_cpu_usage.labels(
                                controller_id=controller_id,
                                controller_name=controller_name
                            ).set(stats['cpu_usage'])
                        
                        if 'memory_usage' in stats:
                            self.controller_memory_usage.labels(
                                controller_id=controller_id,
                                controller_name=controller_name
                            ).set(stats['memory_usage'])
                    except Exception as e:
                        logger.debug(f"Controller stats not available: {e}")
                
                logger.debug(f"Collected metrics for {len(controllers)} controllers")
        except Exception as e:
            logger.error(f"Failed to collect controller metrics: {e}")
            self.scrape_errors.labels(operation='controllers').inc()
    
    def _collect_pool_metrics(self):
        """Collect pool capacity metrics"""
        try:
            with self.scrape_duration.labels(operation='pools').time():
                pools = self.system.pools.to_list()
                
                for pool in pools:
                    pool_id = str(pool.get_id())
                    pool_name = str(pool.get_name())
                    
                    # Capacity metrics
                    capacity_total = pool.get_physical_capacity()
                    capacity_free = pool.get_free_physical_capacity()
                    capacity_used = capacity_total - capacity_free
                    capacity_percent = (capacity_used / capacity_total * 100) if capacity_total > 0 else 0
                    
                    self.pool_capacity_total.labels(
                        pool_id=pool_id,
                        pool_name=pool_name
                    ).set(capacity_total)
                    
                    self.pool_capacity_free.labels(
                        pool_id=pool_id,
                        pool_name=pool_name
                    ).set(capacity_free)
                    
                    self.pool_capacity_used.labels(
                        pool_id=pool_id,
                        pool_name=pool_name
                    ).set(capacity_used)
                    
                    self.pool_capacity_percent.labels(
                        pool_id=pool_id,
                        pool_name=pool_name
                    ).set(capacity_percent)
                    
                    # Volume count
                    volume_count = len(pool.get_volumes())
                    self.volume_count.labels(
                        pool_id=pool_id,
                        pool_name=pool_name
                    ).set(volume_count)
                
                logger.debug(f"Collected metrics for {len(pools)} pools")
        except Exception as e:
            logger.error(f"Failed to collect pool metrics: {e}")
            self.scrape_errors.labels(operation='pools').inc()
    
    def _collect_volume_metrics(self):
        """Collect volume metrics including performance data"""
        try:
            with self.scrape_duration.labels(operation='volumes').time():
                volumes = self.system.volumes.to_list()
                
                for volume in volumes:
                    volume_id = str(volume.get_id())
                    volume_name = str(volume.get_name())
                    pool_name = str(volume.get_pool().get_name()) if volume.get_pool() else "Unknown"
                    
                    # Size
                    size = volume.get_size()
                    self.volume_size.labels(
                        volume_id=volume_id,
                        volume_name=volume_name,
                        pool_name=pool_name
                    ).set(size)
                    
                    # Performance metrics (if available)
                    try:
                        # Get real-time statistics
                        stats = volume.get_performance_stats()
                        
                        # IOPS
                        if 'read_iops' in stats:
                            self.volume_iops_read.labels(
                                volume_id=volume_id,
                                volume_name=volume_name
                            ).set(stats['read_iops'])
                        
                        if 'write_iops' in stats:
                            self.volume_iops_write.labels(
                                volume_id=volume_id,
                                volume_name=volume_name
                            ).set(stats['write_iops'])
                        
                        # Throughput
                        if 'read_bandwidth' in stats:
                            self.volume_throughput_read.labels(
                                volume_id=volume_id,
                                volume_name=volume_name
                            ).set(stats['read_bandwidth'])
                        
                        if 'write_bandwidth' in stats:
                            self.volume_throughput_write.labels(
                                volume_id=volume_id,
                                volume_name=volume_name
                            ).set(stats['write_bandwidth'])
                        
                        # Latency
                        if 'read_latency' in stats:
                            self.volume_latency_read.labels(
                                volume_id=volume_id,
                                volume_name=volume_name
                            ).set(stats['read_latency'] / 1000)  # Convert to ms
                        
                        if 'write_latency' in stats:
                            self.volume_latency_write.labels(
                                volume_id=volume_id,
                                volume_name=volume_name
                            ).set(stats['write_latency'] / 1000)  # Convert to ms
                    
                    except Exception as e:
                        logger.debug(f"Performance stats not available for volume {volume_name}: {e}")
                
                logger.debug(f"Collected metrics for {len(volumes)} volumes")
        except Exception as e:
            logger.error(f"Failed to collect volume metrics: {e}")
            self.scrape_errors.labels(operation='volumes').inc()
    
    def _collect_host_metrics(self):
        """Collect host/mapping information"""
        try:
            with self.scrape_duration.labels(operation='hosts').time():
                hosts = self.system.hosts.to_list()
                self.host_count.set(len(hosts))
                
                logger.debug(f"Collected metrics for {len(hosts)} hosts")
        except Exception as e:
            logger.error(f"Failed to collect host metrics: {e}")
            self.scrape_errors.labels(operation='hosts').inc()
    
    def _collect_topology_data(self):
        """
        Collect topology data for end-to-end path visualization
        This is CRITICAL for correlating Infinibox → FC/iSCSI → ESXi → VM
        """
        try:
            with self.scrape_duration.labels(operation='topology').time():
                # 1. Collect Infinibox FC Port WWPNs
                try:
                    fc_ports = self.system.components.fc_ports.to_list()
                    for port in fc_ports:
                        port_id = str(port.get_id())
                        node_id = str(port.get_field('node_id', 'Unknown'))
                        wwpn = str(port.get_wwpn())
                        port_state = str(port.get_link_state())
                        
                        self.fc_port_wwpn.labels(
                            port_id=port_id,
                            node_id=node_id
                        ).info({
                            'wwpn': wwpn,
                            'state': port_state,
                            'port_index': str(port.get_field('port_index', 'Unknown'))
                        })
                    
                    logger.debug(f"Collected {len(fc_ports)} FC port WWPNs")
                except Exception as e:
                    logger.debug(f"FC ports not available: {e}")
                
                # 2. Collect Host Initiators (WWPNs and IQNs)
                try:
                    hosts = self.system.hosts.to_list()
                    for host in hosts:
                        host_id = str(host.get_id())
                        host_name = str(host.get_name())
                        
                        # Get host ports (initiators)
                        try:
                            ports = host.get_ports()
                            for port in ports:
                                port_type = str(port.get_type()).lower()  # 'fc' or 'iscsi'
                                port_address = str(port.get_address())
                                port_state = str(port.get_state())
                                
                                self.host_initiator_info.labels(
                                    host_id=host_id,
                                    host_name=host_name,
                                    initiator_type=port_type,
                                    initiator_address=port_address
                                ).info({
                                    'state': port_state,
                                    'host_type': str(host.get_host_type())
                                })
                        except Exception as e:
                            logger.debug(f"Could not get ports for host {host_name}: {e}")
                    
                    logger.debug(f"Collected initiator data for {len(hosts)} hosts")
                except Exception as e:
                    logger.error(f"Failed to collect host initiators: {e}")
                
                # 3. Collect Volume WWPNs/IQNs and Host Mappings
                try:
                    volumes = self.system.volumes.to_list()
                    
                    for volume in volumes:
                        volume_id = str(volume.get_id())
                        volume_name = str(volume.get_name())
                        
                        # Get volume serial (used for WWPN/IQN generation)
                        volume_serial = str(volume.get_serial())
                        
                        # Get volume mappings (LUNs)
                        try:
                            luns = volume.get_logical_units()
                            
                            for lun in luns:
                                host = lun.get_host()
                                host_id = str(host.get_id())
                                host_name = str(host.get_name())
                                lun_id = str(lun.get_lun())
                                
                                # Set LUN mapping metric
                                self.lun_mapping.labels(
                                    host_id=host_id,
                                    host_name=host_name,
                                    volume_id=volume_id,
                                    volume_name=volume_name,
                                    lun_id=lun_id
                                ).set(1)
                                
                                # Set host mapping info
                                self.host_mapping_info.labels(
                                    host_id=host_id,
                                    host_name=host_name,
                                    volume_id=volume_id,
                                    volume_name=volume_name
                                ).info({
                                    'lun': lun_id,
                                    'volume_serial': volume_serial,
                                    'mapping_state': 'active'
                                })
                        
                        except Exception as e:
                            logger.debug(f"No mappings for volume {volume_name}: {e}")
                    
                    logger.debug(f"Collected topology data for {len(volumes)} volumes")
                    
                except Exception as e:
                    logger.error(f"Failed to collect volume topology: {e}")
                
        except Exception as e:
            logger.error(f"Failed to collect topology data: {e}")
            self.scrape_errors.labels(operation='topology').inc()
    
    def _collect_event_metrics(self):
        """Collect recent events and alerts"""
        try:
            with self.scrape_duration.labels(operation='events').time():
                # Get recent events (last 5 minutes)
                five_minutes_ago = int((datetime.now() - timedelta(minutes=5)).timestamp() * 1000)
                events = self.system.events.find(timestamp__gte=five_minutes_ago)
                
                event_counts = {}
                for event in events:
                    severity = str(event.get_severity())
                    event_type = str(event.get_code())
                    key = (severity, event_type)
                    event_counts[key] = event_counts.get(key, 0) + 1
                
                # Update counters
                for (severity, event_type), count in event_counts.items():
                    # Note: Counters should only increase, so we track delta
                    self.events_total.labels(
                        severity=severity,
                        event_type=event_type
                    ).inc(count)
                
                logger.debug(f"Collected {len(events)} recent events")
        except Exception as e:
            logger.error(f"Failed to collect event metrics: {e}")
            self.scrape_errors.labels(operation='events').inc()
    
    def collect_metrics(self):
        """Main collection method - gathers all metrics"""
        if not self._connect():
            logger.error("Cannot collect metrics: not connected to InfiniBox")
            return
        
        logger.info("Starting metric collection cycle")
        start_time = time.time()
        
        try:
            # Collect all metrics
            self._collect_system_info()
            self._collect_controller_metrics()
            self._collect_pool_metrics()
            self._collect_volume_metrics()
            self._collect_host_metrics()
            self._collect_topology_data()  # NEW: Topology data for end-to-end visualization
            self._collect_event_metrics()
            
            duration = time.time() - start_time
            logger.info(f"Metric collection completed in {duration:.2f}s")
            
        except Exception as e:
            logger.error(f"Error during metric collection: {e}")
            self.scrape_errors.labels(operation='global').inc()

class HealthCheckHandler:
    """Simple health check endpoint"""
    def __init__(self, collector: InfiniboxCollector):
        self.collector = collector
    
    def is_healthy(self) -> bool:
        """Check if exporter is healthy"""
        return self.collector.system is not None

def main():
    """Main entry point"""
    logger.info("Starting Infinibox Exporter for Prometheus")
    
    # Load configuration
    config_path = os.getenv('CONFIG_FILE', '/app/config.yml')
    if os.path.exists(config_path):
        config = ExporterConfig.from_file(config_path)
        logger.info(f"Loaded configuration from {config_path}")
    else:
        config = ExporterConfig.from_env()
        logger.info("Loaded configuration from environment variables")
    
    logger.info(f"Configuration: host={config.infinibox_host}, port={config.exporter_port}, interval={config.scrape_interval}s")
    
    # Initialize collector
    collector = InfiniboxCollector(config)
    
    # Start Prometheus HTTP server
    start_http_server(config.exporter_port)
    logger.info(f"Prometheus exporter listening on port {config.exporter_port}")
    logger.info(f"Metrics endpoint: http://0.0.0.0:{config.exporter_port}/metrics")
    logger.info(f"Health check: http://0.0.0.0:{config.exporter_port}/health")
    
    # Initial connection
    if collector._connect():
        logger.info("Initial connection successful")
    else:
        logger.warning("Initial connection failed, will retry...")
    
    # Main collection loop
    logger.info(f"Starting collection loop (interval: {config.scrape_interval}s)")
    while True:
        try:
            collector.collect_metrics()
            time.sleep(config.scrape_interval)
        except KeyboardInterrupt:
            logger.info("Received interrupt signal, shutting down...")
            break
        except Exception as e:
            logger.error(f"Unexpected error in main loop: {e}")
            time.sleep(config.scrape_interval)
    
    logger.info("Exporter stopped")

if __name__ == '__main__':
    main()
