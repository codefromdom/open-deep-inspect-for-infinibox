# Deployment Verification Checklist

**@codefromdom**
**Version:** 1.0.0  
**Date:** December 2, 2025

Use this checklist to verify a successful deployment of the monitoring toolbox.

## Pre-Deployment (Complete Before Starting)

- [ ] **Server Requirements Met**
  - [ ] Linux server with Docker 20.10+ installed
  - [ ] 8GB RAM minimum (16GB recommended)
  - [ ] 100GB disk space available
  - [ ] Network connectivity to all monitored devices verified

- [ ] **Credentials Collected**
  - [ ] Infinibox: Management IP, username, password
  - [ ] vCenter: Hostname, username, password
  - [ ] Brocade: IP addresses (4x switches), SNMP community
  - [ ] Juniper: IP addresses (switches), SNMP community
  - [ ] Grafana: Admin password chosen

- [ ] **Network Access Verified**
  - [ ] Ping test to Infinibox management IP: `ping <infinibox-ip>`
  - [ ] Ping test to vCenter: `ping <vcenter-ip>`
  - [ ] Ping test to all Brocade switches (4x)
  - [ ] Ping test to all Juniper switches
  - [ ] Firewall rules configured (see IMPLEMENTATION_GUIDE.md)

- [ ] **Permissions Verified**
  - [ ] Infinibox monitoring user created with read-only API access
  - [ ] vCenter monitoring user created with read-only role
  - [ ] SNMP enabled on Brocade switches
  - [ ] SNMP enabled on Juniper switches

## Deployment Steps

### Phase 1: Configuration

- [ ] **Download/Extract Toolbox**
  ```bash
  cd /opt
  # Extract toolbox
  cd open-deep-inspect-for-infinibox
  ```

- [ ] **Configure Environment Variables**
  ```bash
  cp .env.example .env
  nano .env
  ```
  - [ ] Set `GRAFANA_ADMIN_PASSWORD`
  - [ ] Set `INFINIBOX_HOST`, `INFINIBOX_USER`, `INFINIBOX_PASSWORD`
  - [ ] Set `VCENTER_HOST`, `VCENTER_USER`, `VCENTER_PASSWORD`

- [ ] **Configure Device Details**
  ```bash
  nano config/infinidat.yml
  nano config/vmware.yml
  nano config/brocade.yml  # Update switch IPs
  nano config/juniper.yml  # Update switch IPs
  ```

### Phase 2: Deployment

- [ ] **Run Installation Script**
  ```bash
  ./scripts/install.sh
  ```
  
- [ ] **Verify All Containers Started**
  ```bash
  docker-compose ps
  ```
  Expected containers running:
  - [ ] victoriametrics
  - [ ] prometheus
  - [ ] grafana
  - [ ] infinidat-exporter
  - [ ] vmware-exporter
  - [ ] brocade-exporter
  - [ ] juniper-exporter
  - [ ] topology-correlator (optional, if topology service deployed)
  - [ ] postgresql (optional, if topology service deployed)

### Phase 3: Validation

- [ ] **Run Validation Script**
  ```bash
  ./scripts/validate.sh
  ```
  All checks should pass (0 errors)

- [ ] **Access Grafana**
  ```bash
  # Open browser to: http://<server-ip>:3000
  # Login: admin / <your-password>
  ```
  - [ ] Login successful
  - [ ] Dashboards visible in menu
  - [ ] "Organization Infrastructure Overview" dashboard loads

- [ ] **Verify Metrics Collection**
  - [ ] Navigate to each dashboard
  - [ ] Verify data is populating
  - [ ] Check timestamps are current

### Phase 4: Functional Testing

- [ ] **Test Infinibox Monitoring**
  - [ ] Open "Infinibox Storage Detailed Metrics" dashboard
  - [ ] Verify controller status (3 active controllers shown)
  - [ ] Verify pool capacity metrics displayed
  - [ ] Verify volume metrics shown
  - [ ] Verify FC port status displayed

- [ ] **Test VMware Monitoring**
  - [ ] Open "VMware Compute Infrastructure" dashboard
  - [ ] Verify ESXi hosts shown (14x Lenovo SR950 v3)
  - [ ] Verify VM list populated
  - [ ] Verify host CPU/memory metrics
  - [ ] Verify datastore capacity

- [ ] **Test Brocade Monitoring**
  - [ ] Open "Network Infrastructure" dashboard
  - [ ] Verify 4 switches shown
  - [ ] Verify port status (56 active ports per switch)
  - [ ] Verify port traffic metrics
  - [ ] No excessive port errors

- [ ] **Test Juniper Monitoring**
  - [ ] Juniper switches visible in dashboard
  - [ ] Interface status shown
  - [ ] Traffic metrics displayed
  - [ ] CPU/memory metrics available

- [ ] **Test Topology Visualization** (Optional, if deployed)
  - [ ] Topology correlator health check passes: `curl http://localhost:9700/health`
  - [ ] Topology metrics available: `curl http://localhost:9700/metrics | grep topology`
  - [ ] PostgreSQL connection working
  - [ ] "End-to-End Topology Visualization" dashboard loads
  - [ ] Topology paths discovered: `curl http://localhost:9700/api/v1/topology/paths`
  - [ ] Can view complete path: Volume → Network → VM

### Phase 5: Alert Verification

- [ ] **Verify Alert Rules Loaded**
  ```bash
  curl -s http://localhost:9090/api/v1/rules | jq '.data.groups | length'
  ```
  Should show multiple alert rule groups

- [ ] **Check Prometheus Alerts**
  - [ ] Open: http://<server-ip>:9090/alerts
  - [ ] Verify alert rules are loaded
  - [ ] No critical alerts firing (unless expected)

- [ ] **Test Alert Flow (Optional)**
  - [ ] Configure Alertmanager or notification channel in Grafana
  - [ ] Trigger test alert
  - [ ] Verify notification received

### Phase 6: Performance Validation

- [ ] **Check Scrape Duration**
  ```bash
  curl -s http://localhost:9090/api/v1/query?query=infinibox_scrape_duration_seconds | jq .
  ```
  Should be < 30 seconds

- [ ] **Verify Scrape Intervals**
  - [ ] Infinibox: 10 seconds
  - [ ] VMware: 15 seconds
  - [ ] Brocade: 10 seconds
  - [ ] Juniper: 10 seconds

- [ ] **Check VictoriaMetrics Ingestion**
  ```bash
  curl -s http://localhost:8428/api/v1/status/active_queries | jq .
  ```

- [ ] **Monitor Resource Usage**
  ```bash
  docker stats
  ```
  - VictoriaMetrics memory < 8GB
  - All containers healthy

### Phase 7: Documentation and Handover

- [ ] **Create Backup**
  ```bash
  ./scripts/backup.sh
  ```

- [ ] **Document Custom Configuration**
  - [ ] IP addresses used
  - [ ] Credentials (store securely)
  - [ ] Any customizations made

- [ ] **Schedule Regular Backups**
  - [ ] Add backup script to cron:
  ```bash
  crontab -e
  # Add: 0 2 * * * /opt/open-deep-inspect-for-infinibox/scripts/backup.sh
  ```

- [ ] **Provide Access Information**
  - Grafana URL: http://<server-ip>:3000
  - Prometheus URL: http://<server-ip>:9090
  - VictoriaMetrics URL: http://<server-ip>:8428

- [ ] **Review Documentation**
  - [ ] Team has access to docs/ directory
  - [ ] IMPLEMENTATION_GUIDE.md reviewed
  - [ ] TROUBLESHOOTING.md bookmarked
  - [ ] MAINTENANCE.md understood

## Post-Deployment Monitoring (First 24 Hours)

- [ ] **Hour 1: Initial Monitoring**
  - [ ] All dashboards refreshed and showing current data
  - [ ] No error logs in exporters
  - [ ] CPU/memory usage stable

- [ ] **Hour 4: Stability Check**
  ```bash
  docker-compose ps
  ./scripts/health-check.sh
  ```

- [ ] **Hour 12: Performance Review**
  - [ ] VictoriaMetrics disk usage < 10GB
  - [ ] No scrape errors
  - [ ] Alert rules firing appropriately

- [ ] **Hour 24: Full Validation**
  - [ ] Re-run validation script
  - [ ] Review logs for any warnings
  - [ ] Verify data retention working

## Production Readiness Checklist

- [ ] **Security Hardened**
  - [ ] Default passwords changed
  - [ ] Firewall rules implemented
  - [ ] HTTPS enabled for Grafana (optional but recommended)
  - [ ] Read-only credentials verified

- [ ] **High Availability (Optional)**
  - [ ] Consider deploying on Kubernetes for HA
  - [ ] Backup procedures documented
  - [ ] Disaster recovery plan created

- [ ] **Operational Procedures**
  - [ ] Daily health check scheduled
  - [ ] Weekly capacity review planned
  - [ ] Monthly credential rotation scheduled
  - [ ] On-call team trained

## Troubleshooting Quick Reference

If validation fails, check:

1. **Container not starting**:
   ```bash
   docker-compose logs <container-name>
   ```

2. **No metrics**:
   ```bash
   curl http://localhost:9600/health  # Test each exporter
   ```

3. **Authentication errors**:
   - Verify credentials in .env
   - Test credentials manually on each system

4. **Network connectivity**:
   ```bash
   docker exec org-prometheus ping infinibox.Organization.local
   ```

5. **For detailed troubleshooting**: See `docs/TROUBLESHOOTING.md`

## Sign-Off

| Role | Name | Signature | Date |
|------|------|-----------|------|
| **Deployment Engineer** | | | |
| **System Administrator** | | | |
| **Operations Manager** | | | |
| **Infinidat PS Lead** | | | |

---

**Deployment Complete!** ✅

Your Organization monitoring solution is now operational.

**Support**: For issues or questions, refer to the documentation in `docs/` or contact Open Source Community.

