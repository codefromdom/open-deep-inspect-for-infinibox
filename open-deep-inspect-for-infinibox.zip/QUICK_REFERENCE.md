# Quick Reference Card

**@codefromdom**
**Version:** 1.0.0  
**Date:** December 2, 2025

## Essential Commands

### Start/Stop Services

```bash
# Start all services
docker-compose up -d

# Stop all services
docker-compose down

# Restart specific service
docker-compose restart <service-name>

# View logs
docker-compose logs -f <service-name>
```

### Health Checks

```bash
# Run full validation
./scripts/validate.sh

# Quick health check
./scripts/health-check.sh

# Check specific exporter
curl http://localhost:9600/health  # Infinibox
curl http://localhost:9601/health  # VMware
curl http://localhost:9602/health  # Brocade
curl http://localhost:9603/health  # Juniper

# Check topology correlator
curl http://localhost:9700/health  # Topology Correlation Service
```

### Access URLs

| Service | URL | Default Credentials |
|---------|-----|---------------------|
| Grafana | http://localhost:3000 | admin / (from .env) |
| Prometheus | http://localhost:9090 | N/A |
| VictoriaMetrics | http://localhost:8428 | N/A |

### Maintenance

```bash
# Create backup
./scripts/backup.sh

# Rotate credentials
./scripts/rotate-credentials.sh

# Diagnose latency issues
./scripts/diagnostics/diagnose-latency.sh <vm-name>

# Capacity analysis
./scripts/diagnostics/diagnose-capacity.sh

# Topology discovery
./scripts/topology/discover-fc-topology.sh
./scripts/topology/discover-network-topology.sh

# Query topology paths
curl http://localhost:9700/api/v1/topology/paths | jq .

# Trigger manual correlation
curl -X POST http://localhost:9700/api/v1/topology/correlate
```

### Troubleshooting

```bash
# Check container status
docker-compose ps

# View all logs
docker-compose logs

# Check metrics collection
curl -s http://localhost:9090/api/v1/targets

# Test exporter connectivity
docker exec org-prometheus ping infinibox.Organization.local
```

## Key Metrics

### Infinibox
- `infinibox_system_status` - System health (1=OK)
- `infinibox_controller_status` - Controller status (1=Active)
- `infinibox_pool_free_capacity_bytes` - Free storage capacity
- `infinibox_volume_latency_read_ms` - Read latency

### VMware
- `vmware_host_status` - Host connection status
- `vmware_host_cpu_usage_mhz` - Host CPU usage
- `vmware_datastore_used_percent` - Datastore capacity

### Brocade
- `brocade_port_status` - Port status (1=Up)
- `brocade_port_errors_total` - Port error count
- `brocade_port_tx_bytes_total` - Transmitted bytes

### Juniper
- `juniper_interface_status` - Interface status
- `juniper_cpu_usage_percent` - Switch CPU usage
- `juniper_interface_errors_total` - Interface errors

### Topology Correlation
- `topology_paths_total` - Total topology paths discovered
- `topology_volumes_total` - Mapped volumes
- `topology_vms_total` - VMs discovered
- `topology_path_health` - Path health status
- `topology_correlation_duration_seconds` - Correlation performance

## Alert Severity Levels

- 🔴 **Critical**: Immediate action required (revenue-impacting)
- ⚠️  **Warning**: Action needed within business hours
- ℹ️  **Info**: Informational, monitor

## Common Issues

| Issue | Quick Fix |
|-------|-----------|
| Container not starting | `docker-compose logs <service>` |
| No metrics displayed | Check exporter health endpoints |
| Authentication errors | Verify credentials in .env |
| High memory usage | Reduce retention period |
| Grafana login fails | Reset password in .env and restart |

## Contact

**Open Source Community**  
Support documentation: `docs/`

